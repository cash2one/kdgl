# -*- coding: gb2312 -*-

""" �ļ����ʵ�ͨ�ô����ӿ�.
    
    copyright 2004 ��Ԫ�ţ���������Ϣ�������޹�˾
    all right reserved.
    
    $Id: fileop.py 221 2008-05-19 12:36:22Z zhangjun $
"""

__all__ = [ 'backfile' , 'FTPMixin' , 'FileNotReadyWarning' , 'extractFile' , 'str2dt' ]

import exceptions
import os,shutil,sys,traceback
import tarfile
import time,datetime
import glob

def str2dt( s , fmt , rep = 'null' ):
    try:
        t = time.mktime( time.strptime( s , fmt ) )
        if ( '%Y' in fmt ):
            if ( '%H' in fmt ):
                return datetime.datetime.fromtimestamp( t )
            else:
                return datetime.date.fromtimestamp( t )
        else:
            return datetime.time.fromtimestamp( t )
    except:
        if rep != 'null':
            return rep
        else:
            raise

def backfile( fn , suffix , tgtdir , bmove = True ):
    fn1 = os.path.split( fn )[-1]
    if suffix:
        fn1 += '.' + suffix
    if os.sep != tgtdir[-1]:
        fn2 = tgtdir + os.sep + fn1
    else:
        fn2 = tgtdir + fn1
    no = 0
    if os.access( fn2 , os.R_OK ):
        # �ҵ��ļ���ͳ������׺
        def conv( s ):
            s = s.split( '.' )[-1]
            try:
                r = int( s )
            except:
                r = 0
            return r
        flist = glob.glob( fn2 + '.*' )
        if len( flist ):
            no = max( [ conv( f ) for f in flist ] ) + 1
        else:
            no = 1
    if no > 0:
        fn2 = fn2 + '.' + str( no )
    if bmove :
        shutil.move( fn , fn2 )
    else:
        shutil.copy( fn , fn2 )
    return fn2
    
class FileNotReadyWarning( exceptions.RuntimeWarning ):
    pass
    
import ftplib

class FTPMixin:
    def openftp( self ):
        self.f = ftplib.FTP()
        self.f.connect( self.SERVER_IP , self.SERVER_PORT )
        self.f.login( self.SERVER_USER , self.SERVER_PASSWD )
        self.f.cwd( self.SERVER_FILDIR )
    
    def getFile( self , fn , tgtdir , isBin = 'b' ):
        rets = []
        try:
            self.f.dir( fn , rets.append )
        except:
            rets = []
        if len( rets ) == 0:
            raise FileNotReadyWarning( fn )
        tfn = tgtdir + fn
        try:
            fp = file( tfn , 'w' + isBin )
            if isBin == 'b' :
                self.f.retrbinary( 'retr ' + fn , fp.write )
            else:
                l = []
                self.f.retrlines( 'retr ' + fn , l.append )
                for i in l:
                    fp.write( i + '\n' )
                del l
        finally:
            fp.close()
        return tfn
    
    def closeftp( self ):
        self.f.quit()
        self.f.close()

def createfile( filename ):
    """ ��������·���ļ�, ��������·���ϵ�ȫ��Ŀ¼
        @param filename ����·��
        @return �ļ�����
    """
    try:
        f = open( filename , 'w' )
        return f
    except IOError , v :
        if v.errno == 2: # ·��������
            pn,fn = os.path.split( filename )
            os.makedirs( pn )
            f = open( filename , 'w' )
            return f
        else:
            raise

def extractFile( todir , fn , ty , efl = None ):
    """ ���ļ���ѹ����ָ��Ŀ¼
        @param todir Ŀ��·��
        @param fn    ѹ����
        @param ty    ѹ��������, tar, bz2 , gz , zip ��ѡһ
        @param efl   ָ������������ļ�, Ĭ��ΪNone, ��ʾ���ȫ��
    """
    filelist = []
    if todir[-1] != os.sep:
        todir += os.sep
    if ty.lower() == 'zip':
        raise NotImplemented( '��δʵ��Zip�ļ��Ľ��' )
    else:
        if tarfile.is_tarfile( fn ) == False:
            raise RuntimeWarning( '�ļ��Ƿ�: [%s]����tar�����ļ�' % fn )
        if ty.lower() == 'tar':
            func = tarfile.open
        elif ty.lower() == 'bz2':
            func = tarfile.TarFile.bz2open
        elif ty.lower() == 'gz':
            func = tarfile.TarFile.gzopen
        else:
            raise RuntimeWarning( '����ʶ����ļ�����: ty=' + ty )
        t = None
        try:
            t = func( fn , 'r' )
            for f in t.getnames():
                if efl and f not in efl:
                    continue
                t.extract( f , todir )
                filelist.append( todir + f )
        finally:
            if t :
                t.close()
    return filelist
    
