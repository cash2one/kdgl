# coding: gbk

# ����backplatִ����־
# ִ����־ʹ��kirbybaseģ��洢

from shangjie.conf import settings
from shangjie.utils.kirbybase import KirbyBase
import os
import datetime
def now():
    return datetime.datetime.now().strftime( '%Y-%m-%d %H:%M:%S' )

def insert( taskid , msg , level = 0 ):
    # level : 0 - info  1 - warning 2 - error
    db = KirbyBase()
    taskid = str( taskid )
    logdir = os.path.join( settings.LOGDIR , 'bklog' )
    logfn  = os.path.join( logdir , taskid )
    if not os.access( logdir , os.R_OK ):
        os.makedirs( logdir )
    
    if not os.access( logfn , os.R_OK ):
        db.create( logfn , [ 'rq:str' , 'level:int' , 'msg:str' ] )
    
    db.insert( logfn , { 'rq':now() , 'level':level , 'msg':msg } )

def select( taskid ):
    db = KirbyBase()
    taskid = str( taskid )
    logfn = os.path.join( settings.LOGDIR , 'bklog' , taskid )
    if not os.access( logfn , os.R_OK ):
        return
    
    for x in db.select( logfn , ['recno'] , ['*'] , returnType = 'object' , sortFields=['rq'] ):
        yield x

def drop( taskid ):
    taskid = str( taskid )
    logdir = os.path.join( settings.LOGDIR , 'bklog' )
    logfn  = os.path.join( logdir , taskid )
    if os.access( logfn , os.R_OK ):
        os.unlink( logfn )
