# -*- coding: gbk -*-
# ��̨���ݵ���.
import traceback
import sys
import os
import re

def tableload( fdir, fn, tn, se, schema, logger, hasHeader=False ,proc_err_fun=None ):
    """
        pre_err_fun:�Դ������ݵĴ�������
    """
    while True:
        try:
            if hasHeader:
                f = open( fdir + fn )
                t = open( fdir + fn + '.t', 'w' )
                i = 0
                for line in f:
                    if i == 0:
                        header = ','.join( filter( None , line.split( '|' ) ) )
                    else:
                        t.write( line )
                    i += 1
                f.close()
                t.close()
                os.remove( fdir + fn )
                os.rename( fdir + fn + '.t', fdir + fn )
                sql = "copy %s.%s( %s ) from '%s' NULL as '' DELIMITER as '|'" % ( schema, tn, header, (fdir + fn).replace( '\\', '\\\\' ) )
                logger.info( sql )
                se.execute( sql )
            else:
                sql = "copy %s.%s from '%s' NULL as '' DELIMITER as '|'" % ( schema, tn, (fdir + fn).replace( '\\', '\\\\' ) )
                logger.info( sql )
                se.execute( sql )
            logger.info( '�ļ�[%s]�ѵ������ݱ�[%s.%s]' % ( fdir + fn, schema, tn ) )
            break
        except:
            se.rollback()
            e = sys.exc_info()
            logger.error( ''.join( traceback.format_exception( *e ) ) )
            lineno = int(re.compile( 'line (\d+)', re.I|re.S ).findall( str(e[1]) )[0]) # �������к�
            
            i = 1
            fn1 = fdir + fn + '.1'
            f1 = open( fn1 , 'w' )
            f = open( fdir + fn )
            for line in f:
                if i < lineno:
                    f1.write( line )
                elif i == lineno:
                    logger.error( '��������[%d]:%s' % ( lineno, line ) )
                    ##�����������չ����
                    if proc_err_fun:
                        proc_err_fun( se ,tn ,lineno, line , e[1]  )
                    break
                i += 1
            f1.close()
            
            se.begin()
            if hasHeader:
                sql = "copy %s.%s( %s ) from '%s' NULL as '' DELIMITER as '|'" % ( schema, tn, header, fn1.replace( '\\', '\\\\' ) )
                logger.info( sql )
                se.execute( sql )
            else:
                sql = "copy %s.%s from '%s' NULL as '' DELIMITER as '|'" % ( schema, tn, fn1.replace( '\\', '\\\\' ) )
                logger.info( sql )
                se.execute( sql )
            se.commit()
            se.begin()
            os.remove( fn1 )
            
            fn2 = fdir + fn + '.2'
            f2 = open( fn2 , 'w' )
            if hasHeader:
                f2.write( '|'.join( header.split(',') ) )
            for line in f:
                f2.write( line )
            f.close()
            f2.close()
            os.remove( fdir + fn )
            os.rename( fn2, fdir + fn ) # ������

def filehanlde( fdir, fn, logger ):
    # �����ļ����ݴ���
    logger.info( '��ʼ�����ļ�:%s' % (fdir+fn) )
    f = open( fdir + fn )
    content = f.read()
    f.close()
    
    # ���һ��'|'����
    new_content = content.replace( '|\n', '\n' )
    new_content = new_content.replace( '|\r\n', '\n' ) # Linux�¿��ܳ��ֵĻ��з�
    
    # '\'����
    new_content = new_content.replace( '\\', '\\\\' )
    
    # ���ڴ���
    p = re.compile( '(\d{2})/(\d{2})/(\d{4})', re.I|re.S ) # ��̨ж�����ڸ�ʽΪ����/��/��
    new_content = p.sub( '\\3-\\1-\\2' , new_content )
    p = re.compile( '(\d{4})/(\d{2})/(\d{2})', re.I|re.S ) # MISж�����ڸ�ʽΪ����/��/��
    new_content = p.sub( '\\1-\\2-\\3' , new_content )
    
    f = open( fdir + fn, 'w' )
    #new_content = string_filter( new_content )
    f.write( new_content )
    f.close()
    logger.info( '�ļ�[%s]�������' % (fdir+fn) )

def load( fdir, loadmap, se, schema, logger, step=None, hasHeader=False ,proc_err_fun = None ):
    logger.info( '��̨���ݵ��뿪ʼ' )
    for fitem in loadmap:
        if not step.stepIN( '�����ļ�: ' + fitem[0] ):
            continue
        fn = fitem[0]
        filehanlde( fdir, fn, logger )
        for item in fitem[1]:
            key = item[0]
            if key=='convert':
                func = item[1] ##������
                f = open( fdir+fn, 'r')
                content = f.readlines()
                f.close()
                
                ##�������ļ���������
                f = open( fdir+fn , 'w')
                for line in content:
                    nr = func( line )
                    f.write( nr )
                f.close()
            elif key == 'load':
                tn = item[1]
                de = item[2]
                logger.info( '��ʼ���ļ�%s�����%s.%s...' , fdir+fn , schema, tn )
                if de == True: # ���ԭ����
                    sql = "truncate table %s.%s" % (schema, tn)
                    logger.info( sql )
                    se.execute( sql )
                    se.commit()
                    se.begin()
                #filehanlde( fdir, tn+'.txt', logger )
                tableload( fdir, fn, tn, se, schema, logger, hasHeader ,proc_err_fun )
                #raw_input("�����������������")##todo,�Ժ�����
            elif key == 'sql':
                logger.info( 'ִ��SQL: %s' , item[1] )
                try:
                    se.execute( item[1] )
                except:
                    e = sys.exc_info()
                    logger.error( 'ִ��SQLʧ��:%s',  ''.join( traceback.format_exception(*e) ) )
                    raise RuntimeError( 'sql error' )
            elif key == 'skip':
                continue
            else:
                raise RuntimeError( 'δ֪�Ĺ��ܶ���: %s, %s' , key , str( item[1] ) )
        step.stepOUT()
    logger.info( '��̨���ݵ���ɹ�' )
