# coding: gbk
# �ͻ���ӳ���

from shangjie.conf import settings
from shangjie.utils.db import table_create
from sqlalchemy import *

@table_create( ( 'dg' , 'gr' ) )
def hx_khhys( lb ):
    t = Table( 'hx_%skhhys' % lb,
                settings.META_DATA , 
                Column( 'khid', Integer ), # �ͻ�ID
                Column( 'khh', String(30) ) # �ͻ���
             )
    return ( t, 
             Index( 'hx_%skhhys_u' % lb ,
                    t.c.khid, 
                    t.c.khh , 
                    unique=True ),
             Index( 'hx_%skhhys_i' % lb,
                    t.c.khh, 
                    unique=False ),
           )