# coding: gbk

from shangjie.conf import settings
from shangjie.utils.db import table_create
from sqlalchemy import *

#ȫϢ�˻�����
@table_create( ( 'grckzh' , 'dgckzh' , 'dgdkzh' , 'grdkzh' , 'pjtx' , 'nbzh' ) )
def qx_zhcs( lb ):
    t = Table( 'qx_%scs' % lb,
                settings.META_DATA , 
                Column("zh",String(30) ),#�˺�              
                Column("yxqq",DateTime),#��Ч����              
                Column("yxqz",DateTime, default = func.date(2099,1,1)),#��Ч��ֹ              
                Column("csdm",String(30) ),#��������           
                Column("csz1",String(30),nullable=True ),#����ֵ       
                Column("csz2",Numeric(20,6),nullable=True ),#����ֵ       
                Column("csz3",Numeric(20,6),nullable=True ),#����ֵ       
                Column("csz4",PickleType,nullable=True )#����ֵ        
             )   
    return ( t , 
             Index( 'qx_%scs_u' % lb ,
                    t.c.zh ,
                    t.c.yxqq,
                    t.c.csdm,
                    unique = True ),
             Index( 'qx_%scs_i1' % lb ,
                    t.c.zh ,
                    t.c.yxqq,
                    unique = False ),
             Index( 'qx_%scs_i2' % lb,
                    t.c.zh ,
                    t.c.yxqq,
                    t.c.yxqz,
                    unique = False )
           )
