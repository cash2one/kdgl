# coding: gbk

from shangjie.conf import settings
from shangjie.utils.db import table_create
from sqlalchemy import *

#ȫϢ������
@table_create( zqdm = 'Y' )
def qx_k_yeb( zqdm ):
    def aa(i):
        return Column("ye_%d"%i,Numeric(16,2),default = 0 )#���
        
    t = Table( 'qx_k_yeb_%s'% zqdm ,
                settings.META_DATA ,
                Column("kh",String(30), primary_key= True ),#����              
                *map(aa,range(1,373))
             )
    return ( t , 
           )
