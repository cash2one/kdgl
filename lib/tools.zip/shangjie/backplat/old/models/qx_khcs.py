# coding: gbk
# �Թ�/���˿ͻ�����(ȫϢ)
# 

from shangjie.conf import settings
from shangjie.utils.db import table_create
from sqlalchemy import *
from datetime import date

@table_create( ( 'dg' , 'gr' ) )
def qx_khcs( lb ):
    t = Table(  'qx_%skhcs' % lb ,
                settings.META_DATA , 
                Column( 'khid', Integer ), # �ͻ�ID
                Column( 'yxqq', Date ), # ��Ч����
                Column( 'yxqz', Date, default=date(2099,1,1) ), # ��Ч��ֹ
                Column( 'csdm', String(30) ), # ��������
                Column( 'csz1', String(100) ), # ����ֵ1
                Column( 'csz2', Numeric(20,6), nullable=True ), # ����ֵ2
                Column( 'csz3', Numeric(20,6), nullable=True ), # ����ֵ3
                Column( 'csz4', PickleType, nullable=True ) # ����ֵ4
             )
    return ( t, 
             Index( 'qx_%skhcs_u' % lb,
                    t.c.khid, 
                    t.c.yxqq,
                    t.c.csdm,
                    unique=True ),
             Index( 'qx_%skhcs_i1' % lb,
                    t.c.khid, 
                    t.c.yxqq,
                    unique=False ),
             Index( 'qx_%skhcs_i2' % lb,
                    t.c.khid, 
                    t.c.yxqq,
                    t.c.yxqz,
                    unique=False )
           )