# coding: gbk
# ��Ա��չ��Ϣ(ȫϢ����)

from shangjie.conf import settings
from sqlalchemy import *
from datetime import date
from shangjie.utils.db import table_create

@table_create()
def qx_hykzxx():
    t = Table( 'qx_hykzxx',
                settings.META_DATA , 
                Column( 'hydm', Integer, ForeignKey( 'gl_hydy.hydm', enable=False ) ), # ��Ա����
                Column( 'yxqq', Date ), # ��Ч����
                Column( 'yxqz', Date, default=date(2099,1,1) ), # ��Ч��ֹ
                Column( 'csdm', String(30) ), # ��������
                Column( 'csz1', String(100) ), # ����ֵ1
                Column( 'csz2', String(100) ), # ����ֵ2
                Column( 'csz3', Numeric(20,6) ), # ����ֵ3
                Column( 'csz4', PickleType ), # ����ֵ4
             )
    return ( t, 
             Index( 'qx_hykzxx_u', 
                    t.c.yxqq, 
                    t.c.csdm,
                    unique=True ),
             Index( 'qx_hykzxx_i1', 
                    t.c.yxqq, 
                    unique=False ),
             Index( 'qx_hykzxx_i2', 
                    t.c.yxqq, 
                    t.c.yxqz,
                    unique=False ),
           )