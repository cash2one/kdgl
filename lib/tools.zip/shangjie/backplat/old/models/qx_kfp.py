# coding: gbk

from shangjie.conf import settings
from shangjie.utils.db import table_create
from sqlalchemy import *

#ȫϢ������
@table_create()
def qx_kfp():  
    t = Table( 'qx_kfp',
                settings.META_DATA , 
                Column("kh",String(30) ),#����              
                Column("xh",Numeric(3,0) ),#���              
                Column("yxqq",DateTime),#��Ч����              
                Column("yxqz",DateTime, default = func.date(2099,1,1)),#��Ч��ֹ              
                Column("fplx",String(100),nullable=True  ),#��������           
                Column("hydm",Integer , ForeignKey( 'gl_hydy.hydm' , enable = False ) ),#��Ա����
                Column("zblx",String(1) ),#ռ������       
                Column("zb",Numeric(16,0) )#ռ��       
             )   
    return ( t , 
             Index( 'qx_kfp_u' ,
                    t.c.kh ,
                    t.c.yxqq,
                    t.c.hydm,
                    unique = True ),
             Index( 'qx_kfp_i1' ,
                    t.c.kh ,
                    t.c.yxqq,
                    unique = False ),
             Index( 'qx_kfp_i2' ,
                    t.c.kh ,
                    t.c.yxqq,
                    t.c.yxqz,
                    unique = False )
           )

#�������¶ȱ�
@table_create( zqdm = 'M' )
def hx_kfp( zqdm ):
    t = Table( 'hx_kfp_%s' % zqdm ,
            settings.META_DATA , 
            Column("kh",String(30) ),#����              
            Column("xh",Numeric(3,0) ),#���              
            Column("fplx",String(100),nullable=True  ),#��������           
            Column("hydm",Integer , ForeignKey( 'gl_hydy.hydm' , enable = False ) ),#��Ա����
            Column("zblx",String(1) ),#ռ������       
            Column("zb",Numeric(16,0) )#ռ��       
         )
    return( t , 
            Index( 'hx_kfp_%s_i' % zqdm,
                    t.c.kh ,
                    t.c.hydm,
                    t.c.xh , 
                    unique = True ),
          )