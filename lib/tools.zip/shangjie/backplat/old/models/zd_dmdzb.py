# coding: gbk
# ������ձ�

from shangjie.conf import settings
from sqlalchemy import *
from shangjie.utils.db import table_create

@table_create()
def zd_dmdzb():
    t = Table( 'zd_dmdzb',
                settings.META_DATA , 
                Column( 'lb', String(20) ), # ���
                Column( 'dm', String(20) ), # ����
                Column( 'mc', String(50) ), # ����
                Column( 'cs', String(30) ) # ����
             )
    return ( t, 
             Index( 'zd_dmdzb_u', 
                    t.c.lb, 
                    t.c.dm,
                    unique=True ),
           )