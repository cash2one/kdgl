# coding: gbk

from shangjie.conf import settings
from shangjie.utils.db import table_create
from sqlalchemy import *

#ȫϢ�˻�����
@table_create( ( 'grck' , 'dgck' , 'dgdk' , 'grdk' ) , zqdm = 'Y' )
def qx_zh_yeb( lb ,zqdm ):
    def aa(i):
        return Column("ye_%d"%i,Numeric(16,2),default = 0 )#���
        
    t = Table( 'qx_%szh_yeb_%s'%( lb , zqdm ),
                settings.META_DATA , 
                Column("zh",String(30), primary_key= True  ),#�˺�              
                *map(aa,range(1,373))      
             )   
    return ( t , 
           )
