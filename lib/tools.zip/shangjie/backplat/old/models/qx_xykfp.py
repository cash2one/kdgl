# coding: gbk

from shangjie.conf import settings
from shangjie.utils.db import table_create
from sqlalchemy import *

#ȫϢ���ÿ�����
@table_create()
def qx_xykfp():  
    t = Table( 'qx_xykfp',
                settings.META_DATA , 
                Column("kh",String(30) ),#����              
                Column("xh",Numeric(3,0) ),#���              
                Column("yxqq",DateTime),#��Ч����              
                Column("yxqz",DateTime, default = func.date(2099,1,1)),#��Ч��ֹ              
                Column("fplx",String(100),nullable=True  ),#��������           
                Column("hydm",Integer , ForeignKey( 'gl_hydy.hydm' , enable = False ) ),#��Ա����
                Column("zblx",String(1) ),#ռ������       
                Column("zb",Numeric(16,0) )#ռ��       
             )   
    return ( t , 
             Index( 'qx_xykfp_u' ,
                    t.c.kh ,
                    t.c.yxqq,
                    t.c.hydm,
                    unique = True ),
             Index( 'qx_xykfp_i1' ,
                    t.c.kh ,
                    t.c.yxqq,
                    unique = False ),
             Index( 'qx_xykfp_i2' ,
                    t.c.kh ,
                    t.c.yxqq,
                    t.c.yxqz,
                    unique = False )
           )

#���ÿ������¶ȱ�
@table_create( zqdm = 'M' )
def hx_xykfp(zqdm):
    t = Table( 'hx_xykfp_%s' % zqdm ,
                settings.META_DATA , 
                Column("kh",String(30) ),#����              
                Column("xh",Numeric(3,0) ),#���              
                Column("fplx",String(100),nullable=True  ),#��������           
                Column("hydm",Integer , ForeignKey( 'gl_hydy.hydm' , enable = False ) ),#��Ա����
                Column("zblx",String(1) ),#ռ������       
                Column("zb",Numeric(16,0) )#ռ��       
             )   
    return( t , 
            Index( 'hx_xykfp_%s_u'%zqdm,
                    t.c.kh ,
                    t.c.xh , 
                    t.c.hydm,
                    unique = True ),
          )