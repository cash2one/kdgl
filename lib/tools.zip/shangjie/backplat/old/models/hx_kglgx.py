# coding: gbk

from shangjie.conf import settings
from sqlalchemy import *
from shangjie.utils.db import table_create

#��������ϵ��
@table_create()
def hx_kglgx():
    t = Table( 'hx_kglgx',
                settings.META_DATA , 
                Column("zkh",String(30) ),#������              
                Column("fskh",String(30) )#����������              
             )   
    return ( t , 
             Index( 'hx_kglgx_u' ,
                    t.c.zkh ,
                    t.c.fskh, 
                    unique = True )
           )
