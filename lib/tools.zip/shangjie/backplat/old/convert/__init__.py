# coding: gbk

from datamapping import *
from dataprovide import *