# -*- coding: gbk -*-

from shangjie.conf import settings
from shangjie.utils.functools import AttrDict
# �����ṩ
import types

class SqlDataProvider( object ):
    # ʹ��sql��ѯ����ʼ�������ṩ��
    
    def __init__( self , sql , params = None ):
        self.sql = sql
        self.params = params
    
    def __iter__( self ):
        con = settings.DB.connect()
        ## �ɿ��Ƕ�sql�����﷨У�飬�Ż��Ժ���˵
        r = con.execute( self.sql , self.params )
        for row in r:
            yield row

class TableDataProvider( SqlDataProvider ):
    def __init__( self , tn ):
        super( TableDataProvider , self ).__init__( "select * from " + tn )

class FuncDataProvider:
    def __init__( self , func , *args , **kwargs ):
        self.func = func
        self.args = args
        self.kwargs = kwargs
    
    def __iter__( self ):
        r = self.func( *self.args , **self.kwargs )
        if not ( isinstance( r , types.GeneratorType ) or \
                 isinstance( r , tuple ) or \
                 isinstance( r , list ) ):
            r = [ r ]
            
        for x in r:
            if isinstance( x , dict ):
                yield AttrDict( x )
            elif hasattr( x , 'items' ) and callable( x.items ):
                yield x
            else:
                raise RuntimeError( '�û��ṩ�ĺ���û�з����ֵ���������:name=[%s],ret=[%s]' % (self.func.func_name, repr(x) ) )
