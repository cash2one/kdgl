# coding: gbk

from shangjie.conf import settings
from shangjie.utils.db import create_all

from shangjie.backplat import models as back_models
from shangjie.forwork  import models as flow_models
from shangjie.formula  import models as formula_models

from shangjie.utils import package

@package.register( "�����Խ���" )
def tbcreate( gInst ):
    create_all( back_models , gInst.curdate )
    create_all( flow_models , gInst.curdate )
    create_all( formula_models , gInst.curdate )
