# coding: gbk

# $Id: zqdm.py 222 2008-05-19 15:45:30Z zhangjun $

# Ϊȫ�ֶ���������������Ϣ

from shangjie.utils.globaldata import register_dict
from shangjie.utils.functools import rq2zqdm
import datetime

class ZQObject( object ):
    def __init__( self , con , zqdm ):
        r = con.execute( "select * from zd_sjzq where zqdm='%s' " % zqdm )
        row = r.fetchone()
        if row:
            self.zqdm = zqdm
            self.zqts = int( row.zqts )
            self.zqnljts = int( row.zqnljts )
            self.zqksrq  = datetime.date( int(row.zqksrq[:4]), int(row.zqksrq[5:7]), int(row.zqksrq[8:10]) ) # row.zqksrq
            self.zqjsrq  = datetime.date( int(row.zqjsrq[:4]), int(row.zqjsrq[5:7]), int(row.zqjsrq[8:10]) ) #row.zqjsrq
            self.zqssnf  = int( row.zqssnf )
            self.zqssjd  = int( row.zqssjd or 0 )
            self.zqssyf  = int( row.zqssyf or 0 )
        else:
            raise RuntimeError( '�Ҳ���ָ�����ڵ����ݶ���[%s]' % zqdm )

def dqkhq( gInst ):
    if gInst.curdate is None:
        gInst.log.error( '��û�и���ǰ���ڸ�ֵ�����ɳ�ʼ�����ڴ���' )
        return
    d = {}
    d['m' ] = rq2zqdm( 'M' , gInst.curdate )
    d['mo'] = ZQObject( gInst.con , d['m' ] )
    d['q' ] = rq2zqdm( 'Q' , gInst.curdate )
    d['qo'] = ZQObject( gInst.con , d['q' ] )
    d['b' ] = rq2zqdm( 'B' , gInst.curdate )
    d['bo'] = ZQObject( gInst.con , d['b' ] )
    d['y' ] = rq2zqdm( 'Y' , gInst.curdate )
    d['yo'] = ZQObject( gInst.con , d['y' ] )
    
    if gInst.zqdm:
        gInst.zqdm_obj = ZQObject( gInst.con , gInst.zqdm_obj )
    
    return d
    
register_dict( '��ȡ��ǰ������' , dqkhq )
