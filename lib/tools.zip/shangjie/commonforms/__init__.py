# coding: gbk

from shangjie.conf import settings

settings.check( "CFDIR" )