# coding: gbk
from shangjie.conf import settings
from sqlalchemy import *
from sqlalchemy.orm import *
from djangoext.sqlalchemy import ForeignKey
from sqlalchemy.ext.declarative import *
from shangjie.utils.ftools import register

class GL_JSDY( settings.BaseModel ):
    # ����_��ɫ����
    __tablename__ = 'gl_jsdy'
    jsdm = Column( String(4) , nullable = False , primary_key = True ) # ��ɫ����
    jsmc = Column( String(40) , nullable = False ) # ��ɫ����
    #hylist = many_to_many( 'GL_HYDY' , gl_hyjsfp , 'jslist' )
    
#gl_hyjsfp = Table( 'gl_hyjsfp' , settings.META_DATA , 
#                   Column( 'hydm' , String(10) , ForeignKey( "gl_hydy.hydm" , enable = False ) , primary_key = True ) , 
#                   Column( 'jsdm' , String(4)  , ForeignKey( "gl_jsdy.jsdm" , enable = False ) , primary_key = True )
#                 )
class GL_HYJSFP( settings.BaseModel ):
    # ����_��Ա��ɫ����
    __tablename__ = 'gl_hyjsfp'
    hydm = Column( String(10) , ForeignKey( "gl_hydy.hydm" , enable = False ) , primary_key = True ) # ��Ա����
    jsdm = Column( String(4) , ForeignKey( "gl_jsdy.jsdm" , enable = False ) , primary_key = True ) # ��ɫ����

#gl_jsgndy = Table( 'gl_jsgndy', settings.META_DATA , 
#                   Column( 'gndm', String(10), ForeignKey( 'gl_gndy.gndm', enable=False ) , primary_key = True ), # ���ܴ���
#                   Column( 'jsdm', String(4), ForeignKey( 'gl_jsdy.jsdm', enable=False ) , primary_key = True ), # ��ɫ����
#                   Column( 'qxxx', PickleType, nullable=True ) # Ȩ����Ϣ
#                 )
class GL_JSGNDY( settings.BaseModel ):
    # ����_��ɫ���ܶ���
    __tablename__ = 'gl_jsgndy'
    gndm = Column( String(10) , ForeignKey( "gl_gndy.gndm" , enable = False ) , primary_key = True ) # ���ܴ���
    jsdm = Column( String(4) , ForeignKey( "gl_jsdy.jsdm" , enable = False ) , primary_key = True ) # ��ɫ����
    qxxx = Column( PickleType , nullable = True ) # Ȩ����Ϣ


GL_JSDY.hylist = relation( 'GL_HYDY' , secondary = GL_HYJSFP.__table__ , backref = 'jslist' )
    #gnlist = many_to_many( 'GL_GNDY' , gl_jsgndy , 'jslist' )
GL_JSDY.gnlist = relation( 'GL_GNDY' , secondary = GL_JSGNDY.__table__ , backref = 'jslist' )
    
