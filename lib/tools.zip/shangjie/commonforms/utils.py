# coding: gbk

# ͨ�ù�������ͬȨ����ص�

from django.http import HttpResponse , HttpRequest,HttpResponseRedirect
from djangoext.mako import render_to_response
import simplejson

def to_json( obj ):
    return HttpResponse( simplejson.dumps( obj , ensure_ascii = False , encoding = 'gbk' ) )
