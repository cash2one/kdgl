# coding: gbk

from django.conf.urls.defaults import *
from django.conf import settings
import os

urlpatterns = patterns('',
    # designer
    (r'^text/(.*)$' , 'goldchild_erp.designer.text' ) ,
    (r'^json/(.*)$' , 'django.views.static.serve', {'document_root': settings.DESIGNER_DIR } ),
    (r'^(.*)$' , 'django.views.static.serve', {'document_root': settings.DESIGNER_DIR } ),
)