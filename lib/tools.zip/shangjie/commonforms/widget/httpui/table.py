# coding: gbk

from shangjie.commonforms.cfcore import ElementParse , Action
from shangjie.commonforms.widget import CompositeWidget
from djangoext.mako import render_string
from django.utils.datastructures import SortedDict

class TableRefreshAction( Action ):
    def __init__( self , link , wdg ):
        self.link  = link
        self.table = wdg
        self.params = wdg.fetchdata + [ 'page' ]
    
    def subcall( self , cf , **kwarg ):
        self.table.proc_data( cf , **kwarg )
        
    def get_link( self , cf ):
        return [ self.link , ]

class Table( CompositeWidget ):
    """
        ��������չʾ
        <table name="findtable" dp="" pagesize="" data="fxm,flb,fxb" pk="fxm">
            <row>
                <col header="����"><input type="str" name="fxm"/></col>
                <col header="��Ա���"><text name="flb" dp="hylb"/></col>
                <col header="�Ա�">
                    <combobox name="fxb" dp="aaa" param="">
                        <value key="">��ѡ��</value>
                        <value key="?" at="bottom">��֪��</value>  # at���ԣ�Ĭ��Ϊ�ڶ�������
                    </combobox>
                </col>
                <col header="����"><button ac="queryhy" link="hylist">��ѯ</button></col>
            </row>
        </table>
        
        data����Ϊ��ȡ�������ƣ�ʹ��','�ָ���
        key ����Ϊ��ȡ���ݵ����������������','�ָ�
    """
    def proc_extend( self ):
        w = 0
        for col in self.children[0].children:
            try:
                w += int( col.width[:-2] )
            except:
                pass
        self.width = '%dpx' % w

    def proc_attrib( self , attr ):
        super( Table , self ).proc_attrib( attr )
        self.pagesize = int( attr[ 'pagesize' ] )
        self.dp = attr.get('dp' , None )
        self.nocontrol = 'nocontrol' in attr
        self.fetchdata = map( lambda x: x.strip() , attr[ 'data' ].split( ',' ) ) if 'data' in attr else []# ��ȡ����
        self.pk = attr[ 'pk' ].split( ',' ) if 'pk' in attr else [] 
        self.modified = {}          # �洢�û��޸Ĺ������ݣ�ÿ��Ϊ�ֵ䣬��keyΪ��
        # ��ȡ���ڵ㣨CF���󣩣������ӱ���ˢ�µ�Action
        cf = self.treeobj.get_from_path( '/' ).value
        cf.actions[ self.uniname + '_refresh' ] = TableRefreshAction( self.uniname , self )
    
    def proc_children( self , c ):
        if c.tag.lower() == 'row':
            # ����ҳ���е�ÿ��
            for i in range( self.pagesize ):
                self._proc_children( c )
        else:
            # �����ı�ǲ�֧��
            raise RuntimeError( 'Table������ʹ�÷�row���[%s]' % c.tagname )
    
    def render( self , cf ):
        self.clear_data()
        # ����׼������
        extra = {}
        if self.dp:
            dp = cf.dataprovider( self.dp )
            pagecount , m = divmod( len( dp ) , self.pagesize )
            if m > 0:
                pagecount += 1
            # 
            curpage = int( cf.get( "page" , typo = 'simple' , default = 1 ) )
            bpage = curpage - 5 if curpage > 5 else 1
            epage = bpage + 10 if bpage + 10 <= pagecount else pagecount + 1
            begin = ( curpage - 1 ) * self.pagesize
            i = 0
            for v in dp[ begin:begin+self.pagesize ]:
                self.put_data( 'row' , i , v )
                i += 1
            extra = dict( pagecount = pagecount , curpage = curpage , bpage = bpage , epage = epage )
        return render_string( """#coding: gbk
<table id="${ uniname }" onmouseover="highlight()" style="width:${ twidth };">
    <thead>
        <tr>
        % for c in row.children:
        %   if type( c.header ) == str:
                <th style="width:${ c.width }">${ c.header }</th>
        %   elif type( c.header ) == list:
        %       for h in c.header:
                <td class="header" style="width:${ c.swidth } ">${ h }</td>
        %       endfor
        %   endif
        % endfor
        </tr>
    </thead>
    
    <tbody>
        ${ substr }
    </tbody>
    
    % if not nocontrol:
    <tfoot>
        <tr>
            <td colspan="${ len( row.children ) }">
                <div style="float:right">
                    <input type="hidden" name="page" value="${ curpage }" id="${ uniname }_curpage"/>
                    <div class="page_text">��${ curpage }ҳ����${ pagecount }ҳ</div>
                    % if not( bpage == 1 and epage == pagecount + 1):
                    <div class="page_img"><a href="#" onclick="${ uniname }_page( 1 )"><img src="/images/ht1.gif" width="9" height="8" align="absmiddle" border="0" alt="��һҳ" /></a></div>
                    <div class="page_img"><a href="#" onclick="${ uniname }_page( ${ curpage - 1 if curpage > 1 else curpage } )"><img src="/images/ht2.gif" width="9" height="8"  align="absmiddle" border="0" alt="��һҳ" /></a></div>
                    % endif
                    % for i in range( bpage , epage ):
                    <div class="page_text"><a href="#" onclick="${ uniname }_page( ${ i } )">${ i }</a></div>
                    % endfor
                    % if not( bpage == 1 and epage == pagecount + 1 ):
                    <div class="page_img"><a href="#" onclick="${ uniname }_page( ${ curpage + 1 if curpage < pagecount else pagecount } )"><img src="/images/qj1.gif" width="9" height="8" align="absmiddle" border="0" alt="��һҳ" /></a></div>
                    <div class="page_img"><a href="#" onclick="${ uniname }_page( ${ pagecount } )"><img src="/images/qj2.gif" width="9" height="8" align="absmiddle" border="0" alt="���һҳ" /></a></div>
                    <div class="page_text">ȥ</div>
                    <div class="page_ipt"><input type="text" id="${ uniname }_go_page" style="border:1px solid #7ac4ea; width:15px;"/></div>
                    <div class="page_text">ҳ</div>
                    <div class="page_ipt"><input type="button" value="GO" class="btn_1" onclick="${ uniname }_page( $( '${ uniname }_go_page' ).value )"/></div>
                    % endif
                </div>
            </td>
        </tr>
    </tfoot>
    
    % endif
</table>
""" , uniname = self.uniname , row = self.children[0] , substr = self.render_children( cf ) , nocontrol = self.nocontrol , twidth = self.width , **extra )

    def proc_js( self ):
        return """
function %(uniname)s_page( n ){
    $( '%(uniname)s_curpage' ).value = n;
    action_fire( '%(uniname)s_refresh' , '%(uniname)s' , '' );
}
""" % { 'uniname': self.uniname }
    
    def set_modified( self , v ):
        key = tuple( map( lambda x:v[x] , self.pk ) )
        self.modified[ key ] = v
    
    def get_modified( self , v ):
        key = tuple( map( lambda x:v[x] , self.pk ) )
        return self.modified.get( key , None )
    
    def proc_data( self , cf , page = 1 , **kwarg ):
        if self.fetchdata:
            data = map( lambda x: list( x ) , kwarg.items() )
            data = filter( lambda x:x[0] in self.fetchdata , data )
            for i in data:
                if type(i[1]) is None:
                    raise RuntimeError("[%s]δ�ύ����̨"%i[0])
                elif type( i[1] ) is not list:
                    i[1] = [ i[1] ]
            for i in range( len( data[0][1] ) ):
                v = dict( map( lambda x: ( x[0] , x[1][i] ) , data ) )
                self.set_modified( v )
        cf.set( page = page )
    
class Row( CompositeWidget ):
    """
        �����е��ж���
    """
    def proc_attrib( self , attr ):
        super( Row , self ).proc_attrib( attr )
        self.force = 'force' in attr
        self.onclick = attr.get( 'onclick' , None )
    
    def render( self , cf ):
        self.clear_data()
        data = self.parent.supply_data( self.tagname , self.index )
        if data:
            m = self.parent.get_modified( data )
            cf.set( **( m or data ) )
            if m:
                for x in self.children:
                    if x.bind:
                        mv = m[ x.bind ]
                        self.put_data( 'col' , x.index , None if mv == data[ x.bind ] else data[ x.bind ] )
            substr = self.render_children( cf )
        elif self.force:
            d = dict( zip( self.parent.fetchdata , [''] * len( self.parent.fetchdata ) ) )
            cf.set( **d )
            substr = self.render_children( cf )
        else:
            substr = """<td></td>""" * len( self.children )
        return render_string( """#coding: gbk
<tr class="${ kls }" id="${ uniname }" \\
% if onclick:
onclick="${ onclick }" \\
% endif
>
${ substr }
</tr>""" , kls = 'row%d' % ( self.index % 2 + 1 , ) , uniname = self.uniname , substr = substr , onclick = self.onclick )
            
    def proc_children( self , c ):
        if c.tag.lower() in ( 'col' , 'dyncol' ):
            # ����ÿ�е��ж���
            self._proc_children( c )
        else:
            # �����ı�ǲ�֧��
            raise RuntimeError( 'Table�е�RowԪ���в��������з�col���[%s]' % c.tag )
    
class Col( CompositeWidget ):
    """
        �����е��ж���
    """
    def proc_attrib( self , attrib ):
        super( Col , self ).proc_attrib( attrib )
        self.header = attrib[ 'header' ].encode( 'gbk' )
        self.width  = attrib[ 'w' ]
        self.align = attrib.get( 'a' , "center" )
        self.bind   = attrib.get( 'bind' , None )
    
    def render( self , cf ):
        # ��ȡ��ʾ����
        kls = tooltip = ''
        ret = self.parent.supply_data( 'col' , self.index )
        if ret:
            kls = 'warning'
            tooltip = '�������Ѹı䣬ԭ����Ϊ��' + str(ret)
        return render_string( """#coding: gbk
<td id="${ uniname }" \\
% if kls:
class="${ kls }" tooltip="${ tooltip }" \\
% endif
 style="{ text-valign: middle; text-align:${ align };padding-left:0px; }" >${ buf }</td>""" , kls = kls, uniname = self.uniname , tooltip = tooltip , buf = self.render_children( cf ) , align = self.align )


class DynCol( CompositeWidget ):
    """
        ������չ���ж���
        �ύ��������self.name(key)�����ƣ���Ҫ��һ������
        Ϊ�˼�ʵ�֣����в����仯��ȫ������Ϊһ�����壬�����ڵ����ύ�Ŀ���
    """
    def proc_attrib( self , attr ):
        super( DynCol , self ).proc_attrib( attr )
        self.dp = attr[ 'dp' ]
        self.align = attr.get( 'a' , "center" )
        # ��ȡͨ��¼�����
        cf = self.treeobj.get_from_path( '/' ).value
        dp = cf.dataprovider( self.dp )
        self.columns = SortedDict()
        for x in dp:
            for k , v in x.items():
                self.columns[ k ] = v
        self.swidth = attr[ 'w' ]
        self.width = '%spx' % ( len( self.columns ) * int( attr[ 'w' ][:-2] ) )
        self.bind  = None
        self.header = self.columns.values()
    
    def render( self , cf ):
        return render_string( """#coding: gbk
% for k in cols.keys():
<td id="${ uniname }_${ k }" \\
 style="{ text-align:${ align };padding-left:0px; }" >${ buf }</td>
% endfor""" , uniname = self.uniname , buf = self.render_children( cf ) , align = self.align , cols = self.columns)

