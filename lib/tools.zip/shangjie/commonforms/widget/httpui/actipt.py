# coding: gbk
from shangjie.commonforms.cfcore import BaseDataProvider , ElementParse, Action
from shangjie.commonforms.widget import CFWidget , ActionWidget , CompositeWidget
from djangoext.mako import render_string
from xml.etree.ElementTree import XML
from upload import Field

class ActinputRefreshAction( Action ):
    def __init__( self , wdg ):
        self.actinput = wdg
        self.params = [ wdg.bind , ]
    
    def subcall( self , cf , **k ):
        p = self.params[0]
        cf.set( **{ self.actinput.name : k[ p ] } )

    def get_link( self , cf ):
        return [ self.actinput.uniname , ]
        
class ActinputSelectAction( Action ):
    def __init__( self , link , wdg ):
        self.link  = link
        self.actinput = wdg
        self.params = [ wdg.name , ]
    
    def subcall( self , cf , **k ):
        p = self.params[0]
        cf.set( **{ p : k[ p ] } )

    def get_link( self , cf ):
        return [ self.link , ]

class ActInput( CompositeWidget ):
    def proc_extend( self ):
        #��Ҫ�˹�����һ��table����
        xml = render_string( """## coding: gbk
<?xml version="1.0" encoding="utf-8"?>
<table name="${ uniname }_table" pagesize='10' dp="${ dp }">
    <row onclick="${ uniname }_rowclick()">
% for c in fields:
        <col header="${ c.header }" w="${ c.width }" a="${ c.align }"> \\
% if c.name == bind:
<hidden name="${ c.name }"/> \\
% endif
<text name="${ c.name }"/></col>
% endfor
    </row>
</table>""" , uniname = self.uniname , dp = self.dp , fields = self.fields , bind = self.bind ).decode( 'gbk' ).encode( 'utf8' )
        self._proc_children( XML( xml ) )
        cf = self.treeobj.get_from_path( '/' ).value
        cf.actions[ self.uniname + '_select' ] = ActinputSelectAction( self.children[-1].uniname , self )
        cf.actions[ self.uniname + '_refresh' ] = ActinputRefreshAction( self )
        self.width = self.children[-1].width
#        cf.dataproviders[ self.dp ] = ActinputRefreshProvider( self )
    
    def proc_text( self , text ):
        self.desc = text

    def proc_attrib( self , attr ):
        self.fields = []
        super( ActInput , self ).proc_attrib( attr )
        self.dp = attr.get('dp','')
        self.bind = attr[ 'bind' ]
    
    def proc_children( self , c ):
        if c.tag.lower() == 'field':
            # �����ֶ�
            f = Field( c )
            if f.idx == -1:
                f.idx = self.fields[-1].idx + 1 if len( self.fields ) else 0
            self.fields.append( f )
        else:
            raise RuntimeError( 'ActInputֻ��ʹ��field���[%s]' % c.tag )
    
    def render( self , cf ):
        v = cf.get( self.name , typo = 'simple' , default = "" )
        return render_string( """#coding: gbk
<span id="${ uniname }" style="border:0px;">
<input type="text" id="${ uniname }_ipt" name="${ name }" onkeyup="${ uniname }_keyup()" \\
onclick="${ uniname }_click()" style="width:${ width };" value="${ value }" />
<div style="position:absolute;background-color:#FFFFFF; border:1px solid #bbb; margin-top:0; display:none;" id="${ uniname }_vision">
${substr}
</div>
</span>
""" , uniname = self.uniname ,name = self.name, substr = self.render_children( cf ) , width = self.width , value = v )

    def proc_js( self ):
        return render_string( """# coding: gbk
function ${ uniname }_keyup(){
    vi = $( "${ uniname }_vision" );
    showElement( vi );
    action_fire2( '${ uniname }_select' , '${ uniname }' , '${ uniname }' )
}

function ${ uniname }_click(){
    vi = $( "${ uniname }_vision" )
    ipt = $( "${ uniname }_ipt" )
    if ( getStyle( vi , 'display' ) == 'none' ){
        pos = getElementPosition( ipt );
        pos.y += ipt.offsetHeight;
        setElementPosition( vi , pos );
        showElement( vi );
    } else {
        hideElement( vi );
    }
}

function ${ uniname }_rowclick(){
    var e = event.srcElement;
    while ( e.tagName != 'TR' ){
        e = e.parentElement;
    }
    v = formContents( e );
    $( "${ uniname }_ipt" ).value = v[1];
    ${ uniname }_click();
}
""" , uniname = self.uniname )