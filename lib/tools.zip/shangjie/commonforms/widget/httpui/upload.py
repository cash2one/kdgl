# coding: gbk

from shangjie.commonforms.cfcore import BaseDataProvider , Action , ElementParse
from shangjie.commonforms.widget import CFWidget , CompositeWidget
from djangoext.mako import render_string
from xml.etree.ElementTree import XML
from cStringIO import StringIO
from pyExcelerator import parse_xls

class UploadFileDataProvider( BaseDataProvider ):
    def __init__( self , wdg ):
        self.upload = wdg
        self.once = False
    
    def subcall( self , cf ):
        return self.upload.dataprovider()

class UploadFileAction( Action ):
    def __init__( self , wdg ):
        self.link  = wdg.children[-1].uniname
        self.upload = wdg
        self.params = []
    
    def subcall( self , cf , **params ):
        self.upload.proc_file( cf )
        
    def get_link( self , cf ):
        return [ self.link , ]
    
class Upload( CompositeWidget ):
    """
        �����ϴ�����
        <upload name='' type='xls' header='' ac="">     # type = xls , csv�����ŷָ, txt�����߷ָ 
                                                        # header��ʾ��ͷ������Ҫ����
            <block></block>                             # �ṩ��������ķ�������
            <field type="str" name="xxx" header="yyy" w="" idx=0/>  # type = str , int , num , date , time
        </upload>
    """
    def proc_extend( self ):
        #��Ҫ�˹�����һ��table����
        xml = render_string( """<?xml version="1.0" encoding="utf-8"?>
<table name="${ uniname }_subtable" pagesize='13' dp="${ uniname }_values">
    <row>
% for c in fields:
        <col header="${ c.header }" w="${ c.width }"><text name="${ c.name }"/></col>
% endfor
    </row>
</table>""" , uniname = self.uniname , fields = self.fields ).decode( 'gbk' ).encode( 'utf8' )
        self._proc_children( XML( xml ) )
        # ��ȡ���ڵ㣨CF���󣩣������ӱ���ˢ�µ�Action
        cf = self.treeobj.get_from_path( '/' ).value
        cf.actions[ self.uniname + '_upload' ] = UploadFileAction( self )
        cf.dataproviders[ self.uniname + '_values' ] = UploadFileDataProvider( self )
        
    def proc_attrib( self , attr ):
        self.fields = []
        self.data = []
        super( Upload , self ).proc_attrib( attr )
        self.typo   = attr.get( 'type' , 'txt' )
        self.header = int( attr.get( 'header' , 0 ) )
        self.ac     = attr[ 'ac' ]
    
    def proc_children( self , c ):
        if c.tag.lower() == 'block':
            self._proc_children( c )
        elif c.tag.lower() == 'field':
            # �����ֶ�
            f = Field( c )
            if f.idx == -1:
                f.idx = self.fields[-1].idx + 1 if len( self.fields ) else 0
            self.fields.append( f )
        else:
            raise RuntimeError( 'Upload������block��ʹ�÷�field���[%s]' % c.tag )
    
    def render( self , cf ):
        return render_string( """# coding: gbk
<iframe id="${ uniname }_frame" name="${ uniname }_frame" style="{ position:absolute;top:-1000px;left:-1000px}">
</iframe>
<form action="/cf/subcall/${ uniname }_upload/" method="POST" name="${ uniname }" id="${ uniname }" enctype="multipart/form-data" target="${ uniname }_frame">
<input type="hidden" name="ref" value="sync"/>
<input type='hidden' name="fn" value="${ fn }">
<input id="${ uniname }_file" type="file" size="45" name="${ name }">
<input id="${ uniname }_preview" type="button" class="btn_2" value="Ԥ��" onclick="${ uniname }_pre()"/>
<input id="${ uniname }_submit" type="button" class="btn_2" value="�ύ" onclick="action_fire3( '${ ac }' , '${ uniname }' , '${ uniname }' )"/>
${ buf }
</form>
""" , uniname = self.uniname , name = self.name , buf = self.render_children( cf ) , ac = self.ac , fn = cf.fn )
    
    def proc_file( self , cf ):
        con = StringIO( cf.req.FILES[ self.name ][ 'content' ] )
        func = getattr( self , 'proc_' + self.typo )
        self.data=[]
        for line in func( cf , con ):
            self.data.append( line )
        
    def dataprovider( self ):
        return self.data
    
    def proc_xls( self , cf , con ):
        # ����excel�ļ�
        datas = parse_xls( con )[0][1]
        #���datas�к���u'\xa0'�����ı���ʱ��ȥ��
        tm = u'\xa0'
        for k,v in datas.items():
            try:
                if tm in v:
                    m = v.replace(tm,'')
                    datas[k]=m
            except:
                pass
        lineno = self.header 
        while True:
            d = {}
            for f in self.fields:
                d[ f.name ] = f.convert( datas.get( ( lineno , f.idx ) , None ) )
            if filter( None , d.values() ) == []:
                break
            yield d
            lineno += 1
            
    def proc_txt( self , cf , con ):
        # �������߷ָ��ı��ļ�
        co = con.getvalue()
        col = co.split('\n')
        lineno = self.header
        for c in col[lineno:]:
            id = 0
            d = {}
            c=c.strip()
            if len( c )==0:
                break
            c=c.split('|')
            for f in self.fields:
                try:
                    d[ f.name ] = f.convert( c[id].strip() )
                except:
                    try:
                        d[ f.name ] = c[id].strip()
                    except:
                        d[ f.name ] = ''
                id += 1
            yield d
    
    def proc_csv( self , cf , con ):
        # �������ŷָ��ı��ļ�
        pass
    
    def proc_js( self ):
        return render_string( """# coding: gbk
function ${ uniname }_pre(){
    windowload();
    connect( $( '${ uniname }_frame' ) , 'onload' , ${ uniname }_callback );
    $( '${ uniname }' ).submit()
};

function ${ uniname }_callback(){
    io = $( ${ uniname }_frame );
    json = evalJSON( io.self.document.body.innerText );
    if ( json[0] == true ){
        map( refresh , json[1] )
    } else {
        alert( 'ִ��[' + aname + ']�ӹ��ܴ���!\\n' + json[1] )
        windowunload();
    }
};

function action_fire3( aname , get , objname ){
    /*
        aname   ��������
        get     ��ȡ�������ݵĸ��ڵ㣨��ȡ��ʽ��ȡ������ÿ��Ԫ�ص�name:value�ԣ�
        objname ����Ԫ�ض�������ƣ����ں�̨��������
    */
    if ( get ){
        validate( $( get ) );
        if ( ! valided )
            return;
        
        values = formContents( $( get ) ); 
    } else {
        values = [ [] , [] ];
    }
    values[0].push( 'fn' , 'oname' , 'seed' );
    values[1].push( fn , objname , Math.random() );
    windowload();
    var d  = loadJSONDoc_post( '/cf/subcall/' + aname + '/' , values );
    d.addCallback( 
        function ( json ){
            try{
                if ( json[0] == true ){
                    alert("�ύ�ɹ�")
                    window.location.reload()
                } else {
                    alert( 'ִ��[' + aname + ']�ӹ��ܴ���!\\n' + json[1] );
                }
            } catch( e ){
                alert( e.message );
            }
            windowunload();
        } 
    ).addErrback( 
        function( msg ) {
            alert( 'ϵͳ���󣬸ù��ܺ�ִ̨�г���' );
            windowunload();
        }
    )
}
""" , uniname = self.uniname )
    
    def get_link( self ):
        self.data = []
        return [ self.uniname , ]
    
class Field( ElementParse ):
    def proc_attrib( self , attr ):
        self.typo = attr.get( 'type' , 'str' )
        self.header = attr.get( 'header' , '�ޱ�ͷ' )
        self.name = attr[ 'name' ]
        self.width = attr.get( 'w' , '200px' )
        self.align = attr.get( 'a' , 'center' )
        self.idx = int( attr.get( 'idx' , -1 ) )
    
    def convert( self , v ):
        if v:
            if self.typo == 'str':
                return v
            elif self.typo == 'int':
                return int( float(v) )
            elif self.typo == 'num':
                return float( v )
            elif self.typo == 'date':
                pass
            else:
                raise RuntimeError( '�ֶ����Ͳ��ɴ���[%s][%s][%s]' % ( self.name , self.typo , v ) )
        