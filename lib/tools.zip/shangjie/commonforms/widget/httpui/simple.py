# coding: gbk
from shangjie.commonforms.cfcore import BaseDataProvider , ElementParse, Action
from shangjie.commonforms.widget import CFWidget , ActionWidget , CompositeWidget
from djangoext.mako import render_string
from xml.etree.ElementTree import XML

class Button( ActionWidget ):    
    def proc_text( self , text ):
        self.desc = text.strip()
        self.params = {}
    
    def proc_children( self , c ):
        if c.tag.lower() == 'param':
            self.params[ c.attrib[ 'key' ] ] = c.text.strip() if c.text else ''
    
    def get_params( self ):
        return self.params
    
    def render( self , cf ):
        k = len( self.desc ) / 2
        if k >= 4:
            kls = 'btn'
        else:
            kls = 'btn_%s' % k
            
        return render_string( """#coding: gbk
<input type="button" id="${ uniname }" name="${ name }" value="${ desc }" class='${ kls }' ${ event }\\
% if ac:
onclick="action_fire( '${ ac }' , '${ get }' , '${ uniname }' )" \\
% endif
/>""" , uniname = self.uniname , name = self.name , desc = self.desc , ac = self.ac , get = self.get_form() , kls = kls , event = self.render_event() )

class Input( CFWidget ):
    def proc_attrib( self , attr ):
        super( Input , self ).proc_attrib( attr )
        self.width = attr.get( 'w' , '150px' )
        validate = attr.get( 'validate' , None )
        if validate:
            ins = """$( "%s" )""" % self.uniname
            pos = validate.index( '(' )
            if validate[ pos + 1 ] == ')':
                self.validate = "%s(%s" % ( validate[:pos] , ins , validate[pos+1:] )
            else:
                self.validate = "%s(%s,%s" % ( validate[:pos] , ins , validate[pos+1:] )
            self.validate = self.validate.replace( '"' , "'" )
        else:
            self.validate = None
            
    def proc_text( self , text ):
        self.default = text
    
    def render( self , cf ):
        if cf.first_widget is None:
            cf.first_widget = self.uniname
            
        value = cf.get( self.name , typo = 'simple' ) or self.default
        return render_string( """#coding: gbk
<input type='text' id="${ uniname }" name="${ name }" value="${ value }" ${ event } \\
% if validate:
validate="${ validate }" \\
% endif
style="width:${ width };"></input>""" , uniname = self.uniname , name = self.name ,
                                         value = value , width = self.width , validate = self.validate , event = self.render_event() )

class Select( ActionWidget ):
    pass

class Text( CFWidget ):
    
    def proc_attrib( self , attr ):
        super( Text , self ).proc_attrib( attr )
        self.talign = attr.get( 'a' )
        self.twidth = attr.get( 'w' )
    
    def proc_text( self , text ):
        self.default = text
        
    def render( self , cf ):
        value = cf.get( self.name , typo = 'simple' , default = self.default )
        return render_string( """#coding: gbk
<span id="${ uniname }" style="text-align:${ a };width:${ w };display:inline-block;vertical-align:top;" ${ event } >${ value }</span>""" , 
            uniname = self.uniname , value = value , event = self.render_event(),  a = self.talign , w = self.twidth )

class ComboBox( CFWidget ):
    
    def proc_text( self , text ):
        self.desc = text
    
    def proc_children( self , c ):
        if c.tag.lower() == 'value':
            par = c.attrib.get( 'at' , 'top' )
            if par == 'top':
                self.toplist.append([c.attrib['name'],c.text.encode( 'gbk' )])
            else:
                self.botlist.append([c.attrib['name'],c.text.encode( 'gbk' )])
    
    def proc_attrib( self , attr ):
        super( ComboBox , self ).proc_attrib( attr ) 
        self.toplist = []
        self.botlist = []
        self.dp = attr.get( 'dp' , None )
        
        self.width = attr.get( 'w', '150px' )
    
    def render( self , cf ):
        if cf.first_widget is None:
            cf.first_widget = self.uniname

        if self.dp:
            self.rs = cf.dataprovider(self.dp)
        v = cf.get( self.name , typo = 'simple' )
        def data():
            for x in self.toplist:
                yield x
            if self.rs:
                for row in self.rs:
                    for i,v in row.items():
                        yield i , v
            for x in self.botlist:
                yield x
            
        return render_string( """#coding: gbk
<select name="${ name }" id="${ uniname }" style="width:${ width };" ${ event }>
% for b in data:
  <option value="${ b[0] }" ${ 'selected' if b[0] == se else '' }> ${ b[1] } </option> 
% endfor
</select>
""" , uniname = self.uniname , name = self.name , data = data() , se = v , width = self.width, event = self.render_event() )

class Hidden( Input ):
    def render( self , cf ):
        value = cf.get( self.name , typo = 'simple' , default = self.default )
        return render_string("""#coding: gbk
<input type='hidden' id="${ uniname }" name='${ name }' value ="${ value }" ${ event }></input>""" , uniname = self.uniname ,name = self.name,  value = value , event = self.render_event() )

class Block( CompositeWidget ):
    
    def proc_attrib( self , attr ):
        super( Block , self ).proc_attrib( attr )
        
        self.position = attr.get( 'pos' , '' ).strip()
        if self.position:
            self.height, self.width, self.left, self.top = map( lambda a:a.strip(), self.position.split( "," ) )
        else:
            self.height, self.width, self.left, self.top = '' , '' , '' , ''
            
        self.border = attr.get( 'border' , '' ).strip() #"border:1px solid #DBEDEB;" if attr.get( 'border' ) == 'yes' else ""
        self.bcolor = attr.get( 'color' , '' ).strip()  #( "background-color: " + attr.get( 'color' ).strip() + ";" ) if attr.get( 'color' ).strip() else "background-color: #f1faf9;"
        
    def render( self , cf ):
        return render_string( """# coding: gbk
<div id="${ uniname }" \\
% if pos:
class="drag" \\
% endif
style="\\
% if pos:
height:${ height }; width:${ width }; left:${ left }; top:${ top };\\
% else:
word-wrap: normal; word-break: break-all; \\
% endif
% if border:
border:1px solid #DBEDEB; \\
% endif
% if color:
background-color: ${ color }; \\
% else:
background-color: #f1faf9; \\
% endif
">
${ children }
</div>""" , uniname = self.uniname , pos = self.position , 
            height = self.height , width = self.width , left = self.left , top = self.top , border = self.border , color = self.bcolor , 
            children = self.render_children( cf ) )

class PopupBlock( Block ):
    
    def proc_attrib( self, attr ):
        super( PopupBlock, self ).proc_attrib( attr )
        if self.parent != self.treeobj.get_from_path( '/' ).value:
            raise RuntimeError( "popupblock[%s]��Ǳ��������ڸ��ڵ�[%s]֮��" % ( self.name, self.treeobj.get_from_path( '/' ).value.name ) )
        
    def render( self, cf ):
        
        if self.position:
            return render_string( """# coding: gbk
<div id="${ uniname }" class="pblock" onselectstart="return false" style="height:${ height };width:${ width };left:${ left };top:${ top };${ border }${bcolor}" onmousedown="f_mdown(this)" onmousemove="f_move(this)" after_refresh="showPopupBlock">
    <div id="${ uniname }_title" class="pblock_title">
        <div style="float:right"><img src="/images/btn_close.gif" style="cursor:pointer" onClick="javascript:hidePopupBlock( $( '${ uniname }' ) )"/></div>
    </div>
    <div id='${ uniname }_content' class="pblock_content">
        ${ children }
    </div>
</div> """, uniname = self.uniname, height = self.height, width = self.width, left = self.left, top = self.top, border = self.border, bcolor = self.bcolor, children = self.render_children( cf ) )
        
        else:
            raise RuntimeError( "popupblock[%s]��Ǳ���ָ��position����" % self.name )