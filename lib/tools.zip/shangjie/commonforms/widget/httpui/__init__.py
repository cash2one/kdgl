# coding: gbk

import simple
import table
import upload
import actipt
import wizard