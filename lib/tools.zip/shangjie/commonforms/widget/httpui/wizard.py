# coding: gbk

from shangjie.commonforms.cfcore import BaseDataProvider , ElementParse, Action
from shangjie.commonforms.widget import CFWidget , ActionWidget , CompositeWidget
from djangoext.mako import render_string
from xml.etree.ElementTree import XML

class Wizard( CompositeWidget ):
    
    def proc_attrib( self , attr ):
        super( Wizard , self ).proc_attrib( attr )
        
        # Ĭ����ʾ��һҳ����ҳִ�����WizardAction
        self.curpage = 0 
        
        self.position = attr[ 'pos' ].strip()
        self.height, self.width, self.left, self.top = map( lambda a:a.strip(), self.position.split( "," ) )
        self.border = "border:1px solid #DBEDEB;" if attr.get( 'border' ).strip() == 'yes' else ""
        self.bcolor = ( "background-color: " + attr.get( 'color' ).strip() + ";" ) if attr.get( 'color' ).strip() else "background-color: #f1faf9;"
        
    def proc_children( self, c ):
        if c.tag.lower() == 'page':
            # ����ÿ��pageҳ
            self._proc_children( c )
        else:
            raise RuntimeError( 'WizardԪ���в��������з�page���[%s]' % c.tag )
        
    def render( self , cf ):
        # wizard��Ϊ���������������ָ��pos
        return render_string( """#coding: gbk
<div id="${ uniname }" class="drag" style="height:${ height }; width:${ width }; left:${ left }; top:${ top }; ${ border } ${ color }  " ${ event } >
${ substr }
</div>""", uniname = self.uniname, height = self.height, width = self.width, left = self.left, top = self.top, border = self.border, 
           color = self.bcolor, substr = self.children[ self.curpage ].render( cf ), event = self.render_event() )

            
class Page( CompositeWidget ):
    
    def proc_attrib( self , attr ):
        super( Page , self ).proc_attrib( attr )
        
        next = attr.get( 'next', '' )
        prev = attr.get( 'prev', '' )
        
        # ˳��ִ�У���һ��
        if ',' in next:
            self.next_name , self.next_action, self.next_shortcut = map( lambda x: x.strip() , next.encode( 'gbk' ).split( ',' ) )
        else:
            self.next_name = next.encode( 'gbk' ).strip()
            self.next_action = ''
            self.next_shortcut = ''
        if self.next_name:
            # ��ȡ���ڵ㣨CF���󣩣���������Ӧ��Action��ִ������߼�����ҳ��
            cf = self.treeobj.get_from_path( '/' ).value
            cf.actions[ self.uniname + '_next' ] = WizardAction( self.parent , 1 , self.next_action )
        
        # self.prev ��һ��
        if ',' in prev:
            self.prev_name, self.prev_action , self.prev_shortcut = map( lambda a: a.strip(), prev.encode( 'gbk' ).split( ',' ) )
        else:
            self.prev_name = prev.encode( 'gbk' ).strip()
            self.prev_action = ''
            self.prev_shortcut = ''
        if self.prev_name:
            cf = self.treeobj.get_from_path( '/' ).value
            cf.actions[ self.uniname + '_prev' ] = WizardAction( self.parent, -1, self.prev_action ) 
        
    def render( self , cf ):
        prev_shortcut_str = ( "(ALT+" + self.prev_shortcut + ")" ) if self.prev_shortcut else ''
        next_shortcut_str = ( "(ALT+" + self.next_shortcut + ")" ) if self.next_shortcut else ''
        
        prev_kls, next_kls = 'btn', 'btn'
        if self.next_name:
            next_kls = 'btn_shortcut' if len( self.next_name + next_shortcut_str ) / 2 >= 4 else 'btn_%s' % str( len( self.next_name + next_shortcut_str ) / 2 )
        if self.prev_name:
            prev_kls = 'btn_shortcut' if len( self.prev_name + prev_shortcut_str ) / 2 >= 4 else 'btn_%s' % str( len( self.prev_name + prev_shortcut_str ) / 2 )

        return render_string( """#coding: gbk
${ children }
% if next_name:
<span id="next" name="oper" style="position:absolute; right:20px; bottom:20px; height:24px; width:110px; text-align:right; border: 0px solid red;">
<input type="button" id="${ uniname }_next" name="${ uniname }_next" value="${ next_name }${ next_shortcut_str }" class="${ next_kls }" accessKey = "${ next_shortcut }" onclick="action_fire( '${ uniname }_next', '${ p_uniname }', '' )" >
</span>
% endif
% if prev_name:
<span id="prev" name="oper" style="position:absolute; right:180px; bottom:20px; height:24px; width:70px; text-align:left; border: 0px solid red;">
<input type="button" id="${ uniname }_prev" name="${ uniname }_prev" value="${ prev_name }${ prev_shortcut_str }" class="${ prev_kls }" accessKey = "${ prev_shortcut }"  onclick="action_fire( '${ uniname }_prev', '${ p_uniname }', '' )" >
</span>
% endif
""" , children = self.render_children( cf ), 
      uniname = self.uniname, next_name = self.next_name , next_kls = next_kls, p_uniname = self.parent.uniname, 
      prev_name = self.prev_name, prev_kls = prev_kls, next_shortcut = self.next_shortcut, prev_shortcut = self.prev_shortcut, 
      next_shortcut_str = next_shortcut_str, prev_shortcut_str = prev_shortcut_str ) 
        

class WizardAction( Action ):
    def __init__( self , link , delta , act ):
        self.link = link
        self.delta = delta
        self.act = act
        self.params = []

    def subcall( self , cf , **kwarg ):
        if self.act:
            # ִ��act
            ac = cf.actions.get( self.act , None )
            ac( cf )
            self.link.curpage += self.delta
        else:
            self.link.curpage += self.delta
            
    def get_link( self , cf ):
        return [ self.link.uniname , ]
  