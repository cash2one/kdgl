# coding: gbk
from foreseen_info.commonforms.cfcore import BaseDataProvider , ElementParse, Action
from foreseen_info.commonforms.widget import CFWidget , ActionWidget , CompositeWidget
from djangoext.mako import render_string
from xml.etree.ElementTree import XML

class Tanchu( CompositeWidget ):
    def render( self , cf ):
        return """
        <div id="%(uniname)s" class="gaizhe_1" _show="1"
        """%{'uniname':self.uniname} +""" style="left:35%;top:35%" > 
	<div id="p_title" class="gaizhe_2">
		<table cellpadding="0" cellspacing="0" border="0" width="100%">
        """ + """
			<tr>
				<td style="height:25px; background:url(/images/er.jpg); background-repeat:repeat-x;">
					<div id="p_biaoti" style=" float:left; padding-left:5px;">����</div>
					<div id="p_guanbi" style="float:right;"><img src="/images/qq.gif" style="padding:3px;" width="16" height="16" onclick="%(uniname)s_hidden();" /></div>
				</td>
			</tr>
			<tr>
				<td style="text-align:left;border:1px solid #638689;">
					
				</td>
			</tr>
		</table>
	</div>
	<div style=" float:left; margin-left:2px; margin-right:2px; font-family:'����'; font-size:12px; color:#000000; ">%(content)s</div>
</div>"""%{'uniname':self.uniname,'content':self.render_children( cf )}
    def proc_js( self ):
        return render_string( """# coding: gbk
        function ${ uniname }_show(){
        //��ʾҳ��
        popload( ${ uniname } )
        };
        function ${ uniname }_hidden(){
        //����ҳ��
        popunload( ${ uniname } )
        }
        """ , uniname = self.uniname )
