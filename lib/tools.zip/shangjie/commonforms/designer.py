# coding: gbk
import simplejson
from shangjie.conf import settings
from django.http import HttpResponse
import os

settings.check( 'DESIGNER_DIR' )

def text( re , fn ):
    # ����text����
    r = file( os.path.join( settings.DESIGNER_DIR , fn ) )
    return HttpResponse( simplejson.dumps( r.read() , ensure_ascii = False , encoding = 'gbk' ) )
