# coding: gbk

from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('',
    (r'^login/' , 'shangjie.commonforms.auth.login' ) ,
    (r'^main/' , 'shangjie.commonforms.auth.main' ) ,
    (r'^getmenu/' , 'shangjie.commonforms.auth.getmenu' ) ,
    (r'^quit/' , 'shangjie.commonforms.auth.quit' ) ,
    (r'^chgpwd/' , 'shangjie.commonforms.auth.chgpwd' ) ,
    (r'^status/' , 'shangjie.commonforms.auth.status' ) ,
    (r'^gngl/' , 'shangjie.commonforms.auth.gngl' ) ,
    (r'^entiretree/' , 'shangjie.commonforms.auth.entiretree' ) ,
    (r'^jsdy/' , 'shangjie.commonforms.auth.jsdy' ) ,
    (r'^allmenu/' , 'shangjie.commonforms.auth.allmenu' ) ,
    (r'^jsmenu/' , 'shangjie.commonforms.auth.jsmenu' ) ,
    (r'^menuobj/(.+)/' , 'shangjie.commonforms.auth.menuobj' ) ,
    (r'^newnod/' , 'shangjie.commonforms.auth.newnod' ) ,
    (r'^newjs/' , 'shangjie.commonforms.auth.newjs' ) ,
    (r'^jsfp/$' , 'shangjie.commonforms.auth.jsfp' ) ,
    # ͨ��¼�������ĵ������
    (r'^call/$' , 'shangjie.commonforms.cfcore.call' ) ,
    (r'^subcall/(.+)/$' , 'shangjie.commonforms.cfcore.subcall' ) ,
    (r'^subfresh/(.+)/$' , 'shangjie.commonforms.cfcore.subfresh' ) ,
    (r'^reportparams/' , 'shangjie.commonforms.ReportParamsAction.call' ) ,
    (r'^rptshow/' , 'shangjie.commonforms.ReportParamsAction.show' ) ,
    (r'^rptbridge/(.+)' , 'shangjie.commonforms.ReportParamsAction.bridge' ) ,
)