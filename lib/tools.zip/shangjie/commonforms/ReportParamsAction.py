# coding: gbk
from django.http import HttpResponse , HttpResponseRedirect
from djangoext.mako import render_to_response, render_to_string
from shangjie.conf import settings

settings.check( 'REPORTSVR' )

import xmlrpclib , urllib2

class ReportForm( object ):
    def __init__( self,req ):
        self.hydm = req.session[ 'hydm' ] 
        self.xm = req.session[ 'hyxm' ]
        self.jgdm = req.session[ 'jgdm' ]

    def ParseURL( self,req ):
        self.bbmc = req.GET.get( 'bbmc' ,None)
        self.level = req.GET.get( 'level' , None)
        if self.bbmc and self.level:
            s = xmlrpclib.ServerProxy( settings.REPORTSVR+'/RPC2' )
            v = s.getParameters( self.bbmc )
            if v:
                self.csdict = v[0]
                self.cslist = v[1]
                ypage = self.csdict.get('__ypage__',None) 
                cs = ','.join(self.cslist)
                obj = []
                for i in self.cslist:
                    type = self.csdict[ i ].get("type",None)
                    desc = self.csdict[ i ].get("desc",None)
                    vl   = self.csdict[ i ].get("valuelist",None)
                    if type == "hydm":
                        ret = self.Parsehydm()
                    elif type == "jgdm":
                        ret = self.Parsejgdm()
                    elif type == "jgdm_zy":
                        ret = self.Parsejgdm_zy()
                    elif vl!=[]:
                        ret = vl
                    else:
                        ret = {}
                    key = ( i , type , desc )
                    obj.append( { key : ret } )
                if obj:
                    return render_to_response( 'reportparams.html' , bbmc = self.bbmc, level = self.level, hydm = self.hydm ,jgdm = self.jgdm ,obj = obj,cs = cs,ypage = ypage  )
                else:
                    return HttpResponseRedirect( '/cf/rptshow/?bbmc=%s&ypage=%s' % (self.bbmc ,ypage) )
            else:
                raise RuntimeError("�����ļ�������ȡʧ�ܣ�����%s.ezdef��"%self.bbmc)    
        else:
            raise RuntimeError("�����ļ����͵ȼ�Ϊ��ѡ������")
                    
    def Parsehydm( self ):
        def todict( ret ):
            rsdict = {}
            for i in ret:
                rsdict[ i.hydm ] = i.xm
            return rsdict
        ret = {}
        s = settings.DB_SESSION()
        if self.level == 'qh':
            sql = "select hydm,xm from gl_hydy"
            ret = todict( s.execute( sql ))
        elif self.level == 'jg':
            sql = "select hydm,xm from gl_hydy where jgdm = '%s'" % self.jgdm
            ret = todict( s.execute( sql ))
        elif self.level == 'gr':
            ret = { self.hydm:self.xm }
        else:
            raise RuntimeError( 'hydm����û�д�Ȩ��')
        return ret
        
    def Parsejgdm( self ):
        def todict( ret ):
            rsdict = {}
            for i in ret:
                rsdict[ i.jgdm ] = i.jgmc
            return rsdict
        ret = {}
        s = settings.DB_SESSION()
        if self.level =='qh':
            sql = "select distinct ������ as jgdm,�������� as jgmc  from ��������.dbo.T_�û�_���� b  order by ������"
            sql = sql.decode('gbk')
            ret = todict( s.execute( sql ) )
        elif self.level == 'jg': 
            sql = "select distinct ������ as jgdm,�������� as jgmc  from ��������.dbo.T_�û�_���� b where  ������ = '%s' order by ������" % self.jgdm
            sql = sql.decode('gbk')
            print sql
            ret = todict( s.execute( sql ) )
        else:
            RuntimeError('jgdm����û�д�Ȩ��')
        return ret
    def Parsejgdm_zy( self ):
        def todict( ret ):
            rsdict = {}
            for i in ret:
                rsdict[ i.jgdm ] = i.jgmc
            return rsdict
        ret = {}
        s = settings.DB_SESSION()
        if self.level =='qh':
            sql = "select distinct ywjgdm as jgdm,jgmc from gl_jgdy where jgmc not like '%����%' and ywjgdm!='8888' order by ywjgdm"
            ret = todict( s.execute( sql ) )
        elif self.level == 'jg': 
            sql = "select distinct ywjgdm as jgdm,jgmc from gl_jgdy where ywjgdm='%s' order by ywjgdm" % self.jgdm
            sql = sql.decode('gbk')
            ret = todict( s.execute( sql ) )
        else:
            RuntimeError('jgdm����û�д�Ȩ��')
        return ret

def call( req ):
    f = ReportForm( req )
    return f.ParseURL( req )

def show( req ):
    bbmc = req.REQUEST.get( 'bbmc' , None)
    ypage = req.REQUEST.get( 'ypage' , None)
    if ypage[0] == '/':
        ypage = ypage[1:]
    uri = '/cf/rptbridge/'+ypage+"?rn="+bbmc
    cs = req.REQUEST.get( 'cs' , None )
    if cs:
        cs = cs.split(',')
        for i in cs:
            uri += '&'+i+'='+req.REQUEST.get(i,'') 
    return render_to_response( 'reportshow.html' , uri = uri )
    
def bridge( req , ypage ):
    uri = settings.REPORTSVR + ( '/' if settings.REPORTSVR[-1] != '/' else '' ) + ypage + '?' + req.META['QUERY_STRING']
    u = urllib2.urlopen( uri )
    s = u.read()
    return HttpResponse( s )