# coding: gbk
from django.conf import settings
from djangoext.urls import expose
from django.http import HttpResponseRedirect

from shangjie.egg_manage import plugin
from shangjie.utils import log

@expose( '^egg_manage/$' , tmpl = 'egg_manage/egg_list.html' , db = True )
def egg_list( sess , req ):
    eggs = plugin.list_eggs()
    db_eggs = sess.query( plugin.SJ_APPS ).order_by( plugin.SJ_APPS.mc ).all()
    # ����һ���ϲ����б�
    # �󽻼�
    es_map = {}
    for x in eggs:
        dd = es_map.get( x.common.name , [] )
        dd.append( x )
        dd.sort( key = lambda y:y.common.ver )
        es_map[ x.common.name ] = dd
        
    ds_map = dict( [ ( x.mc , x ) for x in db_eggs ] )
    es = set( es_map.keys() )
    ds = set( ds_map.keys() )
    ed = es - ds # ����
    # data
    data = []
    # �������ļ�
    es = list( ed )
    es.sort()
    for key in es:
        ee = es_map[ key ]
        for e in ee:
            data.append( ( e.common.name , e.common.ver , '' , e.common.desc , e.common.egg , [] , 'δ��װ' , 'orange' , [ '��װ' ] , e.deps.name ) )
    
    # ����
    for d in db_eggs:
        dv = str( d.ver() )
        zt = d.last()[-1]
        key = d.mc
        
        if key in es_map:
            # �ҵ��ļ�
            for e in es_map[ key ]:
                dd = [ d.mc , e.common.ver , d.ver() , d.desc() , e.common.egg , d.last() , '��' + zt , { '��װ':'green' , 'ж��': 'red' , '����':'green' }.get( zt , 'red' ) ]
                try:
                    if zt in ( '����' , '����' , '��װ' ):
                        if int( d.ver() ) > int( e.common.ver ):
                            # ���ݿ��еİ汾��
                            data.append( tuple( dd + [ [ '�������汾[%s]' % e.common.ver , 'ж��' ] , e.deps.name ] ) )
                        elif int( d.ver() ) == int( e.common.ver ):
                            data.append( tuple( dd + [ [ 'ж��' ] , e.deps.name ] ) )
                        elif int( d.ver() ) < int( e.common.ver ):
                            data.append( tuple( dd + [ [ '�������汾[%s]' % e.common.ver , 'ж��' ] , e.deps.name ] ) )
                    else:
                        data.append( tuple( dd + [ [ '��װ' ] , e.deps.name ] ) ) 
                except:
                    data.append( tuple( dd + [ [ '�����ļ��쳣' ] , e.deps.name ] ) )
        else:
            data.append( ( d.mc , "<span color='red'>�ļ�ȱʧ</span>" , d.ver() , d.desc() , d.egg() , d.last() , '��' + zt , 
                           { '��װ':'green' , 'ж��': 'red' , '����':'green' }.get( zt , 'red' ) , [ 'ɾ��' ] , '' ) )
    
    msg = req.GET.get( 'msg' )
    return dict( data = data , msg = msg )

def get_egg( mc , ver ):
    eggs = plugin.list_eggs()
    egg = None
    for x in eggs:
        if x.common.name == mc and str(x.common.ver) == ver:
            egg = x
            break
    
    return egg

@expose( '^install/' , preurl = 'egg_manage/' , db = True )
def install( sess , req ):
    mc = req.GET.get( 'mc' )
    ver = req.GET.get( 'ver' )
    egg = get_egg( mc , ver )
    msg = ''
    if egg:
        try:
            e = plugin.install( sess , egg , '' )
            # ��װ�������
            plugin.get_loader( e )( e )
        except RuntimeError , e:
            msg = e.args[0]
        except:
            log.exception( settings.LOG_MAIN , '��װӦ��[%s:%s]ʧ��' , mc , ver )
            msg = '��װӦ��[%s:%s]ʧ�ܣ���鿴��־' % ( mc , ver )
    return HttpResponseRedirect( '/egg_manage/' + ( ( '?msg=' + msg ) if msg else '' ) )

@expose( '^uninstall/' , preurl = 'egg_manage/' , db = True )
def uninstall( sess , req ):
    mc = req.GET.get( 'mc' )
    ver = req.GET.get( 'ver' )
    egg = get_egg( mc , ver )
    msg = ''
    if egg:
        try:
            plugin.uninstall( sess , egg , '' )
        except RuntimeError , e:
            msg = e.args[0]
        except:
            log.exception( settings.LOG_MAIN , 'ж��Ӧ��[%s:%s]ʧ��' , mc , ver )
            msg = 'ж��Ӧ��[%s:%s]ʧ�ܣ���鿴��־' % ( mc , ver )
            
    return HttpResponseRedirect( '/egg_manage/' + ( ( '?msg=' + msg ) if msg else '' ) )

@expose( '^downgrade/' , preurl = 'egg_manage/' , db = True )
def downgrade( sess , req ):
    mc = req.GET.get( 'mc' )
    ver = req.GET.get( 'ver' )
    egg = get_egg( mc , ver )
    msg = ''
    if egg:
        try:
            plugin.downgrade( sess , egg , '' )
        except RuntimeError , e:
            msg = e.args[0]
        except:
            log.exception( settings.LOG_MAIN , '����Ӧ��[%s:%s]ʧ��' , mc , ver )
            msg = '����Ӧ��[%s:%s]ʧ�ܣ���鿴��־' % ( mc , ver )
            
    return HttpResponseRedirect( '/egg_manage/' + ( ( '?msg=' + msg ) if msg else '' ) )
    
@expose( '^upgrade/' , preurl = 'egg_manage/' , db = True )
def upgrade( sess , req ):
    mc = req.GET.get( 'mc' )
    ver = req.GET.get( 'ver' )
    egg = get_egg( mc , ver )
    msg = ''
    if egg:
        try:
            plugin.upgrade( sess , egg , '' )
        except RuntimeError , e:
            msg = e.args[0]
        except:
            log.exception( settings.LOG_MAIN , '����Ӧ��[%s:%s]ʧ��' , mc , ver )
            msg = '����Ӧ��[%s:%s]ʧ�ܣ���鿴��־' % ( mc , ver )
            
    return HttpResponseRedirect( '/egg_manage/' + ( ( '?msg=' + msg ) if msg else '' ) )


@expose( '^del/' , preurl = 'egg_manage/' , tmpl = '' , db = True )
def aaa( sess , req ):
    return 'bbb'