# coding: gbk

# �ṩ�����з�ʽ����egg�Ľӿ�
import optparse 
class OptionParser (optparse.OptionParser):
    def check_required (self, opt):
        option = self.get_option(opt)
        if getattr(self.values, option.dest) is None:
            self.error("%s option not supplied" % option)

class FakeReq:
    def __init__( self , d = None ):
        self.GET = d or {}

from shangjie.conf import settings

def list():
    from shangjie.egg_manage import views
    se = settings.DB_SESSION()
    req = FakeReq()
    data = views.egg_list( se , req )[ 'data' ]
    fmt = '%15s %8s %8s %40s %15s %20s %10s'
    d = ( '����' , "�ļ��汾" , "��ǰ�汾" , '����' , "λ��" , '������ϵ' , '״̬' )
    print fmt % d
    for x in data:
        d = ( x[0] , x[1] , x[2] , x[3] , x[4] , x[-1] or '' , x[6] )
        print fmt % d
        
def install( mc , ver ):
    from shangjie.egg_manage import views , plugin
    se = settings.DB_SESSION()
    egg = views.get_egg( mc , ver )
    if egg:
        e = plugin.install( se , egg , 'admin' )
    else:
        print '�Ҳ���ָ���İ�װ��: %s,%s' % ( mc , ver )
def upgrade( mc , ver ):
    from shangjie.egg_manage import views , plugin
    se = settings.DB_SESSION()
    egg = views.get_egg( mc , ver )
    if egg:
        e = plugin.upgrade( se , egg , 'admin' )
    else:
        print '�Ҳ���ָ���İ�װ��: %s,%s' % ( mc , ver )
    
def uninstall( mc , ver ):
    from shangjie.egg_manage import views , plugin
    se = settings.DB_SESSION()
    egg = views.get_egg( mc , ver )
    if egg:
        e = plugin.uninstall( se , egg , 'admin' )
    else:
        print '�Ҳ���ָ���İ�װ��: %s,%s' % ( mc , ver )

def execute():
    op = OptionParser()
    op.add_option( "-s" , "--settings" , dest="settings",
                   help=u"�����ļ���Python·�����磺oa.oaconf" )
    op.add_option( "-c" , "--cmd" , dest="cmd", 
                   help=u"�������ƣ�������֧�ֵ������У�list , install , upgrade , uninstall" )
    op.add_option( "-e" , "--egg" , dest="egg",
                   help=u"��װ������" )
    op.add_option( "-v", "--ver" , dest="ver",
                   help=u"��װ���汾��" )
    (options, args) = op.parse_args()
    op.check_required( "-s" )
    op.check_required( "-c" )
    
    settings.register( options.settings )
    
    if options.cmd == 'list':
        list()
    else:
        if options.egg is None or options.ver is None:
            print '������: ��װ�����ƺͰ汾��'
        else:
            if options.cmd == 'install':
                install( options.egg , options.ver )
            elif options.cmd == 'upgrade':
                upgrade( options.egg , options.ver )
            elif options.cmd == 'uninstall':
                uninstall( options.egg , options.ver )
            else:
                print '��֧�ֵ�����: ' , op.cmd

if __name__ == '__main__':
    execute()
