# coding: gbk

from mako.template import Template
from mako.lookup import TemplateLookup

import posixpath , os , re
import py_compile
import zipfile
from Crypto.Cipher import DES3
import dict4ini

def mako_compile( ind , outd , myext = None ):
    # ind  ����Ŀ¼
    # outd ���Ŀ¼
    mako_lookup = TemplateLookup( directories=[ind] , disable_unicode=True )
    
    #outd = os.path.abspath( outd )
    ind = os.path.abspath( ind )
    # ����ind�е�ÿһ��ģ��
    for root, dirs, files in os.walk( ind ):
        #dirs.remove( '.svn' )
        #dirs.remove( '.cvs' )
        dn = root[len(ind):].split( os.sep )
        od = outd + root[len(ind):]
        if not os.path.isdir( od ):
            os.makedirs( od )
            f = file( os.path.join( od , '__init__.py' ) , 'w' )
            f.write( '# coding: gbk\n# auto generate make templates package\n' )
            f.close()
        valid_ext = [ '.html' , '.xml', '.js' ]
        if myext :
            valid_ext.extend( myext )
        
        for fn in files:
            if os.path.splitext( fn )[-1] in valid_ext:
                dn2 = dn + [fn]
                uri = '/'.join( dn2 )
                print uri
                template = mako_lookup.get_template(uri)
                dn2[-1] = ( fn.replace( '.' , '_' ) + '.py' )
                of = file( os.path.abspath( os.path.join( outd , *dn2 ) ) , 'w' )
                of.write( template.code )
                of.close()

def validext_filter( fn ):
    ext = os.path.splitext( fn )[-1]
    return ext in ( '.pyc' , '.html' )

def validext_filter2( fn ):
    ext = os.path.splitext( fn )[-1]
    return ext in ( '.py' , )

def add2zip( z , name , base , addsrc = False ):
    g = os.walk( name )
    base_path = name
    base += os.sep
    for root, dirs, files in g:
        if '.svn' in dirs:
            dirs.remove( '.svn' )
        if 'CVS' in dirs:
            dirs.remove( 'CVS' )
        if '.hg' in dirs:
            dirs.remove( '.hg' )
        
        print root
        fl = filter( validext_filter2 , files )
        for f in fl:
            fn1 = os.sep.join( ( root , f ) )       # py
            fn2 = os.sep.join( ( root , f + 'c' ) ) # pyc
            fn3 = os.sep.join( ( base + root[len(base_path):] , f + 'c' ) )  # short pyc
            fn4 = os.sep.join( ( base + root[len(base_path):] , f  ) )  # short py
            try:
                py_compile.compile( fn1 , fn2 , fn3 , True )
            except:
                import sys,traceback
                exc = sys.exc_info()
                print 'compile ' , fn1
                print exc[1].msg
                raw_input()
            z.write( fn2 , fn3 )
            if addsrc:
                z.write( fn1 , fn4 )

def build_zip( zfn , *args ):
    # ѹ���ļ���
    # ��Ҫѹ���ģ��Ŀ¼�Ͷ�Ӧ�ĸ�Ŀ¼
    z = zipfile.ZipFile( zfn , 'w' , zipfile.ZIP_DEFLATED )
    for x in args:
        add2zip( z , x[0] , base = x[1] )
    z.close()

# zip�ļ���ɣ���ʼ����
def encrypt( fn ):
    f = file( fn , 'r+b' )
    s = f.read()
    f.close()
    i = len(s)/8*8
    
    key = s[i-8:i]  # ȡ��8�ֽ�Ϊ��Կ
    key2 = key + key[4:8] + key[0:4] + key[2:6] + key[0:2] + key[6:8]
    d = DES3.new( key2 )
    b = d.encrypt( s[:i-8] )
    fn = fn.rsplit( "." , 1 )[0] + '.egg'
    f = file( fn , 'wb' )
    f.write( b )
    f.write( s[i-8:] )
    f.close()
    return fn
    
def decrypt( fn ):
    f = file( fn , 'r+b' )
    s = f.read()
    f.close()
    
    i = len(s)/8*8
    key = s[i-8:i]  # ȡ��8�ֽ�Ϊ��Կ
    key2 = key + key[4:8] + key[0:4] + key[2:6] + key[0:2] + key[6:8]
    d = DES3.new( key2 )
    b = d.decrypt( buf[:i-8] )
    f = file( fn.rsplit( "." , 1 )[0] + '.zip' , 'wb' )
    f.write( b )
    f.write(s[i-8:])
    f.close()

def build_ini( egg , name , desc = None , ver = 1 , deps = [] ):
    fn = egg.rsplit( "." , 1 )[0] + '.ini'
    d = dict4ini.DictIni()
    d.common.egg = egg
    d.common.name = name
    d.common.ver = ver
    if desc:
        d.common.desc = desc
    else:
        d.common.desc = '%s �汾��V%s' % ( name , ver )
    if deps:
        d.deps.name = ','.join( deps )
        
    d.setfilename( fn )
    d.save()
    del d

def build_egg( fn , name , desc = None , ver = 1 , deps = [] ):
    # fn  zip�ļ���
    # name ��������
    # entrnce ��ڣ���Ӧpluginģ��
    if type( fn ) is str:
        fn = encrypt( fn )
        if name:
            build_ini( fn , name , desc = desc , ver = ver , deps = deps )
    else:
        raise RuntimeError( '��������[%s]���������ļ���' % fn )

__all__ = [ 'mako_compile' , 'build_zip' , 'build_egg' ]


if __name__ == '__main__':
    build_zip( 'a.zip' , ( r'D:\projects\manacenter\shangjie\backplat' , 'b' ) )
    build_egg( 'a.zip' , '���԰� V1.0' , 'b.a' )