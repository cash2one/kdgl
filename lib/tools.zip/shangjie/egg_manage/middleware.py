# coding: gbk

import time
from django.conf import settings
from shangjie.utils import log
from shangjie.utils import cache
import uuid
from django.utils.cache import patch_vary_headers

class PluginMiddleware(object):
    LOADED = False
    
    def process_request(self, request):
        if not PluginMiddleware.LOADED:
            from shangjie.egg_manage import plugin
            plugin.load()
            PluginMiddleware.LOADED = True
