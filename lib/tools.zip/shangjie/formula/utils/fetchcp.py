# coding: gbk

# $Id: fetchcp.py 222 2008-05-19 15:45:30Z zhangjun $

from shangjie.utils.functools import register

@register( 'formula' )
def fetch( gInst , sql , cp , cpdm , key , val , idx = None ):
    gInst.log.info( "��ȡ[%s]����, ����[%s]�±�[%s]ִ��sql: %s" , cpdm , key , idx , sql )
    r = gInst.con.execute( sql )
    for row in r:
        _dm  = str( row[ key ] )
        if _dm == None:
            continue
        _val = []
        for k in val:
            if k:
                if k[0] in ( '-' , '+' ):
                    k = k[1:]
                _val.append( float( row[ k ] ) )
            else:
                _val.append( None )
        w = cp[ _dm ][ cpdm ]
        if idx:
            _idx = str( row[ idx ] )
            cpobj = w[ _idx ]
        else:
            cpobj = w[ '_' ]
        for i in range( len( _val ) ):
            v = _val[i]
            if v != None:
                op = val[i][0]
                if op == '+':
                    cpobj[i] += v
                elif op == '-':
                    cpobj[i] -= v
                else:
                    cpobj[i] = v

@register( 'formula' )
def fetch2cont( gInst , sql , cont , cpdm , val , idx = None ):
    gInst.log.info( "��ȡ[%s]����, �±�[%s]ִ��sql: %s" , cpdm , idx , sql )
    r = gInst.con.execute( sql )
    for row in r:
        _val = []
        for k in val:
            if k:
                if k[0] in ( '-' , '+' ):
                    k = k[1:]
                _val.append( float( row[ k ] ) )
            else:
                _val.append( None )
        w = cont[ cpdm ]
        if idx:
            _idx = str( row[ idx ] )
            cpobj = w[ _idx ]
        else:
            cpobj = w[ '_' ]
        for i in range( len( _val ) ):
            v = _val[i]
            if v != None:
                op = val[i][0]
                if op == '+':
                    cpobj[i] += v
                elif op == '-':
                    cpobj[i] -= v
                else:
                    cpobj[i] = v
