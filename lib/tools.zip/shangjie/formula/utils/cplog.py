# coding: gbk

# $Id: cplog.py 221 2008-05-19 12:36:22Z zhangjun $

# ��Ʒ��ֵ��log����

from datetime import datetime
import os

class CPLog:
    def __init__( self , gInst , ppath ):
        if not os.access( ppath , os.W_OK ):
            raise RuntimeError( '��־Ŀ¼[%s]���ɷ���' % ppath )
        d = datetime.now()
        self.ppath = os.path.join( ppath , gInst.modname + d.strftime( '%Y%m%d_%H%M%S' ) )
        os.mkdir( self.ppath )
        for subdir in [ 'rycp' , 'jgcp' , 'khcp' , 'zhcp' , 'qjcp' ]:
            os.mkdir( os.path.join( self.ppath , subdir ) )
        self._file = None
        self.content = []
    
    def begin( self , cplb , cpdm , idx = None ):
        # cplb Ϊrycp,jgcp��
        # cpdm 
        # idx  Ϊ��Ӧ����Ա��
        self.close()
        
        if idx:
            p = os.path.join( self.ppath , cplb , idx )
        else:
            p = os.path.join( self.ppath , cplb )
        
        if not os.access( p , os.W_OK ):
            os.makedirs( p )
        self._file = file( os.path.join( p , cpdm ) , 'w' )
    
    def close( self ):
        if self._file:
            map( self._file.write , map( str , self.content ) )
            self._file.close()
            self.content = []
    
    def read_cp( self , desc , dm , cpdm , idx , cpobj ):
        # �ϲ��ظ���
        #     ��鵱ǰ���ʵĲ�Ʒ[�±�]�Ƿ�������ȡ�ù�
        #     ���ȡ�ã����ҵ�����û�з���д���������������Ϊ��Щ��־���Ժϲ���һ��
        if cpdm is None:
            return
            
        for i in range( len( self.content ) - 1 , 0 , -1 ):
            t = self.content[i]
            if desc == t.desc and dm == t.dm and cpdm == t.cpdm and idx == t.idx:
                if not isinstance( t , ReadItem ):
                    # �й�д�����
                    break
                if idx == t.idx:
                    # ���Ժϲ�
                    return
        r = ReadItem( desc , dm , cpdm , idx , cpobj )
        self.content.append( r )
    
    def read_cpobj( self , desc , dm , cpdm , idx , zb , value ):
        if cpdm is None:
            return
            
        for i in range( len( self.content ) - 1 , 0 , -1 ):
            t = self.content[i]
            if isinstance( t , ReadItem ) and desc == t.desc and dm == t.dm and cpdm == t.cpdm and idx == t.idx :
                t.add_read( zb , value )
                
    def write_cp( self , desc , dm , cpdm , idx , cpobj , idx2 = None , v = None ):
        # д��������ϲ�
        if cpdm is None:
            return
            
        w = WriteItem( desc , dm , cpdm , idx , cpobj , idx2 , v )
        self.content.append( w )
    
    def write_cpwrap( self , cpwrap ):
        # д��wrap����
        if cpdm is None:
            return
            
        w = WriteWrap( cpwrap )
        self.content.append( w )
    
ZBMAP = [ 'zb' , ] + map( lambda x: 'zb%02d' % x , range( 2 , 21 ) )
class ReadItem:
    def __init__( self , desc , dm , cpdm , idx , cpobj ):
        self.desc = desc
        self.dm   = dm
        self.cpdm = cpdm
        self.idx  = idx
        self.scp  = repr( cpobj )
        self.reads = []
    
    def add_read( self , zb , value ):
        self.reads.append( '    %s=%s\n' % ( ZBMAP[zb] , value ) )
    
    def __str__( self ):
        return "��ȡ%s[%s]��Ʒ��%s[%s]\n    %s\n" % ( self.desc , self.dm , self.cpdm , self.idx , self.scp ) + "".join( self.reads )
        
class WriteItem:
    def __init__( self , desc , dm , cpdm , idx , cpobj , idx2 = None , v = None ):
        self.desc = desc
        self.dm   = dm
        self.cpdm = cpdm
        self.idx  = idx
        self.scp  = repr( cpobj )
        if idx2 is not None:
            self.details = '    %s=%s\n' % ( ZBMAP[idx2] , v )
        else:
            self.details = ''
    
    def __str__( self ):
        return "д��%s[%s]��Ʒ��%s[%s]\n    %s\n%s" % ( self.desc , self.dm , self.cpdm , self.idx , self.scp , self.details )

class WriteWrap:
    def __init__( self , cpwrap ):
        self.cpdm = cpwrap.cpdm
        self.desc = cpwrap.desc
        self.dm   = cpwrap.dm
        self.scp  = repr( cpwrap )
    
    def __str__( self ):
        return "д��%s[%s]��Ʒ��������%s\n    %s\n" % ( self.desc , self.dm , self.cpdm , self.scp )

class NullCPLog:
    def __init__( self ):
        pass
    
    def begin( self , *args ):
        pass
    
    def close( self ):
        pass
        
    def read_cp( self , desc , dm , cpdm , idx , cpobj ):
        pass
        
    def read_cpobj( self , desc , dm , cpdm , idx , zb , value ):
        pass
                
    def write_cp( self , desc , dm , cpdm , idx , cpobj , idx2 = None , v = None ):
        pass
    
    def write_cpwrap( self , cpwrap ):
        pass
