# -*- coding: gb2312 -*-
"""
    Copyright 2004 ��Ԫ�ţ���������Ϣ�������޹�˾��
    All right reserved.

    ͳ���෽����������
    AVG ��ƽ��ֵ
    SUM ���
    COUNT ������
    
    $Id: exutil.py 222 2008-05-19 15:45:30Z zhangjun $
"""
from shangjie.utils.functools import register

@register( 'formula' )
def AVG( li ):
    """
    ��ָ�������б���ƽ��ֵ
    @param li : �����б�
    """
    if len( li ) == 0:
        return 0
    return sum( li ) * 1.0 / len( li )

@register( 'formula' )
def AVG_CUT( li ):
    return AVG( _cut( li ) )

def _cut( li ):
    li.sort()
    if len(li) <= 3:
        return li
    return li[1:-1]

def _CPWRAP_AVG( cpwrap , filter = None , val = lambda cpobj: cpobj[ 'zb' ] ):
    li = []
    for idx , cpobj in cpwrap:
        if filter and ( not filter( cpobj ) ):
            continue
        li.append( val( cpobj ) )
    return li

@register( 'formula' )
def CPWRAP_AVG( cpwrap , filter = None , val = lambda cpobj: cpobj[ 'zb' ] ):
    li = _CPWRAP_AVG( cpwrap , filter , val )
    return AVG( li )

@register( 'formula' )
def CPWRAP_AVG_CUT( cpwrap , filter = None , val = lambda cpobj: cpobj[ 'zb' ] ):
    li = _CPWRAP_AVG( cpwrap , filter , val )
    return AVG( _cut( li ) )

def _CONT_AVG( cpcont , filter = None , val = lambda cpobj: cpobj[ 'zb' ] ):
    li = []
    for cpwrap in cpcont:
        if filter and ( not filter( cpwrap ) ):
            continue
        for cpdm , cpobj in cpwrap:
            li.append( val( cpobj ) )
    return li

@register( 'formula' )
def CONT_AVG( cpcont , filter = None , val = lambda cpobj: cpobj[ 'zb' ] ):
    li = _CPWRAP_AVG( cpcont , filter , val )
    return AVG( li )

@register( 'formula' )
def CONT_AVG_CUT( cpcont , filter = None , val = lambda cpobj: cpobj[ 'zb' ] ):
    li = _CPWRAP_AVG( cpcont , filter , val )
    return AVG( _cut( li ) )

def _CP_AVG( cp , filter = None ,val = lambda cpobj: cpobj[ 'zb' ] ):
    li = []
    for cpcont in cp:
        if filter and ( not filter( cpcont ) ):
            continue
        for cpdm , cpwrap in cpcont:
            for cpobj in cpwrap:
                li.append( val( cpobj ) )
    return li

@register( 'formula' )
def CP_AVG( cp , filter = None ,val = lambda cpobj: cpobj[ 'zb' ] ):
    li = _CP_AVG( cp , filter , val )
    return AVG( li )

@register( 'formula' )
def CP_AVG_CUT( cp , filter = None ,val = lambda cpobj: cpobj[ 'zb' ] ):
    li = _CP_AVG( cp , filter , val )
    return AVG( _cut( li ) )

@register( 'formula' )
def CPWRAP_SUM( cpwrap , filter = None , val = lambda cpobj: cpobj[ 'zb' ] ):
    li = []
    for cpdm , cpobj in cpwrap:
        if filter and ( not filter( cpobj ) ):
            continue
        li.append( val( cpobj ) )
    return li

@register( 'formula' )
def load( gInst , cpdm ):
    pass