# coding: gbk

from foreseen_info.conf import settings

settings.check( 'DB' , 'CPIDIR' )