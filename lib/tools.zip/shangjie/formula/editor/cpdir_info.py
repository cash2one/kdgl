# coding: gbk

"""
��Ʒ���Ա༭��
$Id: cpdir_info.py 222 2008-05-19 15:45:30Z zhangjun $
"""

import wx
import wx.lib.rcsizer  as rcs
import sys,traceback,os
import re

from shangjie.formula.utils.cpadmin import CPType , py2fun
from shangjie.formula.objs.desc import CPDir

from stc import createStyleCtrl

[ ACTION_SAVE ,
  ACTION_CANCEL ,
  ] = range( 2 )
  
class CPDirInfo( wx.Panel ):
    def __init__( self , parent ):
        wx.Panel.__init__( self , parent , -1 , style= wx.NO_BORDER )
        self.parent = parent

        sizer = rcs.RowColSizer()
        self.btnSave = wx.Button( self , ACTION_SAVE , "����" )
        self.btnCancel = wx.Button( self , ACTION_CANCEL , "ȡ��" )
        sizer.Add( self.btnSave , row=0 , col=3 )
        sizer.Add( self.btnCancel , row=1 , col=3 )
        # row 0
        sizer.Add( wx.StaticText( self , -1 , "���ƣ�" , size = ( 50 , -1 ) ) , row=0 , col=1 )
        self.cpdir_name = wx.TextCtrl( self , -1 )
        sizer.Add( self.cpdir_name , row=0 , col=2 , flag=wx.EXPAND )
        # row1
        sizer.Add( wx.StaticText( self , -1 , "˵����" , size = ( 50 , -1 ) ) , row=1 , col=1 )
        self.stc_note = createStyleCtrl( self )
        sizer.Add( self.stc_note , row=2 , col=1 , rowspan=20 , colspan=3, flag=wx.EXPAND )
        sizer.AddGrowableCol(2)
        sizer.AddGrowableRow(2)
        self.SetSizer( sizer )
        sizer.Fit( self )
        
        self.editObj = None
        self.treeitem = None
        
        self.Bind(wx.EVT_BUTTON, self.OnClick )
    
    def OnClick( self , evt ):
        id = evt.GetId()
        try:
            if id == ACTION_SAVE:
                self.Save()
            elif id == ACTION_CANCEL:
                self.UpdateUI()
        except RuntimeError , e:
            wx.MessageDialog( self, e.args[0], '����' , wx.OK | wx.ICON_ERROR ).ShowModal()
            
    def Save( self ):
        assert self.editObj is not None
        name = self.cpdir_name.GetValue().encode( 'gbk' )
        # �õ�������
        # ����޸������ƣ�����������Ƿ��ظ�, ���޸�����
        if self.editObj.name != name:
            pitem = self.parent.tree.GetItemParent( self.treeitem )
            pobj = self.parent.tree.GetPyData( pitem )
            if name in pobj.keys():
                raise RuntimeError( "�����ظ�, ���޸�����[%s]" % name )
            del pobj[ self.editObj.name ]
            self.editObj.name = name
            pobj.add( self.editObj )# �Ķ��±�
            self.parent.tree.SetItemText( self.treeitem , self.editObj.name )
        # 
        self.editObj.desc = self.stc_note.GetText().encode( 'gbk' ).replace( '\r\n' , '\n' ).strip()
        self.parent.modified()
        
    def UpdateUI( self ):
        self.cpdir_name.SetValue( "" )
        self.stc_note.ClearAll()
        
        self.cpdir_name.Enable( False )
        self.stc_note.Enable( False )
        
        self.treeitem = self.parent.tree.curitem
        self.editObj  = self.parent.tree.curitem_data

        if not ( self.editObj is None ):
            self.cpdir_name.SetValue( self.editObj.name )
            self.stc_note.AddText( self.editObj.desc )
            if self.editObj.root == False:
                self.cpdir_name.Enable( True )
                self.stc_note.Enable( True )
            
    
    def can_switch( self ):
        if self.editObj == None:
            return True
        
        bModified = False
        name = self.cpdir_name.GetValue().encode( 'gbk' ).upper()
        if name != self.editObj.name:
            bModified = True
        desc = self.stc_note.GetText().encode( 'gbk' ).replace( '\r\n' , '\n' ).strip()
        if desc != self.editObj.desc:
            bModified = True
        
        if bModified:
            # ��ʾ�Ƿ񱣴�, ������ʧ�����л�
            if wx.MessageDialog(self, "��ҳ���ڱ༭�Ķ����ѱ��ı�, �Ƿ񱣴�?", "��ʾ" , wx.YES_NO | wx.ICON_INFORMATION ).ShowModal() == wx.ID_YES:
                self.Save()
                return True
            else:
                return False
        return True

