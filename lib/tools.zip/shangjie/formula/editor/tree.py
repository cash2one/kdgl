# coding: gbk
"""
    Copyright 2004 ��Ԫ�ţ���������Ϣ�������޹�˾��
    All right reserved.

    ��Ʒ��������б�
    �����¸�ʽ����
    ��ƷĿ¼
        ��Ʒ����
        ��ƷĿ¼
            ��Ʒ����
    
    ��Ʒ��ֵ��
        ��Ʒ��ֵ������
    
    ����վ
    
    $Id: tree.py 222 2008-05-19 15:45:30Z zhangjun $
"""

import wx
import os,sys,traceback
import listdlg
from shangjie.formula.objs.desc import *

class ProductTree( wx.TreeCtrl ):
    def __init__( self , mainframe ):
        wx.TreeCtrl.__init__( self , mainframe , -1 , wx.DefaultPosition, ( 200 , 90 ) ,
                style= wx.TR_HAS_BUTTONS | wx.TR_HIDE_ROOT | wx.TR_LINES_AT_ROOT | wx.TR_FULL_ROW_HIGHLIGHT )
        # ����ROOT
        self.mainframe = mainframe
        self.root = self.AddRoot( 'must be hide' )
        
        self.Bind( wx.EVT_LEFT_DCLICK, self.OnLeftDClick )
        self.Bind( wx.EVT_TREE_BEGIN_DRAG , self.OnBeginDrag )
        self.Bind( wx.EVT_TREE_ITEM_RIGHT_CLICK , self.OnRightClick )
        self.Bind( wx.EVT_TREE_SEL_CHANGED , self.OnSelected )
        
        
        self.il = wx.ImageList(16,16)
        self.fldridx = self.il.Add(wx.ArtProvider_GetBitmap(wx.ART_FOLDER, wx.ART_OTHER, (16,16)))
        self.fldropenidx = self.il.Add(wx.ArtProvider_GetBitmap(wx.ART_FILE_OPEN, wx.ART_OTHER, (16,16)))
        self.fileidx = self.il.Add(wx.ArtProvider_GetBitmap(wx.ART_NORMAL_FILE, wx.ART_OTHER, (16,16)))
        self.SetImageList(self.il)
        
        self.Bind( wx.EVT_MENU , self.OnCreateCPDir , id = 201 )
        self.Bind( wx.EVT_MENU , self.OnCreateCPObj , id = 202 )
        self.Bind( wx.EVT_MENU , self.OnDeleteCPDir , id = 203 )
        self.Bind( wx.EVT_MENU , self.OnDeleteCPObj , id = 204 )
        
        self.Bind( wx.EVT_MENU , self.OnCreatePkg, id = 212  )
        self.Bind( wx.EVT_MENU , self.OnDeletePkg, id = 214  )
        
        self.curitem = None
        self.curitem_date = None
        
        self.recycle = None
        
        dt = CPDropTarget(self)
        self.SetDropTarget(dt)
        self.dragitem = None
        
    def OnRightClick( self , evt ):
        item = evt.GetItem()
        d = self.GetPyData( item )
        self.curitem = item
        self.curitem_data = d
        if type( d ) in ( CPDir , CPObjDesc ):
            if d.name == '����վ':
                return
            self.popup_menu_cp()
        elif type( d ) in ( PkgDir , PkgObj ):
            self.popup_menu_pkg()
    
    def OnSelected( self , evt ):
        item = evt.GetItem()
        try:
            d = self.GetPyData( item )
        except:
            return
        
        if self.curitem != item:
            # ѡ�����,��Ҫ����Ƿ���Ҫ���浱ǰ�༭�Ľ��
            if self.mainframe.currentpane:
                self.mainframe.currentpane.window.can_switch()
            
        self.curitem = item
        self.curitem_data = d
        if type( d ) in ( CPDir , PkgDir ):
            # ��ʾ��ƷĿ¼����
            self.mainframe.showPane( 'cpdir_info' )
            self.mainframe.cpdir_info.UpdateUI()
        elif type( d ) == PkgObj:
            # ��ʾ��Ʒ��ֵ������
            self.mainframe.showPane( 'pkg_info' )
            self.mainframe.pkginfo.UpdateUI()
        elif type( d ) == CPObjDesc:
            # ��ʾ��Ʒ��������
            self.mainframe.showPane( 'cp_info' )
            self.mainframe.info.UpdateUI()
        else:
            self.mainframe.showPane( None )
    
    def popup_menu_cp( self ):
        # ��Ʒ���󵯳��˵�
        oname = self.curitem_data.name
        menu = wx.Menu()
        menu.Append( 201 , "������ƷĿ¼" )
        menu.Append( 202 , "������Ʒ����" )
        menu.AppendSeparator()
        menu.Append( 203 , 'ɾ����ƷĿ¼[%s]' % oname )
        menu.Append( 204 , 'ɾ����Ʒ����[%s]' % oname )
        if type( self.curitem_data ) != CPDir:
            menu.Enable( 201 , False )
            menu.Enable( 202 , False )
            menu.Enable( 203 , False )
        else:
            menu.Enable( 204 , False )
            if self.curitem_data.root:
                menu.Enable( 203 , False )
                menu.Enable( 202 , False )

        self.PopupMenu( menu )
        menu.Destroy()
    
    def popup_menu_pkg( self ):
        # ��Ʒ���󵯳��˵�
        oname = self.curitem_data.name
        menu = wx.Menu()
        menu.Append( 212 , "������ֵ������" )
        menu.AppendSeparator()
        menu.Append( 214 , 'ɾ����ֵ������[%s]' % oname )
        if type( self.curitem_data ) != PkgDir:
            menu.Enable( 212 , False )
        else:
            menu.Enable( 214 , False )

        self.PopupMenu( menu )
        
        if type( self.curitem_data ) != PkgDir:
            menu.Enable( 212 , False )
        menu.Destroy()
    
    def OnCreateCPDir( self , evt ):
        try:
            obj = CPDir( "�½���ƷĿ¼" )
            self.curitem_data.add( obj )
            try:
                self.Freeze()
                last = self.AppendItem( self.curitem , obj.name , self.fldridx , self.fldropenidx )
                self.SetPyData( last , obj )
                self.SortChildren( self.curitem )
                self.Expand( self.curitem )
            finally:
                self.Thaw()
            
            self.mainframe.modified()
        except RuntimeError , e :
            self.MessageDlg( '����' , e.args[0] )
    
    def OnCompareItems( self , item1 , item2 ):
        d1 = self.GetPyData( item1 )
        d2 = self.GetPyData( item2 )
        r = 0
        if type( d1 ) == type( d2 ):
            return d1.name > d2.name
        elif type( d1 ) == CPDir:
            return -1
        elif type( d1 ) == PkgDir:
            return -1
        return 1
    
    def OnCreateCPObj( self , evt ):
        try:
            self.mainframe.data.check_unique( 'G_NEWCP' )
            obj = CPObjDesc( "G_NEWCP" , "�½���Ʒ����" )
            self.curitem_data.add( obj )
            try:
                self.Freeze()
                last = self.AppendItem( self.curitem , obj.get_lable() , self.fileidx , self.fileidx )
                self.SetPyData( last , obj )
                self.SortChildren( self.curitem )
            finally:
                self.Thaw()
                
            self.mainframe.modified()
            self.mainframe.data.cp_new( obj , self.curitem_data )
        except RuntimeError , e :
            self.MessageDlg( '����' , e.args[0] )
        
    def OnDeleteCPDir( self , evt ):
        try:
            if len( self.curitem_data ) > 0:
                raise RuntimeError( "��Ҫɾ����ƷĿ¼�ǿգ�������ո�Ŀ¼" )
            
            pitem = self.GetItemParent( self.curitem )
            d = self.GetPyData( pitem )
            
            del d[ self.curitem_data.name ] # ɾ���ö���
            self.Delete( self.curitem ) # ɾ���ؼ��еĽڵ�
            
            self.mainframe.modified()
        except RuntimeError , e :
            self.MessageDlg( '����' , e.args[0] )
        
    def OnDeleteCPObj( self , evt ):
        pitem = self.GetItemParent( self.curitem )
        d = self.GetPyData( pitem )
        
        self.mainframe.data.delete( self.curitem_data , d )
        self.Delete( self.curitem )
        
        try:
            self.Freeze()
            self.DeleteChildren( self.recycle )
            self.populate_item( self.recycle , self.mainframe.data.recycle )
        finally:
            self.Thaw()
        
        self.mainframe.modified()
    
    def OnCreatePkg( self , evt ):
        try:
            obj = PkgObj( "�½���Ʒ��ֵ��" )

            self.curitem_data.add( obj )
            try:
                self.Freeze()
                last = self.AppendItem( self.curitem , obj.name , self.fileidx , self.fileidx )
                self.SetPyData( last , obj )
                self.SortChildren( self.curitem )
                self.Expand( self.curitem )
            finally:
                self.Thaw()
            
            self.mainframe.modified()
        except RuntimeError , e :
            self.MessageDlg( '����' , e.args[0] )

    def OnDeletePkg( self , evt ):
        try:
            pitem = self.GetItemParent( self.curitem )
            d = self.GetPyData( pitem )
            
            del d[ self.curitem_data.name ] # ɾ���ö���
            self.Delete( self.curitem ) # ɾ���ؼ��еĽڵ�
            
            self.mainframe.modified()
        except RuntimeError , e :
            self.MessageDlg( '����' , e.args[0] )
    
    def OnBeginDrag( self , evt ):
        item = evt.GetItem()
        self.dragitem = None
        if item:
            d = self.GetPyData( item )
            if type( d ) == CPObjDesc:
                self.dragitem = item
                # ������ק����
                data = wx.TextDataObject( d.name )
                dropSource = wx.DropSource(self)
                dropSource.SetData(data)
                result = dropSource.DoDragDrop(wx.Drag_AllowMove)
    
    def PopulateAll( self , data ):
        """
            ���������
            �������
        """
        try:
            self.Freeze()
            queue = []
            self.DeleteChildren( self.root )
            if data is None:
                return
            
            last = self.AppendItem( self.root, data.cplist.name , self.fldridx , self.fldropenidx )
            self.SetPyData( last , data.cplist )
            queue.append( ( last , data.cplist ) )
            
            last = self.AppendItem( self.root, data.pkglist.name , self.fldridx , self.fldropenidx )
            self.SetPyData( last , data.pkglist )
            queue.append( ( last , data.pkglist ) )
            
            self.recycle = self.AppendItem( self.root , data.recycle.name , self.fldridx , self.fldropenidx )
            self.SetPyData( self.recycle , data.recycle )
            queue.append( ( self.recycle , data.recycle ) )
            
            while queue:
                treeitem , data = queue.pop(0) # �õ���һ���ڵ�
                # CPDir , PkgDir
                self.populate_item( treeitem , data )
        finally:
            self.Thaw()
    
    def populate_item( self , item , data ):
        queue = [ ( item , data ) ]
        while queue:
            item , data = queue.pop(0)
            for k , v in data.items():
                if type( v ) == CPDir or \
                   type( v ) == PkgDir:
                    last = self.AppendItem( item , v.name , self.fldridx , self.fldropenidx )
                    self.SetPyData( last , v )
                    queue.append( ( last , v ) )
                elif type( v ) in ( CPObjDesc , PkgObj ):
                    last = self.AppendItem( item , v.get_lable() , self.fileidx , self.fileidx )
                    self.SetPyData( last , v )
            self.SortChildren( item )
        

    def OnLeftDClick(self, event):
        pt = event.GetPosition();
        item, flags = self.HitTest(pt)
        if item:
            d = self.GetPyData( item )
            if type( d ) == CPObjDesc:
                try:
                    cplist = self.mainframe.data.find_ylcplist( d.name )
                    if len( cplist ) == 0:
                        raise RuntimeError( 'û���ҵ������ò�Ʒ[%s]�Ĳ�Ʒ����' % d.name )
                    i = 0
                    dmlist = {}
                    for obj , p in cplist:
                        dmlist[ i ] = ( obj.name , obj.cpmc , p )
                        i += 1
                    dlg = listdlg.CPListDialog( self , d.name , dmlist , '������Ʒ[%s]�Ĳ�Ʒ�б�' % d.name )
                    dlg.mainframe = self.mainframe
                    dlg.CenterOnScreen()
                    dlg.Show()
                except RuntimeError , e:
                    self.MessageDlg( '����' , e.args[0] )
        event.Skip()
    
    def MessageDlg( self , title , message ):
        dlg = wx.MessageDialog(self, message, title , wx.OK | wx.ICON_ERROR
                                   #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
            )
        dlg.ShowModal()
        dlg.Destroy()
    
    def DragDrop( self , x , y , text ):
        item , flag = self.HitTest( ( x , y ) )
        # 
        pobj = self.GetPyData( item )
        
        obj = self.GetPyData( self.dragitem )
        
        self.mainframe.data.move( obj , pobj.path )
        try:
            self.Freeze()
            self.Delete( self.dragitem )
            
            self.DeleteChildren( item )
            self.populate_item( item , pobj )
        finally:
            self.Thaw()
        # �����ǰ�ƶ��Ĳ�Ʒ����ǰѡ��Ĳ�Ʒ��������ˢ�µ�ǰѡ���Ʒ�Ľ����е������б��ؼ�
        # ע��ֻ��ˢ�¸ÿؼ���Ҫ�������޸ĵ�����
        if ( type( self.curitem_data ) == CPObjDesc ) and \
           ( obj.name in self.curitem_data.ylcplb ):
            self.mainframe.info.refresh_ylcplb( self.mainframe.info.getCPList() )
        
        if type( self.curitem_data ) == PkgObj:
            self.mainframe.pkginfo.refresh_ylcplb()
        
        self.mainframe.modified()
        
    def testCanDrag( self , x , y ):
        item , flag = self.HitTest( ( x , y ) )
        try:
            d = self.GetPyData( item )
            o = self.GetPyData( self.dragitem )
            if type( d ) == CPDir and \
               d != self.mainframe.data.cache[ o.name ][1] and \
               not d.root:
                return wx.DragMove
        except:
            pass
            
        return wx.DragNone
    
    def select( self , path , obj ):
        self.Freeze()
        try:
            ps = path.split( '/' )
            ps.append( obj.get_lable() )
            item = self.root
            for p in ps[1:]:
                citem , cookie = self.GetFirstChild( item )
                bFound = False
                while citem:
                    t = self.GetItemText( citem ).encode( 'gbk' )
                    if t == p:
                        item = citem
                        bFound = True
                        break
                    citem , cookie = self.GetNextChild( citem , cookie )
                if not bFound:
                    break
            if bFound:
                self.SelectItem( item , True )
            else:
                citem , cookie = self.GetFirstChild( item )
                if citem.IsOk():
                    self.SelectItem( citem , True ) # ѡ���һ����
                    item = citem
                else:
                    self.SelectItem( item , True ) # ѡ���һ����
        finally:
            self.Thaw()
    
class CPDropTarget(wx.TextDropTarget):
    def __init__(self, window):
        wx.TextDropTarget.__init__(self)
        self.window = window

    def OnDropText(self, x, y, text):
        self.window.DragDrop( x , y , text.encode( 'gbk' ) )

    def OnDragOver(self, x, y, d):
        return self.window.testCanDrag( x , y )