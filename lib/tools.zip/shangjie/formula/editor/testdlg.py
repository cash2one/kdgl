# coding: gbk

""" ��Ʒ������ԶԻ���
$Id: testdlg.py 222 2008-05-19 15:45:30Z zhangjun $
"""

import sys,os,traceback

import wx
from wx.lib import layoutf
import wx.lib.rcsizer  as rcs
import wx.stc as stc
from stc import createStyleCtrl

import logging
import datetime

from pkginfo import tjszq
import thread
import wx.lib.intctrl  as intctrl
from listdlg import getSmallUpArrowBitmap , getSmallDnArrowBitmap
import  wx.lib.mixins.listctrl  as  listmix
import listdlg
from shangjie.conf import settings
from shangjie.utils import globaldata , functools , package
from shangjie.formula.utils.cpadmin import CPType
from shangjie.formula.utils import comm

class PkgTestDialog( wx.Dialog ):
    def __init__( self, parent, qzobj ):
        self.parent = parent
        self.qzobj  = qzobj
        wx.Dialog.__init__( self , parent , title='��Ʒ��ֵ��[%s][%s]�������' % ( qzobj.get_lable() , qzobj.jszq ) , 
                            style = wx.MINIMIZE_BOX | wx.MAXIMIZE_BOX | wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER )
        
        # ���ݳ�ʼ��
        self.qzmc = qzobj.name
        self.jszq = qzobj.jszq
        
        sizer = rcs.RowColSizer()
        # 1
        sizer.Add( wx.StaticText(self,-1,"��������") , row=0 , col=0 )
        self.zqdm = wx.TextCtrl(self,-1,size=( 200 , -1 ) )
        sizer.Add( self.zqdm , row=0 , col=1 , flag=wx.EXPAND )
        self.btnTest = wx.Button( self , -1 , "����" )
        sizer.Add( self.btnTest , row=0 , col=2 , flag=wx.ALIGN_RIGHT )
        
        # 2
        sizer.Add( wx.StaticText(self,-1,"""ע��: �����Ĳ�Ʒ���ݽ����д����Կ���, ������У�����Ƿ���ȷ""") , row=1,col=0 , colspan=3 , flag=wx.EXPAND )
        # 3
        sizer.Add( wx.StaticText(self,-1,"��־: ") , row=2,col=0,colspan=2,flag=wx.EXPAND )
        self.v1 = wx.CheckBox( self , -1 , "д������������Կ�" )
        sizer.Add( self.v1 , row=2 , col=2 , flag=wx.ALIGN_RIGHT )
        self.v1.SetValue( False )
        # 4 
        self.log = stc.StyledTextCtrl(self,-1,size=( 600 , 300 ) )
        #self.log.Disable()
        #self.log.SetReadOnly( True )
        sizer.Add( self.log , row=3,col=0,colspan=3,flag=wx.EXPAND )
        
        sizer.AddGrowableCol(1)
        sizer.AddGrowableRow(3)
        self.SetSizer( sizer )
        sizer.Fit( self )
        self.Bind(wx.EVT_BUTTON ,self.OnTest , self.btnTest )
        self.Bind(wx.EVT_CLOSE , self.OnClose )
        self.lock = thread.allocate_lock()
        self.dlg = ModuleDialog( self, 'shangjie.backplat.modules\nhuaxia.backdata', "�༭��չ���б�" )

    
    def write( self , l ):
        try:
            self.lock.acquire()
            self.log.Freeze()
            self.log.AddText( l )
            self.log.StutteredPageDown()
            self.log.Thaw()
        finally:
            self.lock.release()
    
    def OnClose( self , evt ):
        if self.IsModal():
            self.EndModal(wx.ID_OK)
        else:
            self.Destroy()
    
    def OnTest( self , evt ):
        self.dlg.ShowModal()
        self.log.Disable()
        self.log.ClearAll()
        logger = logging.getLogger( 'test' )
        logger.handlers = []
        # ��ʼ����Ļ��ӡ�������
        hdlr = logging.StreamHandler( PseudoFileOut( self.write ) )
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        hdlr.setFormatter(formatter)
        logger.addHandler( hdlr )
        
        zqdm = self.zqdm.GetValue().encode( 'gbk' ).strip()
        if not zqdm:
            logger.error( "���������������" )
            return
        gInst = globaldata.globaldata()
        gInst.log = logger
        if self.jszq == '��':
            # �����ջ��ܣ�����ָ�����ڷ�Χ �ո�ָ����������
            if ' ' in zqdm:
                # �����ڷ�Χ�����㿪ʼ���ںͽ�������
                ksrq , jsrq = zqdm.split()
                try:
                    ksrq = functools.str2dt( ksrq , '%Y%m%d' )
                except:
                    logger.error( '����ֵ�������ջ���, �������ʽΪ[YYYYMMDD]����������, %s' , zqdm )
                    return
                try:
                    jsrq = functools.str2dt( jsrq , '%Y%m%d' )
                except:
                    logger.error( '����ֵ�������ջ���, �������ʽΪ[YYYYMMDD]����������, %s' , zqdm )
                    return
            else:
                try:
                    curdate = functools.str2dt( zqdm , '%Y%m%d' )
                except:
                    logger.error( '����ֵ�������ջ���, �������ʽΪ[YYYYMMDD]����������, %s' , zqdm )
                    return
                ksrq = jsrq = curdate
        else:
            if ( zqdm[0] == 'M' and self.jszq != '��' ) or \
               ( zqdm[0] == 'Q' and self.jszq != '��' ) or \
               ( zqdm[0] == 'B' and self.jszq != '����' ) or \
               ( zqdm[0] == 'Y' and self.jszq != '��' ) or \
               ( zqdm[0] == 'Z' and self.jszq != '�Զ���' ):
                logger.error( '��ֵ������[%s]��ĩ����, ��ȷ��������ȷ, %s' , self.jszq , zqdm )
                return
            r = con.execute( "select * from zd_sjzq where zqdm = %s" , zqdm )
            row = r.fetchone()
            if row:
                gInst.zqdm = zqdm
                curdate = row.zqjsrq
            else:
                logger.error( '��������ڴ���[%s]�Ƿ�, �޷��������ڶ���' , zqdm )
                return

        self.btnTest.Disable()
        # 
        logger.setLevel( logging.DEBUG )
        def run( curdate ):
            #
            gInst.curdate = curdate
            gInst.dqkhq.reset()
            
            r = comm.FormulaRunner( files = {'test':[self.qzobj.name]} , cpdesc = {'test':self.parent.data } )
            
            gInst.modname = 'test'
            gInst.log.info( '���Կ�ʼ: ��������[%s]��ǰ������[%s]' , gInst.curdate.strftime( '%Y%m%d' ) , gInst.dqkhq )
            try:
                r.run( gInst , test = True )
            except:
                typ, value, tb = sys.exc_info()
                lst = traceback.format_tb(tb) + traceback.format_exception_only(typ, value)
                gInst.log.error( '���Խ���, �����쳣:\n%s' , ''.join( lst ) )
        
        def runsingle( curdate ):
            run( curdate )
            self.btnTest.Enable()
            self.log.Enable()
        
        def runmulti( ksrq , jsrq ):
            curdate = ksrq
            while curdate <= jsrq:
                run( curdate )
                curdate += datetime.timedelta(1)
            self.btnTest.Enable()
            self.log.Enable()
            
        if self.jszq == '��':
            thread.start_new_thread( runmulti , ( ksrq , jsrq ) )
        else:
            thread.start_new_thread( runsingle , ( curdate ) )


class ModuleDialog(wx.Dialog):
    def __init__(self, parent, msg, caption,
                 pos=wx.DefaultPosition, size=(500,300),
                 style=wx.DEFAULT_DIALOG_STYLE):
        wx.Dialog.__init__(self, parent, -1, caption, pos, size, style)
        x, y = pos
        if x == -1 and y == -1:
            self.CenterOnScreen(wx.BOTH)

        self.text = wx.TextCtrl(self, -1, msg, 
                           style=wx.TE_MULTILINE )

        ok = wx.Button(self, wx.ID_OK, "OK")
        ok.SetDefault()
        lc = layoutf.Layoutf('t=t5#1;b=t5#2;l=l5#1;r=r5#1', (self,ok)) 
        self.text.SetConstraints(lc)

        lc = layoutf.Layoutf('b=b5#1;x%w50#1;w!80;h*', (self,))
        ok.SetConstraints(lc)
        self.SetAutoLayout(1)
        self.Layout()
        
        self.Bind(wx.EVT_BUTTON ,self.OnClose , ok )

    def OnClose( self , evt ):
        import cStringIO
        s = cStringIO.StringIO( self.text.GetValue().encode( 'gbk' ) )
        for x in s:
            x = x.strip()
            if x:
                print `x`
                package.load_module( str(x) )
            
        self.EndModal( 0 )

class PseudoFile:
    def __init__(self):
        pass
    def readline(self):
        pass
    def write(self, s):
        pass
    def writelines(self, l):
        map(self.write, l)
    def flush(self):
        pass
    def isatty(self):
        pass

class PseudoFileOut(PseudoFile):
    def __init__(self, write):
        if callable(write):
            self.write = write
        else:
            raise ValueError, 'write must be callable'
    def isatty(self):
        return 1

class MyApp(wx.App):
    """This class is even less interesting than MyFrame."""

    def OnInit(self):
        """OnInit. Boring, boring, boring!"""
        dlg = PkgTestDialog( None , 'test' , '����' , 1 , '��' )
        dlg.ShowModal()
        return False

def main():
    app = MyApp(False)
    app.MainLoop()


if __name__ == '__main__':
    main()
