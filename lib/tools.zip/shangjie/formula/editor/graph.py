# coding: gbk
# $Id: graph.py 222 2008-05-19 15:45:30Z zhangjun $

import sys,os,traceback

import wx
import wx.lib.rcsizer  as rcs
from stc import createStyleCtrl

from shangjie.formula.utils import cpadmin
from shangjie.formula.editor import pydot
import cStringIO
import  wx.lib.scrolledpanel as scrolled

class GraphDialog( wx.Dialog ):
    def __init__( self, parent ):
        self.parent = parent
        wx.Dialog.__init__( self , parent , title='��Ʒ����·��ͼ' , style =wx.MINIMIZE_BOX | wx.MAXIMIZE_BOX | wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER )
        
        sizer = rcs.RowColSizer()
        sizer.Add( wx.StaticText(self, -1, "��ֵ��Ʒ��" , size=(100,-1) ) , row=0,col=0 )
        self.cplb = wx.TextCtrl( self , -1 , size=(350,-1) )
        sizer.Add( self.cplb , row=0 , col=1 , flag=wx.EXPAND )
        
        self.btnApply = wx.Button( self , wx.ID_APPLY , "����" )
        self.btnApply.SetDefault()
        sizer.Add( self.btnApply , row=0 , col=2 , flag=wx.ALIGN_CENTER )
        self.zoom = wx.Slider(self, 100, 100, 50, 100,style=wx.SL_HORIZONTAL | wx.SL_AUTOTICKS | wx.SL_LABELS)
        self.zoom.SetTickFreq(5, 1)
        sizer.Add( self.zoom , row=0 , col=3 , rowspan=2 , flag=wx.EXPAND )
        box = wx.BoxSizer(wx.HORIZONTAL)
        self.v1 = wx.CheckBox(self, -1, "��ʾ��ֵ˳��" )
        self.v2 = wx.CheckBox(self, -1, "��ʾ������ϵ" )
        self.v3 = wx.CheckBox(self, -1, "��ʾ������Ʒ" )
        self.v1.SetValue( True )
        self.v2.SetValue( True )
        self.v3.SetValue( False )
        box.Add( self.v1 )
        box.Add( self.v2 )
        box.Add( self.v3 )
        sizer.Add( box , row=1 , col=1 )
        self.sp = scrolled.ScrolledPanel(self, -1 , style=wx.SUNKEN_BORDER )
        sizer.Add( self.sp , row=2 , col=0 , rowspan= 10 , colspan=4 , flag=wx.EXPAND )
        self.sp.SetupScrolling()
        #print dir( self.sp )
        self.image = wx.StaticBitmap( self.sp , -1 )
        self._img = None
        
        sizer.AddGrowableCol(1)
        sizer.AddGrowableRow(2)
        self.SetSizer(sizer)
        sizer.Fit(self)
        
        self.Bind(wx.EVT_SCROLL , self.OnZoom )
        self.Bind(wx.EVT_BUTTON, self.OnClick , self.btnApply )
        #self.Bind(wx.EVT_CLOSE , self.OnClose )
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox )
    
    def OnCheckBox( self , evt ):
        self.MakeGraph( self.cpdmlist )
    
    def OnZoom( self , evt ):
        a = self.zoom.GetValue()
        if self._img:
            if a < 100:
                img = self._img.Scale( int(self._img.GetWidth() * a/100.0) , int(self._img.GetHeight() * a/100.0) )
            else:
                img = self._img
            bmp = img.ConvertToBitmap()
            self.image.SetBitmap( bmp )
            self.image.SetSize( ( bmp.GetWidth(), bmp.GetHeight() ) )
            self.sp.SetVirtualSize( ( bmp.GetWidth(), bmp.GetHeight() ) )
            self.sp.Refresh()
    
    def OnClick( self , evt ):
        id = evt.GetId()
        if id == wx.ID_APPLY:
            self.MakeGraph( self.cpdmlist )
    
    def MakeGraph( self , cpdmlist ):
        map = cpadmin._buildCPMap( { 'test':self.parent.data } )
        gjcpmap = {}
        self.cpdmlist = cpdmlist
        for cpdm in cpdmlist:
            gjcpmap[ cpdm ] = map[ cpdm ]

        gjcplist = cpadmin.GJCPCalcList( gjcpmap )
        stream = cStringIO.StringIO()
        s2     = cStringIO.StringIO()
        stream.write( "digraph G {\n" )
        pre = None
        i = 0
        showCal = self.v1.GetValue()
        showDep = self.v2.GetValue()
        showJC  = self.v3.GetValue()
        for cpt in gjcplist.cplist:
            s2.write( '%s [label="%s(%d)"];\n' % ( cpt.cpdm , cpt.cpdm , i ) )
            if pre and showCal:
                stream.write( "%s -> %s[color=red];\n" % ( cpt.cpdm , pre.cpdm ) )
            if showDep:
                for cc in cpt.ylcplb:
                    if ( not showJC ) and cc[0] == 'J':
                        continue
                    stream.write( "%s -> %s;\n" % ( cpt.cpdm , cc ) )
            pre = cpt
            i += 1
        stream.write( s2.getvalue() )
        stream.write( "}" )
        g = pydot.graph_from_dot_data( stream.getvalue() )
        g.write_gif( r"a.gif" )
        self._img = wx.Image(r'a.gif', wx.BITMAP_TYPE_GIF)
        self.OnZoom( None )
            
class MyApp(wx.App):
    """This class is even less interesting than MyFrame."""

    def OnInit(self):
        """OnInit. Boring, boring, boring!"""
        dlg = GraphDialog( None )
        dlg.ShowModal()
        return False

def main():
    app = MyApp(False)
    app.MainLoop()


if __name__ == '__main__':
    main()
