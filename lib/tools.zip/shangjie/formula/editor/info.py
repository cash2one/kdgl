# coding: gbk

"""
��Ʒ���Ա༭��
$Id: info.py 222 2008-05-19 15:45:30Z zhangjun $
"""

import wx
import wx.lib.rcsizer  as rcs
import sys,traceback,os
import re
import sets

from shangjie.formula.utils.cpadmin import CPType , py2fun
from shangjie.formula.objs.desc import CPObjDesc
from shangjie.formula.editor.stc import createStyleCtrl
from shangjie.formula.editor import listdlg

import wx.lib.intctrl  as intctrl
import  wx.lib.mixins.listctrl  as  listmix

[ ACTION_YXJS_TEST , 
  ACTION_SAVE ,
  ACTION_CANCEL ,
  ACTION_DELETE_YL ] = range( 4 )
  
class ObjInfo( wx.Panel , listmix.ColumnSorterMixin ):
    def __init__( self , parent ):
        wx.Panel.__init__( self , parent , -1 , style= wx.NO_BORDER )
        self.parent = parent
        sizer = rcs.RowColSizer()
        self.btnSave = wx.Button( self , ACTION_SAVE , "����" )
        self.btnCancel = wx.Button( self , ACTION_CANCEL , "ȡ��" )
        sizer.Add( self.btnSave , row=0 , col=3 )
        sizer.Add( self.btnCancel , row=2 , col=3 )
        sizer.Add( wx.StaticText( self , -1 , "��ǰ��Ʒ��" , size = ( 100 , -1 ) ) , row=0 , col=1 )
        self.cpzl = wx.StaticText( self , -1 , "��ǰδѡ���Ʒ" ) 
        sizer.Add( self.cpzl , row=0 , col=2 , flag=wx.EXPAND )
        sizer.Add( wx.StaticText( self , -1 , "��Ʒ���룺" ) , row=1 , col=1 )
        self.cpdm = wx.TextCtrl( self , -1 )
        sizer.Add( self.cpdm , row=1 , col=2 , flag=wx.EXPAND )
        sizer.Add( wx.StaticText( self , -1 , "��Ʒ���ƣ�" ) , row=2 , col=1 )
        self.cpmc = wx.TextCtrl( self , -1 )
        sizer.Add( self.cpmc , row=2 , col=2 , flag=wx.EXPAND )
        sizer.Add( wx.StaticText( self , -1 , "������ʽ��" ) , row=3 , col=1 )
        self.gsfs = wx.ComboBox(self, -1, '��Ա' , (100, -1), choices = [ 'ȫ��' , '��Ա' , '����' , '�ͻ�' , '�˻�' ] , style = wx.CB_READONLY )
        sizer.Add( self.gsfs , row=3 , col=2 )
        sizer.Add( wx.StaticText( self , -1 , "���㷽ʽ��" ) , row=4 , col=1 )
        self.sfqj = wx.ComboBox(self, -1, '��Ա' , (100, -1), choices = [ 'ȫ��' , '��Ա' , '����' , '�ͻ�' , '�˻�' , '������' ] , style = wx.CB_READONLY )
        sizer.Add( self.sfqj , row=4 , col=2 )
        sizer.Add( wx.StaticText( self , -1 , "������Ʒ�б���" ) , row=5 , col=1 )
        self.delYL = wx.Button( self , ACTION_DELETE_YL , "ɾ��" )
        sizer.Add( self.delYL , row=6 , col=3 )
        #wx.TextCtrl( self , -1 , style=wx.TE_MULTILINE )
        self.ylcplb = listdlg.MyListCtrl( self )
        sizer.Add( self.ylcplb , row=5 , col=2 , rowspan = 6 , flag=wx.EXPAND )
        self.ylcplb.InsertColumn(0, "����")
        self.ylcplb.InsertColumn(1, "����")
        self.ylcplb.InsertColumn(2, "Ŀ¼")
        listmix.ColumnSorterMixin.__init__(self, 3)
        self.ylcplb.SetColumnWidth( 0 , 200 )
        self.ylcplb.SetColumnWidth( 1 , 300 )
        self.ylcplb.SetColumnWidth( 2 , 400 )
        self.il = wx.ImageList(16, 16)
        self.sm_up = self.il.Add(listdlg.getSmallUpArrowBitmap())
        self.sm_dn = self.il.Add(listdlg.getSmallDnArrowBitmap())
        self.ylcplb.SetImageList(self.il, wx.IMAGE_LIST_SMALL)
        sizer.Add( wx.StaticText( self , -1 , "��Ч���㹫ʽ��" ) , row=11 , col=1 )
        self.btnYXTest = wx.Button( self , ACTION_YXJS_TEST , "����" )
        sizer.Add( self.btnYXTest , row=11 , col=3 , flag=wx.ALIGN_CENTER )
        self.stc_yx = wx.TextCtrl( self , -1 , style=wx.TE_MULTILINE )
        sizer.Add( self.stc_yx , row=11 , col=2 , rowspan=2 , flag=wx.EXPAND )
        sizer.Add( wx.StaticText( self , -1 , "����ű���" ) , row=13 , col=1 )
        self.v1 = wx.CheckBox(self, -1, "��ʾ�հ��ַ�" )
        sizer.Add( self.v1 , row=13 , col=2 )
        self.stc_js = createStyleCtrl( self )
        sizer.Add( self.stc_js , row=14 , col=1 , colspan=3, flag=wx.EXPAND )
        sizer.AddGrowableCol(2)
        sizer.AddGrowableRow(14)
        self.SetSizer( sizer )
        sizer.Fit( self )
        
        self.editObj = None
        self.treeitem = None
        
        self.v1.SetValue( False )
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox )
        self.Bind(wx.EVT_BUTTON, self.OnClick )
        self.ylcplb.Bind(wx.EVT_LEFT_DCLICK, self.OnLeftDClick)
        self.Bind(wx.EVT_LIST_ITEM_SELECTED, self.OnItemSelected, self.ylcplb)
        self.Bind(wx.EVT_LIST_BEGIN_DRAG, self.OnBeginDrag , self.ylcplb )
        self.currentItem = None
        self.itemDataMap = {}
        dt = CPDropTarget(self)
        self.SetDropTarget(dt)
    
    def OnItemSelected( self , evt ):
        self.currentItem = evt.m_itemIndex
        evt.Skip()
    
    def OnBeginDrag( self , evt ):
        index = evt.GetIndex()
        if index >= 0 :
            item = self.ylcplb.GetItem( index , 0 )
            cpdm = item.GetText().encode( 'gbk' )
            data = wx.TextDataObject( cpdm )
            dropSource = wx.DropSource(self)
            dropSource.SetData(data)
            result = dropSource.DoDragDrop(wx.Drag_AllowMove)
    
    def OnLeftDClick( self , evt ):
        item = self.ylcplb.GetItem(self.currentItem, 0 )
        cpdm = item.GetText().encode( 'gbk' )
        if self.can_switch():
            try:
                obj , pobj = self.parent.data.cache[ cpdm ]
                path = pobj.path
                self.parent.tree.select( path , obj )
            except KeyError:
                self.MessageDlg( '����' , '�Ҳ���[%s]��Ʒ�Ķ���' % cpdm )
        
    def GetListCtrl( self ):
        return self.ylcplb
    
    def GetSortImages(self):
        return (self.sm_dn, self.sm_up)
    
    def OnCheckBox( self , evt ):
        self.stc_js.SetViewWhiteSpace( self.v1.GetValue() )
    
    def MessageDlg( self , title , message ):
        dlg = wx.MessageDialog(self, message, title , wx.OK | wx.ICON_ERROR
                                   #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
            )
        dlg.ShowModal()
        dlg.Destroy()
    
    def InfoMsgDlg( self , title , message ):
        dlg = wx.MessageDialog(self, message, title , wx.OK | wx.ICON_INFORMATION )
        dlg.ShowModal()
        dlg.Destroy()
    
    def OnClick( self , evt ):
        id = evt.GetId()
        if id == ACTION_YXJS_TEST:
            sfqj = self.sfqj.GetValue().encode( 'gbk' )
            sfyx = self.stc_yx.GetValue().encode( 'gbk' ).strip().replace( '\r\n' , ' or ' )
            cpdm = self.cpdm.GetValue().encode( 'gbk' )
            cpoper = None
            if sfqj == '��Ա':
                cpoper = self.parent.data.oplist.rycp
            elif sfqj == '����':
                cpoper = self.parent.data.oplist.jgcp
            elif sfqj == '�ͻ�':
                cpoper = self.parent.data.oplist.khcp
            elif sfqj == '�˻�':
                cpoper = self.parent.data.oplist.zhcp
            else:
                self.InfoMsgDlg( '��ʾ' , 'ȫ�ַ�Χ�ĸ߼���Ʒ����Ҫ������Ч��Χ' )
                return
            sql = cpoper.build( sfyx )
            try:
                rs = sql_execute( cu , sql )
                dmlist = {}
                i = 0
                while rs.next():
                    d1 = rs.getString( cpoper.field_list[0] )
                    d2 = rs.getString( cpoper.field_list[1] )
                    dmlist[ i ] = ( d1 , d2 )
                    i += 1
                dlg = listdlg.ListDialog( self , cpdm , dmlist , '��Ʒ[%s]����Ч�б�' % cpdm )
                dlg.CenterOnScreen()
                dlg.ShowModal()
            except:
                typ, value, tb = sys.exc_info()
                lst = traceback.format_tb(tb) + traceback.format_exception_only(typ, value)
                self.MessageDlg( '����' , 'ɾ����Ʒʧ��: \n%s' % ''.join( lst ) )
            cu.close()
        elif id == ACTION_SAVE:
            self.Save()
        elif id == ACTION_CANCEL:
            self.DisplayCPObj()
        elif id == ACTION_DELETE_YL:
            # ��������Ʒ�б���ɾ��ѡ�еĲ�Ʒ
            # 1 ���ѡ�еĲ�Ʒ�б�
            item = self.ylcplb.GetNextItem( -1 , wx.LIST_NEXT_ALL , wx.LIST_STATE_SELECTED )
            dlist = []
            while item >= 0:
                ditem = self.ylcplb.GetItem( item, 0 )
                cpdm = ditem.GetText().encode( 'gbk' )
                dlist.append( cpdm )
                item = self.ylcplb.GetNextItem( item , wx.LIST_NEXT_ALL , wx.LIST_STATE_SELECTED )
            # 2 ���ò�Ʒ�Ƿ�Ӧ��ɾ��
            jsjb = self.stc_js.GetText().encode( 'gbk' ).replace( '\r\n' , '\n' )
            for cp in dlist:
                if cp == self.editObj.name:
                    continue
                a = re.compile( '%s[\.\s]+' % cp )
                if a.search( jsjb ) :
                    self.MessageDlg( '����' , '�ò�Ʒ[%s]���ܴӲ�Ʒ�б���ɾ��, ��Ϊ����ű�����ʹ�øò�Ʒ' % cp )
                    return
            # ���¹���itemDataMap
            fitem = {}
            i = 0
            for k , v in self.itemDataMap.items():
                if v[0] not in dlist:
                    fitem[i] = v
                    i += 1
            self.itemDataMap = fitem
            self.setCPList()
    
    def getCPList( self ):
        # ��ȡ�б�����ʾ�Ĳ�Ʒ�б�
        cplb = sets.Set()
        for k , v in self.itemDataMap.items():
            cplb.add( v[0] )
        return cplb
    
    def setCPList( self ):
        try:
            self.ylcplb.Freeze()
            self.ylcplb.DeleteAllItems()
            for key, data in self.itemDataMap.items():
                index = self.ylcplb.InsertStringItem( key , data[0] )
                self.ylcplb.SetStringItem(index, 1 , data[1] )
                self.ylcplb.SetStringItem(index, 2 , data[2] )
                self.ylcplb.SetItemImage( index , -1 )
                self.ylcplb.SetItemData( index , key )
                if len( data ) == 4:
                    item = self.ylcplb.GetItem( index )
                    item.SetTextColour( data[3] )
                    self.ylcplb.SetItem( item )
                if data[0] == self.editObj.name:
                    item = self.ylcplb.GetItem( index )
                    item.SetTextColour( wx.BLUE )
                    self.ylcplb.SetItem( item )
        finally:
            self.ylcplb.Thaw()

    def Save( self ):
        assert self.editObj is not None
        cpdm = self.cpdm.GetValue().encode( 'gbk' )

        if cpdm != self.editObj.name and ( not self.editObj.new ):
            try:
                self.parent.data.check_unique( cpdm )
            except RuntimeError , e :
                self.MessageDlg( '����' , e.args[0] )
                return False
            dlg = wx.MessageDialog(self, "��Ʒ���뱻����, ���ٴ�ȷ��, ѡ������ò�Ʒ����! " , "��ʾ" , wx.YES_NO | wx.ICON_INFORMATION )
            ret = dlg.ShowModal()
            dlg.Destroy()
            if ret == wx.ID_NO:
                self.cpdm.SetValue( self.editObj.name )
                return
        
        cpmc = self.cpmc.GetValue().encode( 'gbk' )
        if not cpdm:
            self.MessageDlg( '����' , '��Ʒ���벻��Ϊ��' )
            return False
            
        if not cpmc:
            self.MessageDlg( '����' , '��Ʒ���Ʋ���Ϊ��' )
            return False
            
        sfqj = self.sfqj.GetValue().encode( 'gbk' )
        ylcplb = self.getCPList()
        sfyx = self.stc_yx.GetValue().encode( 'gbk' ).replace( '\r\n' , '\n' ).strip()
        if sfqj == 'ȫ��' and sfyx:
            self.MessageDlg( '����' , '��������ʧ��: ȫ��ģʽ�Ĳ�Ʒ��Ӧ��ӵ����Ч��ʽ' )
            return False

        jsjb = self.stc_js.GetText().encode( 'gbk' ).replace( '\r\n' , '\n' )
        # 
        list_cp = list(ylcplb)
        list_cp.append( cpdm )
        code = py2fun( list_cp , jsjb )

        try:
            c = compile( code , cpdm , 'exec' )
            exec c
            del func
        except:
            typ, value, tb = sys.exc_info()
            lst = traceback.format_tb(tb) + traceback.format_exception_only(typ, value)
            self.MessageDlg( '����' , '��������ʧ��: \n%s' % ''.join( lst ) )
            return False
        
        oldcpdm = self.editObj.name  # ԭʼ��Ʒ����
        self.editObj.name = cpdm
        self.editObj.cpmc = cpmc
        self.editObj.jsfs = sfqj
        self.editObj.gsfs = self.gsfs.GetValue().encode( 'gbk' )
        self.editObj.ylcplb = ylcplb.copy()
        self.editObj.yxgs = sfyx
        self.editObj.jsjb = jsjb
        self.editObj.new  = False
        
        self.parent.modified()
        self.parent.data.cp_change( self.editObj , oldcpdm )
        self.parent.tree.SetItemText( self.treeitem , self.editObj.get_lable() )
        pitem = self.parent.tree.GetItemParent( self.treeitem )
        self.parent.tree.SortChildren( pitem )
        self.cpzl.SetLabel( self.editObj.get_lable() )
    
    def UpdateUI( self ):
        self.cpdm.SetValue( "" )
        self.cpmc.SetValue( "" )
        self.gsfs.SetValue( "" )
        self.sfqj.SetValue( "��Ա" )
        #self.ylcplb.DeleteAllItems()
        #self.itemDataMap = {}
        self.stc_yx.SetValue( "" )
        self.stc_js.ClearAll()
        self.delYL.Disable()

        self.cpzl.SetLabel( "δѡ���Ʒ����" )
        self.cpdm.Disable()
        self.cpmc.Disable()
        self.gsfs.Disable()
        self.sfqj.Disable()
        self.ylcplb.Disable()
        self.stc_yx.Disable()
        self.stc_js.Disable()
        self.btnSave.Disable()
        self.btnCancel.Disable()
        self.btnYXTest.Disable()
        
        self.treeitem = self.parent.tree.curitem
        self.editObj  = self.parent.tree.curitem_data
        
        if type( self.editObj ) == CPObjDesc:
            self.cpzl.SetLabel( self.editObj.get_lable() )
            self.cpmc.Enable()
            self.gsfs.Enable()
            self.cpdm.Enable()
            self.sfqj.Enable()
            self.ylcplb.Enable()
            self.stc_yx.Enable()
            self.stc_js.Enable()
            self.btnSave.Enable()
            self.btnCancel.Enable()
            self.btnYXTest.Enable()
            self.delYL.Enable()
            self.DisplayCPObj()
    
    def DisplayCPObj( self ):
        self.cpdm.SetValue( self.editObj.name )
        self.cpmc.SetValue( self.editObj.cpmc )
        self.gsfs.SetValue( self.editObj.gsfs )
        self.sfqj.SetValue( self.editObj.jsfs )
        self.stc_yx.SetValue( self.editObj.yxgs )
        self.stc_js.ClearAll()
        self.stc_js.AddText( self.editObj.jsjb )
        self.refresh_ylcplb( self.editObj.ylcplb )
    
    def refresh_ylcplb( self , yllist ):
        self.itemDataMap = {}
        i = 0
        for cp in yllist:
            self.add_ylcp( i , cp )
            i += 1
        self.setCPList()
    
    def add_ylcp( self , i , cp ):
        obj , pobj = self.parent.data.cache.get( cp , ( None , None ) )
        if obj is None:
            self.itemDataMap[i] = ( cp , 'δ�ҵ��ò�Ʒ����' , '' , wx.RED )
        else:
            if pobj.name == '����վ':
                self.itemDataMap[i] = ( obj.name , obj.cpmc , pobj.path , wx.RED )
            else:
                self.itemDataMap[i] = ( obj.name , obj.cpmc , pobj.path )

    
    def can_switch( self ):
        if self.editObj == None:
            return True
        
        bModified = False
        # ����
        cpmc = self.cpmc.GetValue().encode( 'gbk' )
        cpdm = self.cpdm.GetValue().encode( 'gbk' )
        jsfs = self.sfqj.GetValue().encode( 'gbk' )
        gsfs = self.gsfs.GetValue().encode( 'gbk' )
        ylcplb = self.getCPList()
        yxgs = self.stc_yx.GetValue().encode( 'gbk' ).replace( '\r\n' , '\n' ).strip()
        jsjb = self.stc_js.GetText().encode( 'gbk' ).replace( '\r\n' , '\n' )

        if cpmc != self.editObj.cpmc or \
           cpdm != self.editObj.name or \
           jsfs != self.editObj.jsfs or  \
           gsfs != self.editObj.gsfs or  \
           ylcplb  != self.editObj.ylcplb   or  \
           yxgs     != self.editObj.yxgs or  \
           jsjb     != self.editObj.jsjb :
            '''print '=' * 20
            print cpmc , self.editObj.cpmc
            print cpdm , self.editObj.name
            print jsfs , self.editObj.jsfs
            print gsfs , self.editObj.gsfs
            print ylcplb  , self.editObj.ylcplb
            print yxgs    , self.editObj.yxgs
            print jsjb    , self.editObj.jsjb
            print '=' * 20'''
            bModified = True

        if bModified:
            # ��ʾ�Ƿ񱣴�, ������ʧ�����л�
            dlg = wx.MessageDialog(self, "��ҳ���ڱ༭�Ķ����ѱ��ı�, �Ƿ񱣴�?", "��ʾ" , wx.YES_NO | wx.ICON_INFORMATION )
            d = dlg.ShowModal()
            dlg.Destroy()
            if d == wx.ID_YES:
                self.Save()
                
        return True
    
    def addCP( self , cpdm ):
        if cpdm == self.editObj.name:
            self.MessageDlg( "����" , "�����������Լ�" )
            return

        if cpdm in self.getCPList():
            self.MessageDlg( "����" , "�ò�Ʒ�Ѵ��������б���" )
            return
        
        # ���ò�Ʒ�����Ƿ�Ϸ������ڻ��������Ʒ�����ڣ����ڻ���վ�У�Ҳ��ʾ��Ʒ������
        if self.parent.data.test_cp_exist( cpdm ):
            self.MessageDlg( "����" , "�ò�Ʒδ������ڻ���վ��" )
        
        self.editObj.ylcplb.add( cpdm )
        self.add_ylcp( len( self.itemDataMap ) , cpdm )
        self.setCPList()

class CPDropTarget(wx.TextDropTarget):
    def __init__(self, window):
        wx.TextDropTarget.__init__(self)
        self.window = window

    def OnDropText(self, x, y, text):
        self.window.addCP( text.encode( 'gbk' ) )

    def OnDragOver(self, x, y, d):
        return wx.DragCopy

