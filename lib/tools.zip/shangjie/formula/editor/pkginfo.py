# coding: gbk

"""
��ֵ�����Ա༭
$Id: pkginfo.py 222 2008-05-19 15:45:30Z zhangjun $
"""
[ ACTION_SAVE ,
  ACTION_CANCEL ,
  ACTION_DELETE , 
  ACTION_GRAPH , 
  ACTION_DELCP ,
  ACTION_TEST ] = range( 6 )

tjszq = ['��','��','��','����','��','�Զ���']

import wx
import wx.lib.rcsizer  as rcs
import wx.lib.intctrl  as intctrl
import sys,traceback,os
import cPickle

from shangjie.formula.objs.desc import PkgObj
from shangjie.formula.utils import cpadmin
import listdlg

from graph import GraphDialog
import testdlg
from listdlg import getSmallUpArrowBitmap , getSmallDnArrowBitmap

import  wx.lib.mixins.listctrl  as  listmix

class PkgInfo( wx.Panel , listmix.ColumnSorterMixin ):
    def __init__( self , parent ):
        wx.Panel.__init__( self , parent , -1 , style= wx.NO_BORDER )
        self.parent = parent
        
        sizer = rcs.RowColSizer()
        # 1
        sizer.Add( wx.StaticText( self , -1 , "���ƣ�" , size = ( 100 , -1 ) ) , row=0 , col=1 )
        self.qzmc = wx.TextCtrl( self , -1 )
        sizer.Add( self.qzmc , row=0 , col=2 , colspan=2 , flag=wx.EXPAND )
        self.btnSave = wx.Button( self , ACTION_SAVE , "����" )
        self.btnCancel = wx.Button( self , ACTION_CANCEL , "ȡ��" )
        sizer.Add( self.btnSave , row=0 , col=4 )
        sizer.Add( self.btnCancel , row=0 , col=5 )
        # 3
        sizer.Add( wx.StaticText( self , -1 , "�������ڣ�" ) , row=1 , col=1 )
        boxsizer = wx.BoxSizer(wx.HORIZONTAL)
        self.jszq = wx.ComboBox(self, -1, tjszq[0] , (100, -1), choices = tjszq , style = wx.CB_READONLY )
        boxsizer.Add( self.jszq )
        self.zt   = wx.CheckBox(self ,-1,"����" )
        boxsizer.Add( ( 40 , -1 ) )
        boxsizer.Add( self.zt , flag = wx.ALIGN_BOTTOM )
        sizer.Add( boxsizer , row=1 , col=2 , colspan=4 , flag=wx.EXPAND )
        # 4
        sizer.Add( wx.StaticText( self , -1 , "������Ʒ�б���" ) , row=2 , col=1 , colspan=2 )
        self.btnTest = wx.Button( self , ACTION_TEST , "����" )
        sizer.Add( self.btnTest , row=2 , col=3 )
        self.btnDelCP = wx.Button( self , ACTION_DELCP , "ɾ��ѡ�в�Ʒ" )
        sizer.Add( self.btnDelCP , row=2 , col=4 )
        self.btnGraph = wx.Button( self , ACTION_GRAPH , "��ֵͼ" )
        sizer.Add( self.btnGraph , row=2 , col=5 )
        # 5
        self.cplist = listdlg.MyListCtrl( self )
        sizer.Add( self.cplist , row=3 , col=1 , colspan=5 , flag=wx.EXPAND )
        self.cplist.InsertColumn(0, "���")
        self.cplist.InsertColumn(1, "����")
        self.cplist.InsertColumn(2, "����")
        self.cplist.InsertColumn(3, "Ŀ¼")
        listmix.ColumnSorterMixin.__init__(self, 4)
        self.cplist.SetColumnWidth( 0 , 70 )
        self.cplist.SetColumnWidth( 1 , 120 )
        self.cplist.SetColumnWidth( 2 , 200 )
        self.cplist.SetColumnWidth( 3 , 250 )
        self.il = wx.ImageList(16, 16)
        self.sm_up = self.il.Add(getSmallUpArrowBitmap())
        self.sm_dn = self.il.Add(getSmallDnArrowBitmap())
        self.cplist.SetImageList(self.il, wx.IMAGE_LIST_SMALL)

        sizer.AddGrowableCol(2)
        sizer.AddGrowableRow(3)
        self.SetSizer( sizer )
        sizer.Fit( self )
        
        self.Bind(wx.EVT_BUTTON, self.OnClick )
        self.cplist.Bind(wx.EVT_LEFT_DCLICK, self.OnLeftDClick)
        self.Bind(wx.EVT_LIST_ITEM_SELECTED, self.OnItemSelected, self.cplist)
        
        self.currentItem = None
        self.itemDataMap = {}
        
        self.qzobj = None
        
        dt = CPDropTarget(self)
        self.SetDropTarget(dt)
    
    def OnItemSelected( self , evt ):
        self.currentItem = evt.m_itemIndex
        evt.Skip()
    
    def MessageDlg( self , title , message ):
        dlg = wx.MessageDialog(self, message, title , wx.OK | wx.ICON_ERROR
                                   #wx.YES_NO | wx.NO_DEFAULT | wx.CANCEL | wx.ICON_INFORMATION
            )
        dlg.ShowModal()
        dlg.Destroy()
    
    def InfoMsgDlg( self , title , message ):
        dlg = wx.MessageDialog(self, message, title , wx.OK | wx.ICON_INFORMATION )
        dlg.ShowModal()
        dlg.Destroy()
    
    def OnLeftDClick( self , evt ):
        item = self.cplist.GetItem(self.currentItem, 1 )
        cpdm = item.GetText().encode( 'gbk' )
        try:
            obj , pobj = self.parent.data.cache[ cpdm ]
            path = pobj.path
            self.parent.tree.select( path , obj )
        except KeyError:
            self.MessageDlg( '����' , '�Ҳ���[%s]��Ʒ�Ķ���' % cpdm )
    
    def OnClick( self , evt ):
        id = evt.GetId()
        if id == ACTION_SAVE:
            self.Save()
        elif id == ACTION_CANCEL:
            self.DisplayObj()
        elif id == ACTION_GRAPH:
            self.Graph()
        elif id == ACTION_DELCP:
            self.DelCP()
        elif id == ACTION_TEST:
            self.Test()
    
    def Test( self ):
        qzmc = self.qzmc.GetValue().encode( 'gbk' )
        dlg = testdlg.PkgTestDialog( self.parent , self.qzobj )
        dlg.Show()
    
    def DelCP( self ):
        item = self.cplist.GetNextItem( -1 , wx.LIST_NEXT_ALL , wx.LIST_STATE_SELECTED )
        dlist = []
        while item >= 0:
            i = self.cplist.GetItem(item, 0 )
            k = i.GetText().encode( 'gbk' )
            dlist.append( self.itemDataMap[ int(k) ][1] )
            item = self.cplist.GetNextItem( item , wx.LIST_NEXT_ALL , wx.LIST_STATE_SELECTED )
        # ����������Щɾ����Ʒ�Ĳ�Ʒ�б���������ʣ���Ʒ�Ƿ����������ֵ
        cpdmlist = []
        for cpdm in self.qzobj.cplb:
            if cpdm in dlist:
                continue
            cpdmlist.append( cpdm )
        # ������ֵ�б�
        map = cpadmin._buildCPMap( {'test':self.parent.data} )
        gjcpmap = {}
        try:
            for cpdm in cpdmlist:
                gjcpmap[ cpdm ] = map[ cpdm ]
            gjcplist = cpadmin.GJCPCalcList( gjcpmap )
        except:
            typ, value, tb = sys.exc_info()
            lst = traceback.format_tb(tb) + traceback.format_exception_only(typ, value)
            self.MessageDlg( "����" , "����ɾ����Щ��Ʒ��ɾ�����ǵ��¸���ֵ���޷���ֵ\n" + ''.join( lst ) )
            return
        self.qzobj.cplb.clear()
        self.qzobj.cplb.update( cpdmlist )
        self.DisplayObj()
        
    
    def Save( self ):
        if self.qzobj == None:
            self.UpdateUI( 0 )
            return
        bdmMod = False
        qzmc = self.qzmc.GetValue().encode( 'gbk' )
        jszq = self.jszq.GetValue().encode( 'gbk' )
        zt   = self.zt.GetValue()
        if not qzmc:
            self.MessageDlg( '����' , '����Ϊ��, ���ɱ���' )
            return
        
        oname = self.qzobj.name
        # ����Ƿ�����
        t = self.parent.tree
        pitem = t.GetItemParent( t.curitem )
        pobj  = t.GetPyData( pitem )
        if qzmc != oname:
            if qzmc in pobj.keys():
                self.MessageDlg( '����' , '�����ظ�' )
                return
            del pobj[ oname ]
            self.qzobj.name = qzmc
            pobj.add( self.qzobj )
            
            
        self.qzobj.jszq = jszq
        self.qzobj.sfqy = zt
        self.parent.modified()
        
        self.DisplayObj()
        t.SetItemText( self.parent.tree.curitem , self.qzobj.get_lable() )
        t.SortChildren( pitem )
    
    def GetListCtrl( self ):
        return self.cplist
    
    def GetSortImages(self):
        return (self.sm_dn, self.sm_up)

    def UpdateUI( self ):
        self.qzmc.SetValue( "" )
        self.jszq.SetValue( "��" )
        self.zt.SetValue( True )

        self.qzmc.Disable()
        self.jszq.Disable()
        self.zt.Disable()
        self.cplist.Disable()
        self.btnSave.Disable()
        self.btnCancel.Disable()
        self.btnGraph.Disable()

        self.treeitem = self.parent.tree.curitem
        self.qzobj    = self.parent.tree.curitem_data
    
        if type( self.qzobj ) == PkgObj:
            self.qzmc.Enable()
            self.jszq.Enable()
            self.zt.Enable()
            self.btnSave.Enable()
            self.btnCancel.Enable()
            self.btnGraph.Enable()
            self.cplist.Enable()
            self.DisplayObj()
    
    def Graph( self ):
        if self.qzobj == None:
            self.UpdateUI(0)
            return
        dlg = GraphDialog(self.parent)
        cpdmlist = list( self.qzobj.cplb )
        dlg.cplb.SetValue( ','.join( cpdmlist ) )
        dlg.MakeGraph( cpdmlist )
        dlg.Show()
    
    def Create( self ):
        self.action = 'create'
        self.qzobj = PkgObj()
        self.DisplayObj()
    
    def DisplayObj( self ):
        if self.qzobj == None:
            self.UpdateUI()
            return
            
        self.qzmc.SetValue( self.qzobj.name )
        self.jszq.SetValue( self.qzobj.jszq )
        self.zt.SetValue( self.qzobj.sfqy )
        try:
            self.cplist.Freeze()
            self.cplist.DeleteAllItems()
            self.refresh_ylcplb()
        finally:
            self.cplist.Thaw()

    def addCPList( self , cplist ):
        self.qzobj.cplb.update( cplist )
        self.parent.modified()
        self.DisplayObj()
        
    def refresh_ylcplb( self ):
        map = cpadmin._buildCPMap( {'test':self.parent.data} )
        gjcpmap = {}
        err =  []
        for cpdm in self.qzobj.cplb:
            try:
                gjcpmap[ cpdm ] = map[ cpdm ]
            except:
                err.append( ( cpdm , '�Ҳ����ò�Ʒ����' ) )
        
        self.itemDataMap = {}
        try:
            gjcplist = cpadmin.GJCPCalcList( gjcpmap )
            i = 0
            for obj in gjcplist.cplist:
                pobj = self.parent.data.cache[ obj.cpdm ][1]
                a = [ '%02d' % i , obj.cpdm , obj.cpmc , pobj.path ]
                if pobj.name == '����վ':
                    a.append( wx.RED )
                self.itemDataMap[i] = tuple( a )
                i += 1
            for cp in err:
                self.itemDataMap[i] = ( '%02d' % i , cp[0] , cp[1] , '' , wx.RED )
                i += 1
        except:
            typ, value, tb = sys.exc_info()
            lst = traceback.format_tb(tb) + traceback.format_exception_only(typ, value)
            dlg = wx.MessageDialog( None , '��Ʒ�����д���, �����ˢ��: \n%s' % ''.join( lst ), 
                                    '����' , wx.OK | wx.ICON_ERROR)
            dlg.ShowModal()
            dlg.Destroy()
            i = 0
            for cp in self.qzobj.cplb:
                self.itemDataMap[i] = ( '%02d' % i , cp , '' , '' , wx.RED )
                i += 1
        
        self.cplist.DeleteAllItems()
        for key, data in self.itemDataMap.items():
            index = self.cplist.InsertStringItem( key , data[0] )
            self.cplist.SetStringItem(index, 1 , data[1] )
            self.cplist.SetStringItem(index, 2 , data[2] )
            self.cplist.SetStringItem(index, 3 , data[3] )
            self.cplist.SetItemImage( index , -1 )
            self.cplist.SetItemData( index , key )
            if len( data ) == 5:
                item = self.cplist.GetItem( index )
                item.SetTextColour( data[4] )
                self.cplist.SetItem( item )
        
    def can_switch( self ):
        return True
    
class CPDropTarget(wx.TextDropTarget):
    def __init__(self, window):
        wx.TextDropTarget.__init__(self)
        self.dv = window

    def OnDropText(self, x, y, text):
        cplist = FindCPList( self.dv.parent.data , text.encode( 'gbk' ) )
        self.dv.addCPList( cplist )

    def OnDragOver(self, x, y, d):
        if self.dv.qzobj == None:
            return wx.DragNone
        return wx.DragCopy

def FindCPList( data , cpdm ):
    # ���ݲ�Ʒ�������ò�Ʒ���������Ĳ�Ʒ������һ��
    cplist = [ cpdm ]
    pos = 0
    while pos < len( cplist ):
        cpdm = cplist[pos]
        pos += 1
        try:
            obj = data.cache[ cpdm ][0]
            cplist.extend( list( obj.ylcplb ) )
        except KeyError:
            pass
        
    return cplist
