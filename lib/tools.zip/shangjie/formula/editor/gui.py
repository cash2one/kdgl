# coding: gbk
"""
    Copyright 2004 ��Ԫ�ţ���������Ϣ�������޹�˾��
    All right reserved.

    ��Ʒ����ά���������
    ���������洴��
    
    $Id: gui.py 222 2008-05-19 15:45:30Z zhangjun $
"""

import sys,os
import  wx
import  wx.gizmos   as  gizmos
import wx.lib.rcsizer  as rcs

from shangjie.conf import settings
from shangjie.utils import package
from shangjie.formula.objs import desc
import pyaui
import tree
import cpdir_info
import info
import pkginfo

TITLE = "��Ʒ����ά������ v 0.7 "

class PyAUIFrame(wx.Frame):
    def __init__(self):
        """left a tree, right a textctrl. Wow."""
        wx.Frame.__init__(self, None, -1, TITLE , style = wx.DEFAULT_FRAME_STYLE | wx.MAXIMIZE )
        
        self.question = True
        
        self.data = None  # ���ݶ���
        self.path = None  # �ļ�·��
        self.modules = [] # ע���ģ��
        
        # ����˵�����
        # �ļ��˵�
        self.menu = wx.MenuBar()
        menu1 = wx.Menu()
        menu1.Append( 100 , '�½�' )
        menu1.Append( 101 , '��' )
        menu1.Append( 102 , '����' )
        menu1.Append( 107 , '����Ϊ' )
        menu1.Append( 103 , '�ر�' )
        menu1.AppendSeparator()
        menu1.Append( 104 , "�˳�" )
        self.menu.Append( menu1 , '�ļ�' )
        
        # �߼������˵�
        menu2 = wx.Menu()
        menu2.Append( 120 , '������Ŀ¼' )
        menu2.Append( 121 , '��Ŀ¼����' )
        menu2.Append( 122 , '�����ݿ⵼����Ŀ¼' )
        menu2.AppendSeparator()
        menu2.Append( 105 , '���������ļ�' )
        menu2.Append( 106 , '�ϲ��ļ�' )
        self.menu.Append( menu2 , '�߼�' )

        self.SetMenuBar( self.menu )
        
        # ����pane���������
        self._mgr = pyaui.FrameManager()
        self._mgr.SetFrame(self)
        
        self.SetMinSize(wx.Size(800, 600))
        
        self.tree = tree.ProductTree( self )
        self._mgr.AddPane( self.tree , 
                           pyaui.PaneInfo().Name( "obj_tree" ).Caption( "�����б�" ).
                           Left().Layer(1).Position(1).
                           CloseButton(False).Floatable(False) )
        # �����ұ�ϸ�ڶ���
        # cpdir_info: ��ƷĿ¼��Ϣ
        self.cpdir_info = cpdir_info.CPDirInfo( self )
        self._mgr.AddPane( self.cpdir_info, pyaui.PaneInfo().Name("cpdir_info").
                           CenterPane().Hide() )
        
        # cp_info: ��Ʒ��Ϣ
        self.info = info.ObjInfo( self )
        self._mgr.AddPane( self.info, pyaui.PaneInfo().Name("cp_info").
                           CenterPane().Hide() )
        
        # pkg_info����ֵ����Ϣ
        self.pkginfo = pkginfo.PkgInfo( self )
        self._mgr.AddPane( self.pkginfo , pyaui.PaneInfo().Name("pkg_info").
                           CenterPane().Hide() )
                           
        self._mgr.Update()
        
        self.Bind(wx.EVT_MENU, self.mNewFile , id=100 )
        self.Bind(wx.EVT_MENU, self.mOpenFile , id=101 )
        self.Bind(wx.EVT_MENU, self.mSaveFile , id=102 )
        self.Bind(wx.EVT_MENU, self.mSaveAsFile , id=107 )
        self.Bind(wx.EVT_MENU, self.mCloseFile , id=103 )
        self.Bind(wx.EVT_MENU, self.mExit , id=104 )
        self.Bind(wx.EVT_MENU, self.mDist , id=105 )
        self.Bind(wx.EVT_MENU, self.mMerge , id=106 )
        self.Bind(wx.EVT_MENU, self.mExportToDir , id=120 )
        self.Bind(wx.EVT_MENU, self.mImportFromDir , id=121 )
        self.Bind(wx.EVT_MENU, self.mExportFromDBToDir , id=122 )
        
        
        self.Bind( wx.EVT_CLOSE , self.mExit )
        
        #self.Bind(wx.EVT_TREE_ITEM_EXPANDING , self.treeExpanding , self.tree )
        #self.Bind(wx.EVT_TREE_SEL_CHANGED , self.treeSel , self.tree )
        self.currentpane = None
    
    def showPane( self , name ):
        """
        ��ʾָ�����Ƶ�pane
        """
        self.Freeze()
        try:
            # �������е�pane
            self.currentpane = None
            map( lambda x:x.Hide() , self._mgr.GetAllPanes() )
            # ��ʾָ����pane
            if name:
                self.currentpane = self._mgr.GetPane( name ).Show()
            self._mgr.GetPane( 'obj_tree' ).Show()
            self._mgr.Update()
        finally:
            self.Thaw()
        
    # Menu Event Handler
    def mNewFile( self , evt ):
        self.mCloseFile( evt )
        self.new_data()
    
    def mOpenFile( self , evt ):
        if self.data and self.data.modified:
            self.mSaveFile( evt )
        
        dlg = wx.FileDialog(
                self, message="���ļ�", defaultDir=settings.CPIDIR, 
                defaultFile="", wildcard="��Ʒ������Ϣ�ļ�(*.cpi)|*.cpi", style=wx.OPEN | wx.CHANGE_DIR )
        if dlg.ShowModal() == wx.ID_OK:
            paths = dlg.GetPaths()
            self.path = paths[0]
            self.load_data()
            self.SetLabel( TITLE + " " + self.path.encode( 'gbk' ) )
            
        dlg.Destroy()
    
    def mCloseFile( self , evt ):
        if self.data and self.data.modified:
            self.mSaveFile( evt )
        
        self.clear_data()
    
    def mSaveFile( self , evt ):
        if self.path:
            self.save_data()
        else:
            self.mSaveAsFile( evt )
    
    def mSaveAsFile( self , evt ):
        dlg = wx.FileDialog( self, message="����", defaultDir=settings.CPIDIR, 
                        defaultFile="", wildcard="��Ʒ������Ϣ�ļ�(*.cpi)|*.cpi", style=wx.SAVE | wx.CHANGE_DIR )
        if dlg.ShowModal() == wx.ID_OK:
            paths = dlg.GetPaths()
            self.path = paths[0]
            self.save_data()
        
        dlg.Destroy()
        
    def mExit( self , evt ):
        if self.data and self.data.modified:
            if wx.MessageDialog(self, "�ļ��Ѹı�, �Ƿ񱣴�?", "��ʾ" , wx.YES_NO | wx.ICON_INFORMATION ).ShowModal() == wx.ID_YES:
                self.mSaveFile( evt )
        
        self.Destroy()
    
    def mMerge( self , evt ):
        pass
    
    def mDist( self , evt ):
        pass
    
    def mExportToDir( self , evt ):
        if self.data:
            dlg = wx.DirDialog(self, "��ѡ��Ŀ¼:",
                          style=wx.DD_DEFAULT_STYLE|wx.DD_NEW_DIR_BUTTON)
            try:
                if dlg.ShowModal() == wx.ID_OK:
                    pa = dlg.GetPath().encode( 'gbk' )
                    a = os.listdir( pa )
                    if not a:
                        # ��ʼ����
                        desc.exporter( self.data , pa )
                    else:
                        wx.MessageDialog( self , "��ѡ���Ŀ¼[%s]�ǿգ��������ܽ���" % pa , "����" , wx.OK | wx.ICON_ERROR ).ShowModal()
            finally:
                dlg.Destroy()
        else:
            wx.MessageDialog( self , "��ǰδ�򿪲�Ʒ�����ļ�" , "����" , wx.OK | wx.ICON_ERROR ).ShowModal()
        
    
    def mImportFromDir( self , evt ):
        self.mCloseFile( evt )
        dlg = wx.DirDialog(self, "��ѡ��Ŀ¼:",
                      style=wx.DD_DEFAULT_STYLE|wx.DD_NEW_DIR_BUTTON)
        try:
            if dlg.ShowModal() == wx.ID_OK:
                pa = dlg.GetPath().encode( 'gbk' )
                a = os.listdir( pa )
                if a:
                    # ��ʼ����
                    self.data = desc.importer( pa )
                    self.tree.PopulateAll( self.data )
                else:
                    wx.MessageDialog( self , "��ѡ���Ŀ¼[%s]Ϊ�գ����벻�ܽ���" % pa , "����" , wx.OK | wx.ICON_ERROR ).ShowModal()
        finally:
            dlg.Destroy()
    
    def mExportFromDBToDir( self , evt ):
        dlg = wx.DirDialog(self, "��ѡ��Ŀ¼:",
                      style=wx.DD_DEFAULT_STYLE|wx.DD_NEW_DIR_BUTTON)
        try:
            if dlg.ShowModal() == wx.ID_OK:
                pa = dlg.GetPath().encode( 'gbk' )
                a = os.listdir( pa )
                if not a:
                    # ��ʼ����
                    desc.dbexporter( cx_Oracle.connect( config.db_khcon ) , pa )
                else:
                    wx.MessageDialog( self , "��ѡ���Ŀ¼[%s]�ǿգ��������ܽ���" % pa , "����" , wx.OK | wx.ICON_ERROR ).ShowModal()
        finally:
            dlg.Destroy()
    
    def new_data( self ):
        self.data = desc.Description()
        self.path = None
        self.tree.PopulateAll( self.data )
    
    def clear_data( self ):
        self.path = None
        self.data = None
        self.tree.PopulateAll( None )
    
    def save_data( self ):
        self.data.save( self.path )
    
    def load_data( self ):
        self.data = desc.Description.load( self.path )
        self.tree.PopulateAll( self.data )
    
    def modified( self ):
        assert self.data
        self.data.modified = True

class MyApp(wx.App):
    """This class is even less interesting than MyFrame."""

    def OnInit(self):
        """OnInit. Boring, boring, boring!"""
        frame = PyAUIFrame()
        frame.Show(True)
        self.SetTopWindow(frame)
        return True

def main():
    app = MyApp(False)
    app.MainLoop()


if __name__ == '__main__':
    main()

