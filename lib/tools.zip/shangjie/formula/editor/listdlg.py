# coding: gbk
# $Id: listdlg.py 221 2008-05-19 12:36:22Z zhangjun $

import wx
import wx.lib.rcsizer  as rcs
import sys,traceback,os

from wx import ImageFromStream, BitmapFromImage
import cStringIO

#----------------------------------------------------------------------
def getSmallUpArrowData():
    return \
'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x10\x00\x00\x00\x10\x08\x06\
\x00\x00\x00\x1f\xf3\xffa\x00\x00\x00\x04sBIT\x08\x08\x08\x08|\x08d\x88\x00\
\x00\x00<IDAT8\x8dcddbf\xa0\x040Q\xa4{h\x18\xf0\xff\xdf\xdf\xffd\x1b\x00\xd3\
\x8c\xcf\x10\x9c\x06\xa0k\xc2e\x08m\xc2\x00\x97m\xd8\xc41\x0c \x14h\xe8\xf2\
\x8c\xa3)q\x10\x18\x00\x00R\xd8#\xec\xb2\xcd\xc1Y\x00\x00\x00\x00IEND\xaeB`\
\x82' 

def getSmallUpArrowBitmap():
    return BitmapFromImage(getSmallUpArrowImage())

def getSmallUpArrowImage():
    stream = cStringIO.StringIO(getSmallUpArrowData())
    return ImageFromStream(stream)

#----------------------------------------------------------------------
def getSmallDnArrowData():
    return \
"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x10\x00\x00\x00\x10\x08\x06\
\x00\x00\x00\x1f\xf3\xffa\x00\x00\x00\x04sBIT\x08\x08\x08\x08|\x08d\x88\x00\
\x00\x00HIDAT8\x8dcddbf\xa0\x040Q\xa4{\xd4\x00\x06\x06\x06\x06\x06\x16t\x81\
\xff\xff\xfe\xfe'\xa4\x89\x91\x89\x99\x11\xa7\x0b\x90%\ti\xc6j\x00>C\xb0\x89\
\xd3.\x10\xd1m\xc3\xe5*\xbc.\x80i\xc2\x17.\x8c\xa3y\x81\x01\x00\xa1\x0e\x04e\
?\x84B\xef\x00\x00\x00\x00IEND\xaeB`\x82" 

def getSmallDnArrowBitmap():
    return BitmapFromImage(getSmallDnArrowImage())

def getSmallDnArrowImage():
    stream = cStringIO.StringIO(getSmallDnArrowData())
    return ImageFromStream(stream)

import  wx.lib.mixins.listctrl  as  listmix
class MyListCtrl( wx.ListCtrl, listmix.ListCtrlAutoWidthMixin):
	def __init__( self , parent , size = None ):
		if size:
			wx.ListCtrl.__init__( self , parent , -1 , style=wx.LC_REPORT , size = size )
		else:
			wx.ListCtrl.__init__( self , parent , -1 , style=wx.LC_REPORT )
		listmix.ListCtrlAutoWidthMixin.__init__(self)

class ListDialog( wx.Dialog , listmix.ColumnSorterMixin ):
	def __init__( self, parent, cpdm , dmlist , title = "" ):
		wx.Dialog.__init__( self , parent , size=( 400 , 100 ) , title=title , style = wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER )
		self.il = wx.ImageList(16, 16)
		self.sm_up = self.il.Add(getSmallUpArrowBitmap())
		self.sm_dn = self.il.Add(getSmallDnArrowBitmap())
		sizer = rcs.RowColSizer()
		list = MyListCtrl( self , size = ( 400 , 300 ) )
		list.SetImageList(self.il, wx.IMAGE_LIST_SMALL)
		self.itemDataMap = dmlist
		self.list = list
		list.InsertColumn(0, "�������")
		list.InsertColumn(1, "��������")
		listmix.ColumnSorterMixin.__init__(self, 2)
		i = 0
		for key, data in dmlist.items():
			index = list.InsertStringItem( i, data[0] )
			list.SetStringItem(index, 1 , data[1] )
			list.SetItemData( index , key )
			list.SetItemImage( index , -1 )
		
		list.SetColumnWidth(0, 150)
		list.SetColumnWidth(1, 240)
		
		sizer.Add( list , row=0 , col=0 , flag=wx.EXPAND )
		btnCancel = wx.Button( self , -1 , "�˳�" )
		sizer.Add( btnCancel , row=1 , col=0 , flag = wx.ALIGN_CENTER )
		sizer.AddGrowableCol(0)
		sizer.AddGrowableRow(0)
		self.SetSizer( sizer )
		sizer.Fit( self )
		
		self.Bind(wx.EVT_BUTTON ,self.OnClose , btnCancel )
		self.Bind(wx.EVT_CLOSE , self.OnClose )

	def OnClose( self , evt ):
		if self.IsModal():
			self.EndModal(wx.ID_OK)
		else:
			self.Destroy()
		
	def GetListCtrl( self ):
		return self.list
	
	def GetSortImages(self):
		return (self.sm_dn, self.sm_up)

class CPListDialog( wx.Dialog , listmix.ColumnSorterMixin ):
	def __init__( self, parent, cpdm , dmlist , title = "" ):
		wx.Dialog.__init__( self , parent , size=( 400 , 100 ) , title=title , style = wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER )
		self.mainframe = parent.GetParent().GetParent()
		self.il = wx.ImageList(16, 16)
		self.sm_up = self.il.Add(getSmallUpArrowBitmap())
		self.sm_dn = self.il.Add(getSmallDnArrowBitmap())
		sizer = rcs.RowColSizer()
		list = MyListCtrl( self , size = ( 400 , 300 ) )
		list.SetImageList(self.il, wx.IMAGE_LIST_SMALL)
		self.itemDataMap = dmlist
		self.list = list
		list.InsertColumn(0, "����")
		list.InsertColumn(1, "����")
		list.InsertColumn(2, "Ŀ¼")
		listmix.ColumnSorterMixin.__init__(self, 3)
		i = 0
		for key, data in dmlist.items():
			index = list.InsertStringItem( i, data[0] )
			list.SetStringItem(index, 1 , data[1] )
			list.SetStringItem(index, 2 , data[2] )
			list.SetItemData( index , key )
			list.SetItemImage( index , -1 )
		
		list.SetColumnWidth(0, 150)
		list.SetColumnWidth(1, 150)
		list.SetColumnWidth(2, 240)
		
		sizer.Add( list , row=0 , col=0 , flag=wx.EXPAND )
		btnCancel = wx.Button( self , -1 , "�˳�" )
		sizer.Add( btnCancel , row=1 , col=0 , flag = wx.ALIGN_CENTER )
		sizer.AddGrowableCol(0)
		sizer.AddGrowableRow(0)
		self.SetSizer( sizer )
		sizer.Fit( self )
		
		self.Bind(wx.EVT_BUTTON ,self.OnClose , btnCancel )
		self.Bind(wx.EVT_CLOSE , self.OnClose )
		self.list.Bind(wx.EVT_LEFT_DCLICK, self.OnLeftDClick)
		self.Bind(wx.EVT_LIST_ITEM_SELECTED, self.OnItemSelected, self.list)

	def OnClose( self , evt ):
		if self.IsModal():
			self.EndModal(wx.ID_OK)
		else:
			self.Destroy()
		
	def GetListCtrl( self ):
		return self.list
	
	def GetSortImages(self):
		return (self.sm_dn, self.sm_up)
	
	def OnLeftDClick( self , evt ):
		cpdm = self.list.GetItemText(self.currentItem).encode( 'gbk' )
		item = self.list.GetItem(self.currentItem, 1 )
		cplb = item.GetText().encode( 'gbk' )
		item = self.list.GetItem(self.currentItem, 2 )
		cpmc = item.GetText().encode( 'gbk' )
		self.mainframe.treeRefresh( False , cplb + " -/" + cpdm )
	
	def OnItemSelected(self, event):
		self.currentItem = event.m_itemIndex
		event.Skip()

class MyApp(wx.App):
	"""This class is even less interesting than MyFrame."""

	def OnInit(self):
		"""OnInit. Boring, boring, boring!"""
		dmlist = { 0: ( '1' , 'A0' , 'aaaa' ) ,
				   1: ( '3' , 'B0' , 'bbbb' ) 
				 }
		dlg = CPListDialog( None , 'test' , dmlist )
		dlg.ShowModal()
		return False

def main():
	app = MyApp(False)
	app.MainLoop()


if __name__ == '__main__':
	main()
