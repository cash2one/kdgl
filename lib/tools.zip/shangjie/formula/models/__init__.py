# coding: gbk

from cprmx import fx_cprmx
from cphz  import fx_cphz