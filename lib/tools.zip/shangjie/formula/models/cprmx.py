# coding: gbk

from shangjie.conf import settings
from shangjie.utils.db import table_create
from sqlalchemy import *

#��������
@table_create( ( 'hy' , 'jg' , 'kh' , 'zh' , 'qj' ) , zqdm = 'M' )
def fx_cprmx( wd , zqdm ):
    d = { 'hy': Column( 'hydm' , Integer ) ,        # ��Ա����
          'jg': Column( 'jgdm' , String(10) ) ,     # ��������
          'kh': Column( 'khid' , Integer ) ,        # �ͻ�ID
          'zh': Column( 'zh'   , String(30) ) ,     # �˺�
          'qj': Column( 'dummy' , String(1) ) ,     # �����Կ��ǵ��ֶΣ�ȫ�ֲ�Ʒ��ʹ��
        }
    def aa(i):
        return Column( "zb%02d" % i , Numeric(20,6) , default = 0 )  #ָ����

    t = Table( 'fx_%scprmx_%s' % ( wd , zqdm ) ,
                settings.META_DATA , 
                Column( 'rq' , Date ) ,           # ����
                d[ wd ] , 
                Column( 'cpdm' , String( 30 ) ) , # ��Ʒ����
                Column( 'pickle' , PickleType , nullable = True ) , # �����ֶ�
                Column( 'idx' , String(100) , nullable = True ) , # ����
                Column( 'zb'   , Numeric( 20 , 6 ) , default = 0 ) , # ָ������
                *map( aa , range( 2 , 21 ) ) 
             )
    if wd == 'hy':
        colwd = t.c.hydm
    elif wd == 'jg':
        colwd = t.c.jgdm
    elif wd == 'kh':
        colwd = t.c.khid
    elif wd == 'zh':
        colwd = t.c.zh
    elif wd == 'qj':
        colwd = t.c.dummy 
    return ( t, 
             Index( 'fx_%scprmx_%s_u' % ( wd , zqdm ) , 
                    t.c.rq , 
                    colwd , 
                    t.c.cpdm , 
                    t.c.idx , 
                    unique=True )
           )