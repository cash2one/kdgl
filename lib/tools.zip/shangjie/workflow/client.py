# coding: gbk

from Pyro.errors import *
import Pyro.core
import Pyro.naming

Pyro.config.PYRO_MOBILE_CODE=1      # Enable mobile code
Pyro.config.PYRO_NS_DEFAULTGROUP=":wf"

locator = Pyro.naming.NameServerLocator()
print 'Searching Naming Service...'
ns = locator.getNS()

try:
    URI=ns.resolve('workflow')
except Pyro.core.PyroError,x:
    print "workflow engine can't be found:" , x
    raise SystemExit

wf = Pyro.core.getAttrProxyForURI( URI )

print wf.get_version()
l = wf.getflow( '3' )
print '��Ա[3]����������������:'
for lc in l:
    print '\t%s|%s|%s' % ( lc.id, lc.zwmc, lc.xmlpath )