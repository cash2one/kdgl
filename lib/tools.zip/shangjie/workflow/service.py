# coding: gbk


import sys
import Pyro.naming
import Pyro.core
from Pyro.errors import PyroError,NamingError

import interface

group = ':wf'   # the namespace group for all test servers

def main():
    # initialize the server and set the default namespace group
    Pyro.core.initServer()
    Pyro.config.PYRO_NS_DEFAULTGROUP=":wf"

    # locate the NS
    print 'Searching Naming Service...'
    locator = Pyro.naming.NameServerLocator()
    ns = locator.getNS()

    # make sure our namespace group exists
    try:
        ns.createGroup(group)
    except NamingError:
        pass

    daemon = Pyro.core.Daemon()
    daemon.useNameServer(ns)
    cleanupAge=20
    daemon.setTransientsCleanupAge(cleanupAge)
    print '>>>The maximum account inactivity age is',cleanupAge,'seconds<<<'

    # connect a new object implementation (first unregister previous one)
    try:
        ns.unregister('workflow')
    except NamingError:
        pass

    # bank class is direct subclass of Pyro.core.ObjBase
    daemon.connect(interface.Workflow(),'workflow')

    # enter the service loop.
    print 'workflow engine ready now'
    daemon.requestLoop()
    
if __name__ == '__main__':
    main()
