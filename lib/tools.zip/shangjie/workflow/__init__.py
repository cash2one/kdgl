# coding: gbk

from shangjie.conf import settings

settings.register( 'oaconf' )

from shangjie.utils import isqln
isqln.install()