# coding: gbk
from ctypes import *
STRING = c_char_p

_stdcall_libraries = {}
_stdcall_libraries['ApplicationApi.dll'] = WinDLL('ApplicationApi.dll')


API_ERRCODE = c_int # enum
ONAPPSTOP = WINFUNCTYPE(None, STRING, c_int)
ONRECVMSG = WINFUNCTYPE(None, STRING, STRING, STRING, STRING, STRING, STRING, STRING, c_long, c_ulong)
class tagEVENTHANDLER(Structure):
    pass
tagEVENTHANDLER._fields_ = [
    ('AppStopHandler', ONAPPSTOP),
    ('MsgHandler', ONRECVMSG),
]
PEVENTHANDLER = POINTER(tagEVENTHANDLER)
EVENTHANDLER = tagEVENTHANDLER

StartApp = _stdcall_libraries['ApplicationApi.dll'].StartAppA
StartApp.restype = c_int
StartApp.argtypes = [STRING, c_ushort, STRING, STRING, POINTER(tagEVENTHANDLER), c_int, STRING, c_int]
StopApp = _stdcall_libraries['ApplicationApi.dll'].StopAppA
StopApp.restype = c_int
StopApp.argtypes = [STRING]
SendMsg = _stdcall_libraries['ApplicationApi.dll'].SendMsgA
SendMsg.restype = c_int
SendMsg.argtypes = [STRING, STRING, STRING, STRING, STRING, STRING, c_ulong, c_int, STRING, c_int]
RegisterApp = _stdcall_libraries['ApplicationApi.dll'].RegisterAppA
RegisterApp.restype = c_int
RegisterApp.argtypes = [STRING, c_ushort, STRING, STRING, c_int, STRING, STRING, c_int]
UnRegisterApp = _stdcall_libraries['ApplicationApi.dll'].UnRegisterAppA
UnRegisterApp.restype = c_int
UnRegisterApp.argtypes = [STRING, c_ushort, STRING, STRING, c_int]
