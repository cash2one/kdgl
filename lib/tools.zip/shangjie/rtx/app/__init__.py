# coding: gbk

from rtxapi import ONAPPSTOP , ONRECVMSG , EVENTHANDLER , StartApp , StopApp , SendMsg , RegisterApp , UnRegisterApp , STRING

from shangjie.conf import settings
import shangjie.utils.apis

import threading
from ctypes import *
import time , datetime

class AppPlugin:
    
    def __init__( self , guid , name , level = 5 , action="Copy" , reqt = 'ALL' , rspt = 'ALL' , sender = 'AnyOne' , rcv = ( 'anystate' , 'AnyOne' ) ):
        """
            <Action>Copy, Distill</Action>
            <AppName>ALL( �������� )</AppName>
            <Request_Type>ALL</Request_Type> 
                    ->  Tencent.RTX.OrgStruct
                        Tencent.RTX.Store
                        Tencent.RTX.P2P
                        Tencent.RTX.ClientObjects
                        Tencent.RTX.Session
                        Tencent.RTX.MDSession
                        Tencent.RTX.UserSelector
                        Tencent.RTX.IM // IM��Ϣ 
                        Tencent.RTX.UserProfile
                        Tencent.RTX.FileTransfer
                        Tencent.RTX.RTXLogin
                        Tencent.RTX.Sms //�ֻ�����
                        Tencent.RTX.Config
                        Tencent.RTX.P2P
                        Tencent.RTX.SYSMSG //ϵͳ��Ϣ
                        Tencent.RTX.SearchUsers
                        Tencent.RTX.LocalTabManager
                        Tencent.RTX.OffMsgModule
                        Tencent.RTX.UpdateModule
                        Tencent.RTX.Alert //��Ϣ���� 
                        Tencent.RTX.BroadCast
                        Tencent.RTX.RTXCSDK
                        Tencent.RTX.Watcher
                        Tencent.RTX.MsgManager
                        Tencent.RTX.RTXPhone
                        Tencent.RTX.RightMgr
                        Tencent.RTX.UserDefineWizard
                        Tencent.RTX.RTXCPro
                        Tencent.RTX.changestate //�ͻ���״̬ 
            <Response_Type>ALL, None</Response_Type>
            <Sender>AnyOne</Sender>
                    -> AnyOne ��;�ָ�Ķ����
            <Receiver StateType="anystate">AnyOne</Receiver>
                    -> Online��offline��away
                    -> AnyOne ��;�ָ�Ķ����
        """
        self.guid = guid #'{%s}' % uuid.uuid1().urn.split( ':' )[-1]
        self.name = name
        self.level = level
        self.xml = """\
<?xml version="1.0" encoding="GB2312"?>
<AppRegInfo>
    <Action>%s</Action>
    <AppName>ALL</AppName>
    <Request_Type>%s</Request_Type>
    <Response_Type>%s</Response_Type>
    <Sender>%s</Sender>
    <Receiver StateType="%s">%s</Receiver>
</AppRegInfo>""" % ( action , reqt , rspt , sender , rcv[0] , rcv[1] )
        
        self.lock = threading.Lock()
        
    def start( self , threads = 1 ):
        # �����߳�
        result = create_string_buffer( 512 )
        nret = RegisterApp( settings.RTXSERVER , int( settings.RTXPORT ) , self.guid , self.name , self.level , self.xml , cast( result , STRING ) , 512 )
        if nret:
            raise RuntimeError( 'RTX APP[%s]ע��ʧ��[%s]: %s' % ( self.name , nret , result.value ) )
        
        eh = EVENTHANDLER()
        eh.MsgHandler = ONRECVMSG( self.onrecvmsg )
        eh.AppStopHandler = ONAPPSTOP( self.onappstop )
        
        nret = StartApp( settings.RTXSERVER , int( settings.RTXPORT ) , self.guid , "" , byref( eh ) , threads , cast( result , STRING ) , 512 )
        if nret:
            raise RuntimeError( 'RTX APP[%s]����ʧ��[%s]: %s' % ( self.name , nret , result.value ) )
    
    def stop( self ):
        print 'stoping...'
        result = create_string_buffer( 512 )
        StopApp( self.guid )
        r = UnRegisterApp( settings.RTXSERVER , int( settings.RTXPORT ) , self.guid , cast( result , STRING ) , 512 )
        print 'stoped' , r
        
    def daemon( self ):
        print 'daemon started'
        try:
            while True:
                time.sleep( 1 )
        except:
            self.stop()
            
    def onrecvmsg( self , lpszguidApp, lpszAppName, lpszMsgType , lpszSender , lpszReceivers , lpszOfflineReceivers , lpszMsg , tSendTime , dwFlag ):
        """
            ��׼�������������ڷּ�ͬ�����Ϣ�������ò�ͬ��Ϣ��Ӧ�Ĵ�����������������ʹ��Сд��ĸ
        """
        m = lpszMsgType.split( '.' )[ -1 ]
        rcvs = set( filter( None , map( lambda x: x.strip() , lpszReceivers.split( ';' ) ) ) )
        offrcvs = set( filter( None , map( lambda x:x.strip() , lpszOfflineReceivers.split( ';' ) ) ) )
        onrcvs = rcvs - offrcvs
        dt = datetime.datetime.fromtimestamp( tSendTime )
        func = getattr( self , 'on_' + m.lower() , None )
        if callable( func ):
            func( lpszMsgType , lpszSender , list( onrcvs ) , list( offrcvs ) , dt , lpszMsg )
        else:
            self.default( lpszMsgType , lpszSender , list( onrcvs ) , list( offrcvs ) , dt , lpszMsg )
        
    def onappstop( self , lpszguidApp , iCode ):
        pass
    
    def default( self , msgtype , sender , onrcvs , offrcvs , dt , msg ):
        print threading._get_ident() , msgtype , sender , onrcvs , offrcvs , dt , msg
    
    def on_changestate( self , msgtype , sender , onrcvs , offrcvs , dt , msg ):
        """
            �û�״̬�仯
            <RTXCData>
                <Item Key="Command" Type="String">STATECHANGE</Item>
                <Item Key="UserName" Type="String">�ſ�</Item>
                <Item Key="OldState" Type="String">Online</Item>
                <Item Key="NewState" Type="String">Offline</Item>
            </RTXCData>
        """
        root = xml( msg )
        items = xmlread( root , 'Item' , [ 'Key' , None ] )
        if hasattr( self , 'changestate' ) and callable( self.changestate ):
            d = dict( items )
            self.changestate( dt = dt , **d )
    
    def on_im( self , msgtype , sender , onrcvs , offrcvs , dt , msg ):
        """
            �û�������Ϣ
            <RTXCData>
                <Item Key="Mode" Type="Long">0</Item><Item Key="Content" Type="String">&lt;RTXMsg Ver="1.0"&gt;
            &lt;Content&gt;
            &lt;Txt&gt;123&lt;/Txt&gt;
            &lt;Font Name="����" CharSet="134" PAF="2" Size="9" YOffset="0" Effects="0" Color="6684927"/&gt;
            &lt;/Content&gt;
            &lt;/RTXMsg&gt;
                </Item>
                <Item Key="Title" Type="String">123</Item>
                <Item Key="Initiator" Type="String">�ſ�</Item>
                <Item Key="Key" Type="String">{D819715B-0A9B-4FFC-BBD8-B6979DBDA9EC}</Item>
                <Item Key="im_message_id" Type="Buffer">EAAAAKj65AtE+8BMsfNyGYbNPtg=</Item>
            </RTXCData>
            ���У�Mode      0 ��Ե���Ϣ
                            1 Ⱥ��Ϣ
                  Content   ��Ϣ���ݣ�����һ��XML�����������õĻ���Txt��
                            <RTXMsg Ver="1.0">
                                <Content>
                                    <Txt>123</Txt>
                                    <Font Name="����" CharSet="134" PAF="2" Size="9" YOffset="0" Effects="0" Color="6684927"/>
                                </Content>
                            </RTXMsg>
                            ��Ҫע����ǣ�����б��飺Txt�е�����Ϊ\x02/jy\x03�ĸ�ʽ����ÿһ������
                                          ����н�����ͼƬ�ļ����Զ�����飺Txt�е�����Ϊ��\x18 xxxx \x19����ÿһ��ͼƬ��
                  Initiator �Ự������
                  Key       �ỰΨһ��ʶ
        """
        #print repr( msg )
        # ��ǰ���� ������xml�淶 �ı��顢ͼƬ
        if '\x02' in msg:
            msg = msg.replace( '\x02' , '[' )
            msg = msg.replace( '\x03' , ']' )
        if '\x18' in msg:
            msg = msg.replace( '\x18' , '[' )
            msg = msg.replace( '\x19' , ']' )
            
        root = xml( msg )
        items = dict( xmlread( root , 'Item' , [ 'Key' , None ] ) )
        root2 = xml( items[ 'Content' ] )
        txt   = xmlread( root2 , 'Content/Txt' , None )
        if hasattr( self , 'im' ) and callable( self.im ):
            self.im( dt , sender , onrcvs , offrcvs , initiator = items['Initiator'] , content = txt , cid = items[ 'Key' ] , mode = items[ 'Mode' ] )
    
if __name__ == '__main__':
    settings.RTXSERVER = '127.0.0.1'
    settings.RTXPORT   = '8006'
    guid = '{cdc413c0-5c63-11dd-ba36-005056c00008}'
    
    class DemoApp( AppPlugin ):
        def changestate( self , Command = None , UserName = None , OldState = None , NewState = None , dt = None ):
            print Command , UserName , OldState , '->' , NewState , dt
        
        def im( self , dt , sender , onrcvs , offrcvs , initiator = None , content = None , cid = None , mode = None ):
            print '�Ự%s(��[%s]����) %s��Ϣ��������[%s]��������(����)��%s��������(����)��%s' % ( cid , initiator , dt , sender , ','.join( onrcvs ) , ','.join( offrcvs ) ) 
            print content
        
    a = DemoApp( guid , 'RTX.AllFilter' )
    a.start( 10 )
    a.daemon()