# coding: gbk

"""
    ʹ�� COM ��ʵ����Ϣ���͹���
"""

from win32com.client import Dispatch

try:
    rtxobj = Dispatch( 'rtxserver.rtxobj' )
    rtxobj.Name = "SYSTOOLS"
except:
    rtxobj = None

def convert_rcvs( rcvs , sep = ';' ):
    if type( rcvs ) in ( list , tuple ):
        rcvs = sep.join( rcvs )
    elif rcvs is None:
        rcvs = ''
    return rcvs
    
def send_alert( rcvs = None , title = 'ϵͳ֪ͨ' , msg = '' , delay = 1000 ):
    if rtxobj:
        rtxparams = Dispatch("rtxserver.collection")
        
        mode = 0
        if not rcvs:
            mode = 0x11  # ���͸�������
        
        rcvs = convert_rcvs( rcvs )
        
        rtxparams.Add( "SENDMODE", mode )
        rtxparams.Add( "USERNAME" , rcvs )
        rtxparams.Add( "MSGINFO", msg )
        rtxparams.Add( "TITLE", title )
        rtxparams.Add( "MSGID", "1234567" )
        rtxparams.Add( "ASSTYPE", "0" )
        rtxparams.Add( "DELAYTIME", delay )
        
        rtxparams.Add( "TYPE", 0 )
        
        rst = rtxobj.Call2( 0x2100, rtxparams )


def send_msg( sender , pwd , rcvs = None , msg = '' ):
    if rtxobj:
        rtxparams = Dispatch("rtxserver.collection")

        rtxparams.Add( "SENDER" , sender )
        rtxparams.Add( "RECVUSERS" , convert_rcvs( rcvs ) )
        rtxparams.Add( "IMMSG" , msg )
        rtxparams.Add( "SDKPASSWORD" , pwd )
        
        res = rtxobj.Call2( 0x2002, rtxparams )

if __name__ == '__main__':
    send_msg( '�����' , '' , [ '�ſ�' , ] , msg = '����python��������' )
    