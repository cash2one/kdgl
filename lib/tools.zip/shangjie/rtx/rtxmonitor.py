# coding: gbk
from shangjie.conf import settings

from shangjie.rtx.app import AppPlugin
import threading

import Queue

queue = Queue.Queue()

def write_to_db():
    while True:
        d = queue.get()
        print d
        if d == 'exit':
            break
        #queue.task_done()

class RTXMonitor( AppPlugin ):
    threads = {}
    
    def get_connect( self ):
        se = RTXMonitor.threads.get( threading._get_ident() , None )
        if se is None:
            se = settings.DB_ENGINE.connect().connection.connection # ̫��ª�ˣ���ȡsqlalchemy��ʵ�ʵ����Ӷ���
            RTXMonitor.threads[ threading._get_ident() ] = se
        return se
    
    def changestate( self , Command = None , UserName = None , OldState = None , NewState = None , dt = None ):
        #print 'changestate'
        #con = self.get_connect()
        #cur = con.cursor()
        #cur.execute( "insert into rtx_rtxlog( syr , lb , msg , crttime ) values( %s , %s , %s , %s )" , [ UserName , 'changestate' , '%s->%s' % ( OldState , NewState ) , dt ] )
        #con.commit()
        #cur.close()
        print 'changestate'
        queue.put( ( 'changestate' , dict( syr = UserName , lb = 'changestate' , msg = '%s->%s' % ( OldState , NewState ) , crttime = dt ) ) )
        #queue.put( 'changestate' )
        #try:
        #    print 'changestate'
        #    #se = self.get_session()
        #    obj = RTX_RTXLOG( syr = UserName , lb = 'changestate' , msg = '%s->%s' % ( OldState , NewState ) , crttime = dt )
        #    #se.save( obj )
        #    #se.flush()
        #except:
        #    import sys,traceback
        #    print ''.join( traceback.format_exception( *sys.exc_info() ) )
    
    def im( self , dt , sender , onrcvs , offrcvs , initiator = None , content = None , cid = None , mode = None ):
        print 'im'
        #se = settings.DB_SESSION()
        #obj = RTX_RTXLOG( syr = sender , lb = 'im' , msg = content , crttime = dt , hhid = cid , 
        #                  cjz = initiator , zxjsz = ';'.join( onrcvs ) , lxjsz = ';'.join( offrcvs ) )
        #se.save( obj )
        #se.flush()
        #se.close()

    def default( self , msgtype , sender , onrcvs , offrcvs , dt , msg ):
    #    print threading._get_ident() , msgtype , sender , onrcvs , offrcvs , dt , msg
        pass