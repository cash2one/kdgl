# coding: gbk

from shangjie.conf import settings

settings.check( 'RTXSERVER' , 'RTXPORT' )
