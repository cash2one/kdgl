# coding: gbk

"""
    ʹ�� COM ��ʵ�ֵ����¼
"""

from win32com.client import Dispatch
from shangjie.conf import settings

try:
    rtxobj = Dispatch( 'rtxserver.rtxobj' )
    rtxobj.Name = "SYSTOOLS"
    rtxobj.ServerIP = settings.RTXSERVER
    rtxobj.ServerPort = int( settings.RTXPORT )
except Exception , e:
    rtxobj = None

def get_session_key( username ):
    if rtxobj:
        rtxparams = Dispatch("rtxserver.collection")
        rtxparams.Add( "USERNAME" , username )
        
        rt = rtxobj.Call2( 0x2000 , rtxparams )
        return rt

def get_user_status( username ):
    if rtxobj:
        rtxparams = Dispatch("rtxserver.collection")
        rtxparams.Add( "USERNAME" , username )
        
        rt = rtxobj.Call2( 0x2001, rtxparams)
        
        return { 1: 'online' , 0: 'offline' , 2: 'away' , 11: '������' }.get( rt , 'δ֪״̬' )

if __name__ == '__main__':
    sk = get_session_key( '�ſ�' )
    print sk
    """
    rtxcli = Dispatch( 'RTXClient.RTXAPI' )
    objProp = rtxcli.GetObject("Property")
    objProp.SetValue( "RTXUsername" , "�ſ�" )
    objProp.SetValue( 'LoginSessionKey' , sk )
    objProp.SetValue( 'ServerAddress' , "192.168.3.177" )
    objProp.SetValue( 'ServerPort' , 8011 )
    
    print objProp.Keys.Count
    
    print rtxcli.Call( 0x2 , objProp )
    
    raw_input()
    """

