# coding: gbk
# ���ܶ���

from shangjie.conf import settings
from sqlalchemy import *
from shangjie.utils.db import table_create

@table_create()
def fw_flowrun():
    t = Table( 'fw_flowrun',
                settings.META_DATA , 
                Column( 'id', Integer , primary_key = True ), # ID
                Column( 'gcmc', String(100) ), # ��������
                Column( 'lct', PickleType ),   #����ͼ
                Column( 'hdmc', String(100) ), # ��ǰ�����
                Column( 'cjsj', DateTime ), # ����ʱ��
                Column( 'zt', String(40) ) # �����
             )
    return ( t, 
             Index( 'fw_flowrun_i1', 
                    t.c.gcmc, 
                    unique=False),
             Index( 'fw_flowrun_i2', 
                    t.c.hdmc, 
                    unique=False )
           )