# coding: gbk
# ���ܶ���

from shangjie.conf import settings
from sqlalchemy import *
from shangjie.utils.db import table_create

@table_create()
def fw_activerun():
    t = Table( 'fw_activerun',
                settings.META_DATA , 
                Column( 'id', Integer , primary_key = True ), # ID
                Column( 'gcid', Integer  ), # ����id
                Column( 'hdmc', String(100) ), # �����
                Column( 'cjsj', DateTime ), # ����ʱ��
                Column( 'zt', String(40) ) # �����
             )
    return ( t, 
             Index( 'fw_activerun_i1', 
                    t.c.gcid, 
                    unique=False),
             Index( 'fw_activerun_i2', 
                    t.c.hdmc, 
                    unique=False )
           )