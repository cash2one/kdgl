# coding: gbk
# �����������ඨ��

flows = {}
from shangjie.forwork.models import fw_activerun,fw_flowrun
import datetime
from shangjie.conf import settings
from shangjie.utils.functools import AttrDict
from sqlalchemy import *
from shangjie.utils.globaldata import globaldata

activetabobj = fw_activerun()[0]
flowtabobj = fw_flowrun()[0]

class Flow( object ):
    def __init__( self , name , lct , *args , **kwargs ):
        self.lct = lct
        self.args = args
        self.kwargs = kwargs
        self.name = name
        print "��ʼ����������[%s]"%self.name

    def __call__( self , *args , **kwargs):
        print "������������[%s][%s]"%(self.name,datetime.datetime.now())

        self.gInst = globaldata()
        con = self.gInst.con
        sql = "select * from fw_flowrun where gcmc = '%s' and zt != '���' "%self.name
        r = con.execute(sql)
        row = r.fetchone()
        if row:
            self.flowid = row['id']
            self.beginactivename = row['hdmc']
        else:
            r = con.execute( flowtabobj.insert() , { 'gcmc':self.name , 'hdmc':'  ' , 'lct':self.lct ,'cjsj':datetime.datetime.now() , 'zt':'��ʼ' } )
            self.flowid = r.last_inserted_ids()[0]
            
        sql = "select * from fw_activerun where gcid = %d and zt = '���'" %self.flowid
        r = con.execute(sql)
        activer = []
        for row in r:
            activer.append(row['hdmc'])
            
        cljl = 0     
        for subactive in self.lct:
            print '��ʼ�:',subactive.name
            if subactive.name in activer:
                print 'already run,skip'
                continue
            sql = "update fw_flowrun set hdmc = '%s' ,zt = '������' where id  = %d"%(subactive.name,self.flowid )
            con.execute(sql)
            subactive.begin(self.gInst,activetabobj,self.flowid,subactive.name)
            subactive(self.gInst,*args , **kwargs)
            subactive.end(self.gInst,'���')
            cljl += 1
        if len(self.lct) == ( len(activer) + cljl ):
            sql = "update fw_flowrun set zt = '���' where id  = %d"%self.flowid 
            con.execute(sql)
        
            print "������������[%s][%s]"%(self.name,datetime.datetime.now())

class Active( object ):
    def __init__( self , name , *args , **kwargs ):
        self.args = args
        self.kwargs = kwargs
        self.activeid = 0
    
    def __call__( self , gInst ):
        pass
    
    def begin( self, gInst, t, gcid , hdmc ):
        con = gInst.con
        r = con.execute( t.insert() , { 'gcid':gcid , 'hdmc':hdmc , 'cjsj':datetime.datetime.now() , 'zt':'��ʼ' } )
        self.activeid = r.last_inserted_ids()[0]

    def end(self,gInst,zt):
        con = gInst.con
        sql = "update fw_activerun set zt = '%s' where id = %d"%(zt,self.activeid)
        con.execute(sql)


       
       