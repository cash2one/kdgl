# coding: gbk

"""
    Tree���ݽṹ��ʵ��
"""
from django.utils.datastructures import SortedDict

class TreeNode( object ):
    def __init__( self , key , value = None , parent = None ):
        self.key = key
        self.value = value
        self.parent = parent
        self.next = SortedDict()
    
    def count( self , key = None ):
        count = 0
        for k , v in self.next.items():
            if key is None or ( callable( key ) and key( k , v.value ) ):
                count += 1
        return count 
    
    def filter( self , key = None ):
        ret = []
        for k , v in self.next.items():
            if key is None or ( callable( key ) and key( k , v.value ) ):
                ret.append( v )
        if len( ret ) == 0:
            return None
        elif len( ret ) == 1:
            return ret[0]
        else:
            return ret
    
    def __setitem__( self , key , value ):
        if not isinstance( value , TreeNode ):
            value = TreeNode( key , value , self )
        self.next[ key ] = value
    
    def __getitem__( self , key ):
        return self.next[ key ]
    
    def get_children( self ):
        return self.next
    
    def find_root( self ):
        r = self
        while r.parent:
            r = r.parent
        return r
    
    def get_from_path( self , path = '' , sep = '/' ):
        """
            ���·�����д���
        """
        try:
            if not path:
                return self
            
            path = path.rstrip( sep )
            ps = path.split( sep , 1 )
            if len( ps ) == 0:
                return self
            
            if ps[0] == '':
                # Ѱ�Ҹ��ڵ㣬Ȼ��ִ��
                r = self.find_root()
            elif ps[0] == '.':
                # �Լ�
                r = self
            elif ps[0] == '..':
                # ���ڵ�
                r = self.parent
            else:
                # �ӽڵ�
                r = self.next[ ps[0] ]
                
            if len( ps ) == 1:
                return r
            else:
                return r.get_from_path( ps[1] )
        except KeyError:
            return None

    def get_dotpath( self , path ):
        """
            ��ָ��·��
        """
    
    def _get_path( self ):
        p = []
        r = self
        while r:
            p.insert( 0 , r.key )
            r = r.parent
        return p
        
    path = property( _get_path )
    
    def __repr__( self ):
        return '.'.join( map( str , self.path ) ) + '  ==>  ' + repr( self.value )
        
    def print_tree( self , func = None , sort = None ):
        out = []
        def build_tree( tobj , prefix , parent_next , self_next , level ):
            n_prefix = prefix + ( ( '��' if level > 1 else '' ) if parent_next == False else '��' )
            out.append( n_prefix + ( ( '��' if self_next == False else '��' ) if level > 0 else '' ) + tobj.key + '  ' + ( func( tobj.value ) if func else repr( tobj.value ) ) )
            ch = tobj.get_children().values()
            if sort:
                ch = sort( ch )
            ma = len( ch )
            for i in range( ma ):
                build_tree( ch[ i ] , n_prefix , self_next , i < ma-1 , level + 1 )
                
        #children = self.next.values()
        #maxc = len( children )
        #for i in range( maxc ):
        #    build_tree( children[ i ] , '' , False , i < maxc-1 )
        build_tree( self , '' , False , False , 0 )
        
        return out
    
if __name__ == '__main__':
    r = TreeNode( 'v' )
    print r.get_from_path( '/' )
    print r.get_from_path()
    print r.get_from_path( '.' )
    print r.get_from_path( '..' )
    r[ 'branch' ] = None
    r[ '1' ] = 'aaa'
    print r.get_from_path( 'branch' )
    print r.get_from_path( '/branch' )
    print r.get_from_path( './branch' )
    t = r.get_from_path( 'branch' )
    t[ 'bbb' ] = 'cccc'
    print 't' , t
    print t.get_from_path( '/' )
    print t.get_from_path()
    print t.get_from_path( '..' )
    print t.get_from_path( r'\branch\\' , sep = '\\' )
    print 'aaa'
    print '\n'.join( r.print_tree() )
    