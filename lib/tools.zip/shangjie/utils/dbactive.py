# coding: gbk

from shangjie.forwork.classdef import Active
from shangjie.utils.db import tableload

class DataLoad( Active ):
    def __init__(self,name, args ):
        self.args = args
        self.name = name
        
    def __call__(self,gInst,*args):
        con = gInst.con
        for sub_arg in self.args:
            trans = con.begin()
            try:
                if isinstance( sub_arg, str ):
                    con.execute( sub_arg )
                elif isinstance( sub_arg, dict ):
                    tableload( con,**sub_arg )
                trans.commit()
            except:
                trans.rollback()

