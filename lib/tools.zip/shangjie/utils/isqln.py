# coding: gbk 

import gettext , os 

from shangjie.conf import settings

settings.check( 'SQL_LOCATION' , 'DB_ENGINE' )

def install(): 
    import __builtin__ 
    if '_sql_' not in __builtin__.__dict__:
        t = gettext.translation('sqls', settings.SQL_LOCATION , [settings.DB_ENGINE.name,] ) 
        __builtin__.__dict__['_sql_'] = t.ugettext
        __builtin__.__dict__['placeholder'] = { 'postgres':'%s' , 'informix':'%s' , 'db2':'?' , 'oracle':'?' }.get( settings.DB_ENGINE.name , '?' )
