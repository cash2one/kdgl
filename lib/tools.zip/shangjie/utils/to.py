# coding: gbk

di = { '0' : '0000' , 
       '1' : '0001' , 
       '2' : '0010' , 
       '3' : '0011' , 
       '4' : '0100' , 
       '5' : '0101' , 
       '6' : '0110' , 
       '7' : '0111' , 
       '8' : '1000' , 
       '9' : '1001' , 
       'A' : '1010' , 
       'B' : '1011' , 
       'C' : '1100' , 
       'D' : '1101' , 
       'E' : '1110' , 
       'F' : '1111' 
     }

def to_bin( x ):
    a = '%02X' % ord( x )
    print di[a[0]] , di[a[1]]

import cStringIO

def to_hex( s ):
    st = cStringIO.StringIO()
    
    def fmt( x ):
        if ord( ' ' ) <= ord( x ) <= ord( '\x7E' ):
            return x
        return '.'
    i = 0
    end = 0
    line = ''
    if type( s ) != str:
        s = str( s )
    for c in s:
        i += 1
        if i % 16 == 1:
            line += '%04X: ' % ( i - 1 , )
        line += '%02X ' % ord(c)
        if i % 8 == 0 and ( i / 8 ) % 2 == 1 :
            line += '- '
        if i % 16 == 0:
            line += ' ' + ''.join( map( fmt , s[i-16:i] ) )
            st.write( line + '\n' )
            line = ''
            end = i
    if line :
        line += ' ' * ( 56 - len( line ) )
        st.write( line )
        st.write( ' ' + ''.join( map( fmt , s[end:] ) ) + '\n' )
    return st.getvalue()
    
def from_hex( s ):
    import binascii
    datastr = s.replace( " " , "" ).replace( "\n" , "" ).replace( "-" , "" )
    d = binascii.a2b_hex( datastr )
    return d
