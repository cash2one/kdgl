# coding: gbk
# ʵ�ֿ����ڳ��η���ʱ��ʼ����LazyObject����
from UserDict import UserDict
from UserList import UserList
import types

class LazyDict( UserDict ):
    def __init__( self, fun=None, *args, **kwargs ):
        self.__dict__[ 'init' ] = False
        self.__dict__[ 'data' ] = {}
        self.__dict__[ 'fun' ] = fun
        self.__dict__[ 'args' ] = args
        self.__dict__[ 'kwargs' ] = kwargs
    
    def set_fun( self, method, *args, **kwargs ):
        self.fun = method
        self.args = args
        self.kwargs = kwargs
        self.data.clear()
        self.init = False
    
    def reset( self ):
        self.data.clear()
        self.init = False
    
    def __str__( self ):
        return repr( self.data )
    
    def __iter__(self):
        if self.init == False: self.initdata()
        return iter(self.data)
    
    def __getattr__( self , key ):
        try:
            return self.__dict__[ key ]
        except KeyError:
            return self.__getitem__( key )
    
    def __setattr__( self, key, value ):
        if key in self.__dict__.keys():
            self.__dict__[ key ] = value
        else:
            if self.init == False: self.initdata()
            self.data[ key ] = value
    
    def __getitem__( self , key ):
        if self.init == False: self.initdata()
        return UserDict.__getitem__( self, key )
    
    def __setitem__( self, key, item ):
        if self.init == False: self.initdata()
        UserDict.__setitem__( self, key, item )
    
    def keys( self ):
        if self.init == False: self.initdata()
        return UserDict.keys( self )
    
    def values( self ):
        if self.init == False: self.initdata()
        return UserDict.values( self )
    
    def items( self ):
        if self.init == False: self.initdata()
        return UserDict.items( self )
    
    def initdata( self ):
        d = self.kwargs.pop( '__dict__', {} )
        if len( d ):
            self.update( d )
        if self.fun is not None:
            x = self.fun( *self.args, **self.kwargs )
            if isinstance( x , dict ):
                self.update( x )
            elif isinstance( x , types.GeneratorType ) or \
                 isinstance( x , tuple ) or \
                 isinstance( x , list ):
                self.update( dict( x ) )
            else:
                raise RuntimeError( '�������صĽ���޷��Զ�ӳ��Ϊ�ֵ�' )
        self.init = True
#=======================================================================================================================
class LazyList( UserList ):
    def __init__( self, fun=None, *args, **kwargs ):
        self.__dict__[ 'init' ] = False
        self.__dict__[ 'data' ] = []
        self.__dict__[ 'fun' ] = fun
        self.__dict__[ 'args' ] = args
        self.__dict__[ 'kwargs' ] = kwargs
    
    def set_fun( self, method, *args, **kwargs ):
        self.fun = method
        self.args = args
        self.kwargs = kwargs
        self.data = []
        self.init = False
    
    def reset( self ):
        self.data = []
        self.init = False
    
    def __getitem__( self , i ):
        if self.init == False: self.initdata()
        return UserList.__getitem__( self, i )
    
    def __setitem__( self, i, item ):
        if self.init == False: self.initdata()
        UserList.__setitem__( self, i, item )
    
    def append( self, item ):
        if self.init == False: self.initdata()
        UserList.append( self, item )
    
    def initdata( self ):
        l = self.kwargs.pop( '__dict__', [] )
        if len( l ):
            if type(l) == type(self.data):
                self.data[:] = l
            elif isinstance(l, UserList):
                self.data[:] = l.data[:]
            else:
                self.data = list(l)
        if self.fun is not None:
            x = self.fun( *self.args, **self.kwargs )
            if isinstance( x , list ) or \
               isinstance( x , types.GeneratorType ) or \
               isinstance( x , tuple ):
                self.extend( x )
            else:
                raise RuntimeError( '�������صĽ���޷��Զ�ӳ��Ϊ�б�' )
        self.init = True
#=======================================================================================================================
class LazyObj( object ):
    def __init__( self, kls=None, limit=None, *args, **kwargs ):
        self.d = {} # ���󻺴��ֵ�
        self.l = [] # ���󴴽������б�
        self.kls = kls
        self.limit = limit
        self.args = args
        self.kwargs = kwargs
    
    def reset( self ):
        self.d.clear()
        self.l = []
    
    def get( self, index ):
        try:
            return self.d[ index ]
        except:
            s = self.kls( index, *self.args, **self.kwargs )
            # �������˻��������������ҵ�ǰ����������������޶�ֵ����ɾ�����紴�����Ƕ�key:value
            if self.limit and len(self.d)>self.limit:
                i = self.l.pop(0)
                del self.d[i]
            self.d[ index ] = s
            self.l.append( index )
            
            return self.d[ index ]
    
    __getitem__ = __getattr__ = get
#=======================================================================================================================
if 0:
    def DataProvider( gInst, lb=None ):
        # �����ṩ����
        if lb == 'upper':
            for i in range(65, 75):
                yield 'name%d' % i , chr(i)
        elif lb == 'lower':
            for i in range(65, 75):
                yield 'name%d' % (i+32) , chr(i+32)
    
    # ����LazyDict��ʵ��
    gInst = object()
    d = LazyDict( DataProvider, gInst, lb='lower' )
    print d
    #d.name = 'name'
    #print d.name66
    #print d
    for k, v in d.items():
        print k, v
    d.reset()
    print d
    for k, v in d.items():
        print k, v
    d.set_fun( DataProvider, gInst , lb='upper' )
    print d
    for k, v in d.items():
        print k, v

if 0:
    def DataProvider( gInst, lb):
        # �����ṩ����
        if lb == 'upper':
            for i in range(65, 75):
                yield chr(i)
        elif lb == 'lower':
            for i in range(65, 75):
                yield chr(i+32)
    # ����LazyList��ʵ��
    gInst = object()
    l = LazyList( DataProvider, gInst, lb='upper' )
    print l
    l[0] = 'name'
    l.append( 'sex' )
    print l
    l.reset()
    print l
    l.set_fun( DataProvider, gInst, lb='lower' )
    print l
    for i in l:
        print i,
    print
    l.reset()
    l.set_fun( None, __dict__=[1,2,3,4,5,6,7,8,9] )
    print l
    for i in l:
        print i,

if 0:
    class Record( object ):
        def __init__( self, index, *args, **kwargs ):
            print index
    
    l = LazyObj( Record, limit=10 )
    for i in range( 100, 115 ):
        print l.l
        l[i]