# coding: gbk
# sjapi�е�mako��������
#    ������settings.MAKO_DIR �� settings.MAKO_MODULES_DIR
#    ���У�MAKO_DIR �洢��̬ģ���ļ�
#          MAKO_MODULES_DIR �洢�����ģ���ļ�

from shangjie.utils.ftools import register

import sys

from mako.template import Template
from mako import runtime , exceptions

from shangjie.conf import settings

def reload():
    global d_mako_lookup , m_mako_lookup
    
    from mako.lookup import TemplateLookup
    d_mako_lookup = TemplateLookup( directories=list( settings.MAKO_DIR ) , filesystem_checks = settings.TEMPLATE_DEBUG ,
                                  disable_unicode=True , module_directory= None )
    from mako.modulelookup import ModuleTemplateLookup
    m_mako_lookup = ModuleTemplateLookup()

@register( 'sjapi' )
def render_to_string( temp_name , context = None , resp_kwargs = None , **kwargs ):
    try:
        temp = m_mako_lookup.get_template( temp_name )
    except exceptions.TemplateLookupException , e :
        temp = d_mako_lookup.get_template( temp_name )
    return _render( temp , context , **kwargs )

@register( 'sjapi' )
def render_string( temp , context = None , disable_unicode = True , **kwargs ):
    if disable_unicode:
        temp = Template( temp , disable_unicode = True )
    else:
        temp = Template( temp , output_encoding=settings.DEFAULT_CHARSET , default_filters=['decode.' + settings.DEFAULT_CHARSET , ] )
        
    return _render( temp , context , **kwargs )

def _render( temp , context = None , **kwargs ):
    exc_type = kwargs.pop( 'exc_type' , None )
    if context is None:
        context = {}
        
    context.update( kwargs )
    try:
        return temp.render( **context )
    except:
        if exc_type == 'txt':
            buf = exceptions.text_error_template( temp = temp ).render()
        else:
            buf = exceptions.html_error_template( temp = temp ).render()
        
        raise MakoTemplateError( buf )

class MakoTemplateError( Exception ):
    def __init__( self , msg ):
        self.args = []
        self.msg = msg
    
    def __str__( self ):
        return self.msg

reload()
