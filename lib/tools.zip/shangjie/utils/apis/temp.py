# coding: gbk

from mako.template import Template
from mako import runtime , exceptions

from shangjie.utils.ftools import register


@register( 'sjapi' )
def render_string( temp , context = None , **kwargs ):
    temp = Template( temp , disable_unicode = True )
    
    if context is None:
        context = {}
        
    context.update( kwargs )
    try:
        return temp.render( **context )
    except:
        buf = exceptions.text_error_template( temp = temp ).render()
        raise MakoTemplateError( buf )

class MakoTemplateError( Exception ):
    def __init__( self , msg ):
        self.args = []
        self.msg = msg
    
    def __str__( self ):
        return self.msg

if __name__ == '__main__':
    print render_string( """#coding: gbk
% for i in range( n ):
${ i }
% endfor
""" , n = 10 )
