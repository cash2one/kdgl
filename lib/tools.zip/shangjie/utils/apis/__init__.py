# coding: gbk
from shangjie.conf import settings


import xmlparse
import numberfmt
import _json
import timeout
#import temp
if settings.USE_DB:
    import resultset
if settings.MAKO_DIR:
    import _mako