# coding: gbk
from shangjie.utils.ftools import register

import rpdb2
@register( 'sjapi' )
def bp( password = 'sj' ):
    rpdb2.start_embedded_debugger(password)