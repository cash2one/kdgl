# coding: gbk

import datetime
from shangjie.utils.ftools import register

from shangjie.conf import settings

if settings.USE_DB:
    settings.check( 'DB_CONSTR' , 'DB_TYPE' , msg = '������USE_DBΪFalse' )

    if settings.DB_TYPE == 'informix':
        import informixdb as db2api
    elif settings.DB_TYPE == 'postgresql':
        import psycopg2 as db2api
    elif settings.DB_TYPE == 'oracle':
        import cx_Oracle as db2api
    elif settings.DB_TYPE == 'db2':
        import DB2 as db2api
        
class DBConnection( object ):
    def __init__( self , constr = None ):
        if constr is None:
            self.con = db2api.connect( **settings.DB_CONSTR )
        else:
            self.con = db2api.connect( **constr )
        self.cursors = []
    
    def cursor( self ):
        cursor = self.con.cursor()
        self.cursors.append( cursor )
        return cursor
    
    def has_table( self , tname , schema = None ):
        cur = self.cursor()
        if schema is None:
            cur.execute("""select relname from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname=current_schema() and lower(relname)=%(name)s""", {'name':tname.lower() } );
        else:
            cur.execute("""select relname from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname=%(schema)s and lower(relname)=%(name)s""", {'name':tname.lower() , 'schema':schema});
        return bool( cur.rowcount )
    
    def execute( self , sql , params = None ):
        cur = self.cursor()
        kind = sql.strip()[:6].lower()
        if type( params ) in ( tuple , list ):
            if len( params ) and type( params[0] ) in ( tuple , list , dict ):
                cur.executemany( sql , params )
                return cur
            if kind != 'select':
                cur.execute( sql , params )
                return cur
        elif type( params ) in ( dict , ):
            if kind != 'select':
                cur.execute( sql , params )
                return cur
        else:
            if kind!='select':
                cur.execute( sql )
                return cur
        # ʣ�µ�ȫ�ǲ�ѯ
        return sjapi.sql_execute( cur , sql , params )
        
    def begin( self ):
        if settings.DB_TYPE in ( 'informix' , 'postgresql' ) :
            pass
    
    def rollback( self ):
        self.con.rollback()
        self.close()
        # ���쳣��Ӧ�������ݿ����ӣ�������߳��µ����ݿ����һֱ�쳣
        self.con = db2api.connect( **settings.DB_CONSTR )
    
    def commit( self ):
        self.con.commit()
        self.close()
    
    def close( self ):
        map( lambda x:x.close() , self.cursors )
        self.cursors = []

@register( 'sjapi' )
def connect( constr = None ):
    return DBConnection( constr )

from contextlib import contextmanager
@register( 'sjapi' )
@contextmanager
def connection( constr = None ):
    """
    ����with����У������ṩ���ݿ����Ӷ����̰߳�ȫ
    �÷���
        with connection() as con:
            cur = con.cursor()
            cur.execute( "select * from gl_jddy where mc = '����'" )
            rs = cur.fetchone() 
            ...
    """
    con = None
    try:
        con = DBConnection( constr )
        yield con
        con.commit()
    except:
        if con:
            con.rollback()
        raise
    finally:
        if con:
            con.close()

@register( 'sjapi' )
def sql_execute( cur , sql , params = None , encoding = 'gbk' ):
    return ResultSet( cur , sql , params , encoding )

class ResultSet( object ):
    """ 
        ��cur��select���ؽ��ת��Ϊ�ɰ��ֶ����Ʒ��ʵĸ�ʽ   2010-7-30 15:58renhl����ע��
    """
    def __init__( self , cur , sql , params = None , encoding = 'gbk' ):
        """
            @param:cur   ���ݿ�����
            @param:sql   sql���  ������%s��%d����ʽ����  ����:select * from gl_hydy where hydm ='%s' and jgdm =%d
            @param:params   �����б�(��������Ϊ�б�),sql�������Ҫ�Ĳ���˳����ɵ��б�,�����������,�����б�Ϊ: ['admin' , 10 ]
            @param:encoding  ������ʽ
        """
        self.__cursor = cur
        self.fields = {}
        #self.rowno  = 0
        self.encoding = encoding
        if params:
            self.__cursor.execute( sql , params )
        else:
            self.__cursor.execute( sql )
        if self.__cursor.description == None:
            return
        for i in range( 0 , len( self.__cursor.description ) ):
            self.fields[ self.__cursor.description[i][0].lower() ] = i
        self.row_cache = []

    @property
    def rowcount( self ):
        """
            ����sql�����¼����
        """
        return self.__cursor.rowcount
    
    def printFieldName( self ):
        """
            ��ӡ��ѯ������ֶε��ֶ���
        """
        for i in self.fields.keys():
            print i ,
    
    def next( self ):
        """
            ˳��ȡ��һ����¼��ֱ��ȡ��
        """
        #self.rowno += 1
        if not self.row_cache:
            self.row_cache = self.__cursor.fetchmany( 100 )
        
        self.item = self.row_cache.pop( 0 ) if self.row_cache else None
        return self if self.item != None else None
    
    fetchone = next
    
    def __iter__( self ):
        while self.next():
            yield self
    
    def fetchall( self ):
        """
            ȡ��������
        """
        rows = []
        while self.next():
            rows.append( self.to_dict())
            #rows.append(  AttrDict(  self.to_dict( )  )  )
        return rows
    
    def getString( self , key , encoding = 'gbk' ):
        """
            ���ַ�����ʽ����ĳ���ֶε�ֵ
                @param:key  �ֶ�����
                @encoding:  ������ʽ
        """
        if isinstance( key , int ):
            v = self.item[ key ]
        else:
            idx = self.fields[ key.lower() ]
            v = self.item[ idx ]
        if type( v ) == unicode:
            return v.encode( encoding )
        elif type( v ) == str and self.encoding != encoding :
            return v.decode( self.encoding ).encode( encoding )
        elif v:
            return str( v )
        elif v is not None:
            return str(v)
        else:
            return v
    
    def getUnicode( self , key ):
        """
            ��ȡ�ֶ�key��unicodeֵ
            @param:key �ֶ�����
        """
        if isinstance( key , int ):
            v = self.item[ key ]
        else:
            idx = self.fields[ key.lower() ]
            v = self.item[ idx ]
        if type( v ) == str:
            return v.decode( self.encoding )
        elif v:
            return unicode( v )
        else:
            return v
    
    def getInt( self , key ):
        """
            ��������ʽ�����ֶ�key��ֵ
            @param: key �ֶ�����
        """
        if isinstance( key , int ):
            v = self.item[ key ]
        else:
            idx = self.fields[ key.lower() ]
            v = self.item[ idx ]
        if v:
            return int( v )
        else:
            return 0
    
    def getDouble( self , key ):
        """
            ��float�ͷ����ֶ�key��ֵ
            @param:key �ֶ�����
        """
        if isinstance( key , int ):
            v = self.item[ key ]
        else:
            idx = self.fields[ key.lower() ]
            v = self.item[ idx ]
        if v:
            return float( v )
        else:
            return 0.0
    
    def getValue( self , key ):
        """
            ��ȡĳ���ֶε�ֵ����ʲô���;ͷ���ʲô����
        """
        if isinstance( key , int ):
            v = self.item[ key ]
        else:
            idx = self.fields[ key.lower() ]
            v = self.item[ idx ]
        return v
    
    def getDate( self , key ):
        """
            ��ȡ�������ֶε�ֵ
        """
        if isinstance( key , int ):
            v = self.item[ key ]
        else:
            idx = self.fields[ key.lower() ]
            v = self.item[ idx ]
        if type( v ) == datetime.datetime:
            v = v.date()
        elif v and type( v ) != datetime.date:
            raise RuntimeError( '�������ֶβ��ɰ����ڻ�ȡ����' )
        return v
    
    def getPickle( self , key ):
        if isinstance( key , int ):
            v = self.item[ key ]
        else:
            idx = self.fields[ key.lower() ]
            v = self.item[idx]
        if type( v ) == buffer:
            return pickle_loads( v )
        else:
            return None
    
    def to_dict( self ):
        """
            ����ѯ���ת�����ֵ����ʽ����Ϊ�ֶ�����ʵ��ֵ
        """
        d = {}
        for key , i in self.fields.items():
            d[ key ] = self.item[ i ]
        return d
    
    def __getitem__( self , key ):
        """
            ��ȡĳ���ֶε�ֵ
        """
        return self.getValue( key )
    
    def __getattr__( self , key ):
        return self.getValue( key )
        
    def close( self ):
        try:
            self.__cursor.close()
        except:
            pass
    
    def mkInsert( self , tn ):
        """
            ���ղ�ѯ�����Ľ����ƴд�������
        """
        s = 'insert into ' + tn + '('
        a = self.fields.keys()
        s += ','.join( a ) 
        s += ') values ('
        vs = []
        for k in a:
            v = self.getValue( k )
            if type( v ) == type(''):
                vs.append( "'%s'" % v )
            elif type( v ) == type(0) :
                vs.append( "%d" % v )
            elif type( v ) == type(0.1):
                vs.append( "%f" % v )
            elif v == None:
                vs.append( "null" )
            else:
                vs.append( "to_date( '%s' , 'YYYYMMDD' )" % v.strftime( '%Y%m%d' ) )
        s += ','.join( vs )
        s += ')'
        return s
        

class FakeResultSet( ResultSet ):
    """ result���滻����
    """
    def __init__( self , cur , sql ):
        self.fields = {}
        self.item = []
        self.first = True
    
    def next( self ):
        if self.first :
            self.first = False
            return True
        return False
    
