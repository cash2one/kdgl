# coding: gbk

from shangjie.utils.ftools import register

import sys
if sys.version_info[:2] < ( 2 , 6 ):
    import simplejson as json
else:
    import json

@register( 'sjapi' )
def jsondumps( obj , ensure_ascii = False , encoding = 'gbk' ):
    return json.dumps( obj , ensure_ascii = ensure_ascii , encoding = encoding )

@register( 'sjapi' )
def jsonloads( buf ):
    return json.loads( buf )