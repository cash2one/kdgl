# -*- coding: gbk -*-
from shangjie.utils.ftools import AttrDict
from shangjie.utils.lazy import LazyDict, LazyList , LazyObj
from shangjie.conf import settings
from shangjie.utils.log import logger

dict_d = {}
list_d = {}
obj_d  = {}

def register_dict( desc, fun, *args, **kwargs ):
    n = fun.func_name 
    if n in dict_d.keys() or \
       n in list_d.keys() or \
       n in obj_d.keys():
        raise RuntimeError( '����%s�Ѿ���ע��' % n )
    dict_d[ n ] = fun, args, kwargs

def register_list( desc, fun, *args, **kwargs ):
    n = fun.func_name 
    if n in dict_d.keys() or \
       n in list_d.keys() or \
       n in obj_d.keys():
        raise RuntimeError( '����%s�Ѿ���ע��' % n )
    list_d[ n ] = fun, args, kwargs

def register_obj( desc , kls , *args , **kwargs ):
    n = kls.__name__
    if n in dict_d.keys() or \
       n in list_d.keys() or \
       n in obj_d.keys():
        raise RuntimeError( '��%s�Ѿ���ע��' % n )
        
    obj_d[ n ] = kls , args, kwargs

def globaldata():
    gInst = AttrDict()
    gInst.log = logger
    con = settings.DB.connect()
    gInst.con = con
    
    for k, v in dict_d.items():
        gInst[k] = LazyDict( v[0], gInst, *v[1], **v[2] )
        
    for k, v in list_d.items():
        gInst[k] = LazyList( v[0], gInst, *v[1], **v[2] )
    
    for k, v in obj_d.items():
        gInst[k] = LazyObj( v[0], gInst, *v[1], **v[2] )
        
    return gInst