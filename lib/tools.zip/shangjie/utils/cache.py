# coding: gbk

# ʵ��ͨ�õ�cacheģ��

from beaker.cache import CacheManager
from shangjie.conf import settings

__cm = CacheManager()

def get_cache( name , **kwargs ):
    if settings.CACHE_TYPE:
        kwargs[ 'type' ] = settings.CACHE_TYPE
    return __cm.get_cache( name , **kwargs )

