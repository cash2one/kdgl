# coding: gbk

class MessageQueueFull( Exception ):
    pass

class MessageQueueEmpty( Exception ):
    pass
