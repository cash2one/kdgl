# coding: gbk

from django.conf.urls.defaults import *
from django.conf import settings

urlpatterns = patterns('',
    (r'^list/' , 'shangjie.mq.views.mq_list' ) ,
    (r'^(.+)/list/' , 'shangjie.mq.views.mq_content' ) , 
    (r'^(.+)/view/(.+)/' , 'shangjie.mq.views.mq_object' ) ,
)