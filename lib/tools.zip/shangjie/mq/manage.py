# coding: gbk

from shangjie.conf import settings

settings.check( 'MQ_BACKEND' )

from shangjie.mq import backend

try:
    module = getattr( __import__( 'shangjie.mq.backend.%s' % settings.MQ_BACKEND ).mq.backend , settings.MQ_BACKEND )
except ImportError:
    raise 
    
class MQManager( object ):
    def __init__( self ):
        self.mapping = {}
        
    def build( self , name , _type , size = None ):
        """
            ����һ����Ϣ���ж��󣬲����¶��й����������Ϣ��
        """
        if name in self.mapping:
            q = self.mapping[ name ]
        else:
            q = module.MessageQueue( name , _type , size )
            self.mapping[ name ] = q
            
        return q
        
    def list( self ):
        pass
        
gMsgMng = MQManager()



